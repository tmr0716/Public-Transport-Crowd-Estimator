import { Router, Request, Response } from 'express';
import { db, CURATED_ROUTES } from './db';

export const apiRouter = Router();

// Middleware to extract Bearer token
function authMiddleware(req: Request, res: Response, next: () => void) {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    res.status(401).json({ error: 'Unauthorized: Missing or invalid token' });
    return;
  }
  const token = authHeader.split(' ')[1];
  const user = db.findUserByToken(token);
  if (!user) {
    res.status(401).json({ error: 'Unauthorized: Session expired' });
    return;
  }
  (req as any).user = user;
  (req as any).token = token;
  next();
}

// 1. REGISTER
apiRouter.post('/auth/register', (req: Request, res: Response) => {
  try {
    const { email, phone, name, password, vehicle } = req.body;
    if (!email || !phone || !password) {
      res.status(400).json({ error: 'Email, phone, and password are required' });
      return;
    }
    const existing = db.findUserByIdentifier(email) || db.findUserByIdentifier(phone);
    if (existing) {
      res.status(409).json({ error: 'An account with this email or phone number already exists' });
      return;
    }
    const result = db.createUser({
      email,
      phone,
      name: name || email.split('@')[0],
      password,
      vehicle,
    });
    res.status(201).json(result);
  } catch (error: any) {
    res.status(500).json({ error: error.message || 'Registration failed' });
  }
});

// 2. LOGIN
apiRouter.post('/auth/login', (req: Request, res: Response) => {
  try {
    const { identifier, password } = req.body;
    if (!identifier || !password) {
      res.status(400).json({ error: 'Identifier and password are required' });
      return;
    }
    const result = db.authenticate(identifier, password);
    if (!result) {
      res.status(401).json({ error: 'Invalid credentials. Please verify identifier and password.' });
      return;
    }
    res.json(result);
  } catch (error: any) {
    res.status(500).json({ error: error.message || 'Login failed' });
  }
});

// 3. QUICK DEMO LOGIN (Evaluator fast access)
apiRouter.post('/auth/quick-demo', (req: Request, res: Response) => {
  try {
    const result = db.getOrCreateQuickDemoUser();
    res.json(result);
  } catch (error: any) {
    res.status(500).json({ error: error.message || 'Demo login failed' });
  }
});

// 4. GET CURRENT AUTHENTICATED USER
apiRouter.get('/auth/me', authMiddleware, (req: Request, res: Response) => {
  const user = (req as any).user;
  res.json({ user: db.sanitizeUser(user) });
});

// 5. UPDATE VEHICLE PROFILE
apiRouter.put('/user/vehicle', authMiddleware, (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    const { vehicle } = req.body;
    if (!vehicle) {
      res.status(400).json({ error: 'Vehicle profile payload is required' });
      return;
    }
    const updated = db.updateVehicleProfile(user.id, vehicle);
    res.json({ user: updated });
  } catch (error: any) {
    res.status(500).json({ error: error.message || 'Vehicle update failed' });
  }
});

// 6. UPDATE USER PREFERENCES
apiRouter.put('/user/preferences', authMiddleware, (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    const { preferences } = req.body;
    const updated = db.updatePreferences(user.id, preferences);
    res.json({ user: updated });
  } catch (error: any) {
    res.status(500).json({ error: error.message || 'Preferences update failed' });
  }
});

// 7. GET ROUTES & DESTINATIONS
apiRouter.get('/routes', (req: Request, res: Response) => {
  res.json({
    routes: CURATED_ROUTES,
    destinations: db.getDestinations(),
  });
});

// 8. SEARCH DESTINATIONS / PLACES
apiRouter.get('/routes/search', (req: Request, res: Response) => {
  const query = (req.query.q as string || '').toLowerCase().trim();
  const allDestinations = db.getDestinations();

  if (!query) {
    res.json({ results: allDestinations });
    return;
  }

  const matches = allDestinations.filter(
    (d) =>
      d.name.toLowerCase().includes(query) ||
      d.category.toLowerCase().includes(query) ||
      d.description.toLowerCase().includes(query)
  );

  const routeMatches = CURATED_ROUTES.filter(
    (r) =>
      r.destination.toLowerCase().includes(query) ||
      r.name.toLowerCase().includes(query) ||
      r.via.toLowerCase().includes(query)
  );

  res.json({
    destinations: matches,
    routes: routeMatches,
  });
});

// 9. SAVE TRIP RECORD
apiRouter.post('/trips', authMiddleware, (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    const tripData = req.body;
    const record = {
      id: `trip_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`,
      userId: user.id,
      destination: tripData.destination || 'Smart City Tech Park Hub',
      origin: tripData.origin || 'Electronic City Terminal Gate',
      routeId: tripData.routeId || 'route_tech_park',
      distanceKm: tripData.distanceKm || 4.8,
      durationMin: tripData.durationMin || 11,
      durationSec: tripData.durationSec || 45,
      completedAt: new Date().toISOString(),
      safetyScore: tripData.safetyScore || 98,
      obstaclesDetected: tripData.obstaclesDetected || 4,
      reroutesCount: tripData.reroutesCount || 3,
      emergencyBrakes: tripData.emergencyBrakes || 1,
      vehicleModel: tripData.vehicleModel || user.vehicle.modelName,
      events: tripData.events || [],
    };
    const saved = db.saveTrip(record);
    res.status(201).json({ trip: saved });
  } catch (error: any) {
    res.status(500).json({ error: error.message || 'Saving trip failed' });
  }
});

// 10. GET TRIP HISTORY
apiRouter.get('/trips', authMiddleware, (req: Request, res: Response) => {
  const user = (req as any).user;
  const trips = db.getTrips(user.id);
  res.json({ trips });
});

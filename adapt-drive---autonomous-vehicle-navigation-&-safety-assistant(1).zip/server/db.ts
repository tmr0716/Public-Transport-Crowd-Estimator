import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import { UserProfile, VehicleProfile, TripRecord } from '../src/types/app';
import { DEFAULT_SAVED_DESTINATIONS, CURATED_ROUTES } from '../src/data/curatedRoutes';

export { CURATED_ROUTES, DEFAULT_SAVED_DESTINATIONS };

interface DatabaseSchema {
  users: Array<{
    id: string;
    email: string;
    phone: string;
    name: string;
    passwordHash: string;
    salt: string;
    vehicle: VehicleProfile;
    preferences: {
      soundEnabled: boolean;
      autoOvertake: boolean;
      cautiousMargin: number;
    };
    tokens: string[];
    createdAt: string;
  }>;
  trips: TripRecord[];
  savedDestinations: Array<{
    id: string;
    name: string;
    category: string;
    coordinates: [number, number];
    description: string;
  }>;
}

const DATA_DIR = path.resolve(process.cwd(), 'data');
const DB_FILE = path.join(DATA_DIR, 'db.json');

class Database {
  private data: DatabaseSchema;

  constructor() {
    this.data = this.load();
  }

  private load(): DatabaseSchema {
    try {
      if (!fs.existsSync(DATA_DIR)) {
        fs.mkdirSync(DATA_DIR, { recursive: true });
      }
      if (fs.existsSync(DB_FILE)) {
        const raw = fs.readFileSync(DB_FILE, 'utf-8');
        return JSON.parse(raw);
      }
    } catch (e) {
      console.error('Failed to load database file, creating fresh DB:', e);
    }

    const initialDb: DatabaseSchema = {
      users: [],
      trips: [],
      savedDestinations: DEFAULT_SAVED_DESTINATIONS,
    };
    this.save(initialDb);
    return initialDb;
  }

  private save(data: DatabaseSchema): void {
    try {
      if (!fs.existsSync(DATA_DIR)) {
        fs.mkdirSync(DATA_DIR, { recursive: true });
      }
      fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2), 'utf-8');
    } catch (e) {
      console.error('Failed to write database file:', e);
    }
  }

  public hashPassword(password: string, salt: string): string {
    return crypto.pbkdf2Sync(password, salt, 1000, 64, 'sha512').toString('hex');
  }

  public generateToken(): string {
    return crypto.randomBytes(32).toString('hex');
  }

  public findUserByIdentifier(identifier: string) {
    const clean = identifier.trim().toLowerCase();
    return this.data.users.find(
      (u) => u.email.toLowerCase() === clean || u.phone === clean
    );
  }

  public findUserByToken(token: string) {
    return this.data.users.find((u) => u.tokens.includes(token));
  }

  public createUser(userData: {
    email: string;
    phone: string;
    name: string;
    password: string;
    vehicle?: Partial<VehicleProfile>;
  }) {
    const salt = crypto.randomBytes(16).toString('hex');
    const passwordHash = this.hashPassword(userData.password, salt);
    const token = this.generateToken();

    const defaultVehicle: VehicleProfile = {
      type: (userData.vehicle?.type as any) || 'suv',
      modelName: userData.vehicle?.modelName || 'Production Compact SUV',
      width: userData.vehicle?.width || 1.82,
      length: userData.vehicle?.length || 4.25,
      turningRadius: userData.vehicle?.turningRadius || 5.2,
      brakingDist: userData.vehicle?.brakingDist || 13.5,
    };

    const newUser = {
      id: `usr_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`,
      email: userData.email.trim().toLowerCase(),
      phone: userData.phone.trim(),
      name: userData.name || userData.email.split('@')[0],
      passwordHash,
      salt,
      vehicle: defaultVehicle,
      preferences: {
        soundEnabled: true,
        autoOvertake: true,
        cautiousMargin: 2.0,
      },
      tokens: [token],
      createdAt: new Date().toISOString(),
    };

    this.data.users.push(newUser);
    this.save(this.data);
    return { user: this.sanitizeUser(newUser), token };
  }

  public authenticate(identifier: string, password: string) {
    const user = this.findUserByIdentifier(identifier);
    if (!user) return null;
    const hash = this.hashPassword(password, user.salt);
    if (hash !== user.passwordHash) return null;

    const token = this.generateToken();
    user.tokens.push(token);
    if (user.tokens.length > 5) {
      user.tokens.shift();
    }
    this.save(this.data);
    return { user: this.sanitizeUser(user), token };
  }

  public updateVehicleProfile(userId: string, vehicle: VehicleProfile) {
    const user = this.data.users.find((u) => u.id === userId);
    if (!user) return null;
    user.vehicle = { ...user.vehicle, ...vehicle };
    this.save(this.data);
    return this.sanitizeUser(user);
  }

  public updatePreferences(userId: string, prefs: any) {
    const user = this.data.users.find((u) => u.id === userId);
    if (!user) return null;
    user.preferences = { ...user.preferences, ...prefs };
    this.save(this.data);
    return this.sanitizeUser(user);
  }

  public saveTrip(trip: TripRecord) {
    this.data.trips.unshift(trip);
    if (this.data.trips.length > 100) {
      this.data.trips.pop();
    }
    this.save(this.data);
    return trip;
  }

  public getTrips(userId?: string): TripRecord[] {
    if (userId) {
      return this.data.trips.filter((t) => t.userId === userId);
    }
    return this.data.trips;
  }

  public getDestinations() {
    return this.data.savedDestinations;
  }

  public sanitizeUser(user: DatabaseSchema['users'][0]): UserProfile {
    return {
      id: user.id,
      name: user.name,
      email: user.email,
      phone: user.phone,
      vehicle: user.vehicle,
      preferences: user.preferences,
      registeredAt: user.createdAt,
    };
  }

  public getOrCreateQuickDemoUser() {
    const demoEmail = 'driver@adapt.in';
    let user = this.findUserByIdentifier(demoEmail);
    if (!user) {
      const res = this.createUser({
        email: demoEmail,
        phone: '9876543210',
        name: 'Arjun Sharma',
        password: 'drive123',
        vehicle: {
          type: 'suv',
          modelName: 'Production Compact SUV',
          width: 1.82,
          length: 4.25,
          turningRadius: 5.2,
          brakingDist: 13.5,
        },
      });
      return res;
    }
    const token = this.generateToken();
    user.tokens.push(token);
    this.save(this.data);
    return { user: this.sanitizeUser(user), token };
  }
}

export const db = new Database();

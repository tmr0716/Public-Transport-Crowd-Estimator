/**
 * Autonomous Vehicle Sprite Renderer (High-Tech Black Model Autonomous Car)
 */

import { EgoVehicleState } from '../types/simulation';
import { WORLD_SCALE } from '../utils/geometry';

export class VehicleSpriteRenderer {
  private readonly carWidthPx: number;
  private readonly carLengthPx: number;

  constructor() {
    this.carWidthPx = 1.85 * WORLD_SCALE;
    this.carLengthPx = 4.4 * WORLD_SCALE;
  }

  public renderVehicle(
    ctx: CanvasRenderingContext2D,
    screenX: number,
    screenY: number,
    ego: EgoVehicleState,
    simTime: number
  ): void {
    const w = this.carWidthPx;
    const l = this.carLengthPx;
    const halfW = w / 2;
    const halfL = l / 2;

    ctx.save();
    ctx.translate(screenX, screenY);
    ctx.rotate(ego.heading);

    // 1. Soft Dynamic Drop Shadow under Chassis
    ctx.fillStyle = 'rgba(0, 0, 0, 0.65)';
    ctx.beginPath();
    ctx.ellipse(0, 4, halfW + 6, halfL + 6, 0, 0, Math.PI * 2);
    ctx.fill();

    // 2. Cyan Sensor Ground Aura / Chassis Underglow
    const underglow = ctx.createRadialGradient(0, 0, halfW * 0.5, 0, 0, halfL * 1.1);
    underglow.addColorStop(0, 'rgba(56, 189, 248, 0.22)');
    underglow.addColorStop(0.6, 'rgba(14, 165, 233, 0.08)');
    underglow.addColorStop(1, 'rgba(14, 165, 233, 0)');
    ctx.fillStyle = underglow;
    ctx.beginPath();
    ctx.ellipse(0, 0, halfW + 14, halfL + 12, 0, 0, Math.PI * 2);
    ctx.fill();

    // 3. Four Wheels with Steerable Front Wheels
    const wheelW = 4.5;
    const wheelL = 12.0;
    const frontAxleY = -halfL * 0.62;
    const rearAxleY = halfL * 0.65;
    const trackW = halfW + 1.2;

    this.drawWheel(ctx, -trackW, rearAxleY, wheelW, wheelL, 0);
    this.drawWheel(ctx, trackW, rearAxleY, wheelW, wheelL, 0);
    this.drawWheel(ctx, -trackW, frontAxleY, wheelW, wheelL, ego.steeringAngle);
    this.drawWheel(ctx, trackW, frontAxleY, wheelW, wheelL, ego.steeringAngle);

    // 4. Front Headlights Projecting Forward
    const lightBeamGrad = ctx.createLinearGradient(0, -halfL, 0, -halfL - 95);
    lightBeamGrad.addColorStop(0, 'rgba(56, 189, 248, 0.45)');
    lightBeamGrad.addColorStop(0.3, 'rgba(224, 242, 254, 0.18)');
    lightBeamGrad.addColorStop(1, 'rgba(56, 189, 248, 0)');
    ctx.fillStyle = lightBeamGrad;

    ctx.beginPath();
    ctx.moveTo(-halfW + 4, -halfL);
    ctx.lineTo(-halfW - 22, -halfL - 95);
    ctx.lineTo(-halfW + 12, -halfL - 95);
    ctx.closePath();
    ctx.fill();

    ctx.beginPath();
    ctx.moveTo(halfW - 4, -halfL);
    ctx.lineTo(halfW - 12, -halfL - 95);
    ctx.lineTo(halfW + 22, -halfL - 95);
    ctx.closePath();
    ctx.fill();

    // 5. Main Obsidian Black Body Shell
    const bodyGrad = ctx.createLinearGradient(-halfW, 0, halfW, 0);
    bodyGrad.addColorStop(0.0, '#020617');
    bodyGrad.addColorStop(0.12, '#0f172a');
    bodyGrad.addColorStop(0.48, '#1e293b');
    bodyGrad.addColorStop(0.55, '#334155');
    bodyGrad.addColorStop(0.88, '#0f172a');
    bodyGrad.addColorStop(1.0, '#020617');
    ctx.fillStyle = bodyGrad;
    ctx.beginPath();
    ctx.moveTo(-halfW + 6, -halfL);
    ctx.quadraticCurveTo(0, -halfL - 4.5, halfW - 6, -halfL);
    ctx.lineTo(halfW, -halfL + 12);
    ctx.lineTo(halfW + 1.0, 0);
    ctx.lineTo(halfW, halfL - 10);
    ctx.quadraticCurveTo(0, halfL + 3.0, -halfW + 6, halfL);
    ctx.lineTo(-halfW, halfL - 10);
    ctx.lineTo(-halfW - 1.0, 0);
    ctx.lineTo(-halfW, -halfL + 12);
    ctx.closePath();
    ctx.fill();

    ctx.strokeStyle = '#38bdf8';
    ctx.lineWidth = 0.8;
    ctx.stroke();

    // 6. Panoramic Glass Roof
    const glassGrad = ctx.createLinearGradient(-halfW, -halfL * 0.3, halfW, halfL * 0.5);
    glassGrad.addColorStop(0.0, '#090d16');
    glassGrad.addColorStop(0.4, '#0f172a');
    glassGrad.addColorStop(0.7, '#1e3a5f');
    glassGrad.addColorStop(1.0, '#090d16');
    ctx.fillStyle = glassGrad;
    ctx.beginPath();
    ctx.moveTo(-halfW * 0.72, -halfL * 0.32);
    ctx.quadraticCurveTo(0, -halfL * 0.38, halfW * 0.72, -halfL * 0.32);
    ctx.lineTo(halfW * 0.65, halfL * 0.48);
    ctx.quadraticCurveTo(0, halfL * 0.52, -halfW * 0.65, halfL * 0.48);
    ctx.closePath();
    ctx.fill();

    // 7. Roof-Mounted LiDAR Puck
    const lidarY = -halfL * 0.05;
    ctx.fillStyle = '#020617';
    ctx.beginPath();
    ctx.roundRect(-4.5, lidarY - 4.5, 9, 9, 3);
    ctx.fill();
    ctx.strokeStyle = '#38bdf8';
    ctx.lineWidth = 1.2;
    ctx.stroke();

    const pulseRadius = 1.5 + Math.sin(simTime * 8) * 0.8;
    ctx.fillStyle = '#38bdf8';
    ctx.beginPath();
    ctx.arc(0, lidarY, pulseRadius, 0, Math.PI * 2);
    ctx.fill();

    // 8. Rear Dynamic LED Brake Light Bar
    const isBraking = ego.isBraking;
    if (isBraking) {
      const brakeBloom = ctx.createRadialGradient(0, halfL + 1, 2, 0, halfL + 6, 28);
      brakeBloom.addColorStop(0, 'rgba(239, 68, 68, 0.85)');
      brakeBloom.addColorStop(0.4, 'rgba(220, 38, 38, 0.35)');
      brakeBloom.addColorStop(1, 'rgba(220, 38, 38, 0)');
      ctx.fillStyle = brakeBloom;
      ctx.beginPath();
      ctx.ellipse(0, halfL + 4, halfW + 10, 14, 0, 0, Math.PI * 2);
      ctx.fill();

      ctx.fillStyle = '#ff1a1a';
      ctx.beginPath();
      ctx.roundRect(-halfW * 0.82, halfL - 1.5, w * 0.82, 3.5, 1.5);
      ctx.fill();
    } else {
      ctx.fillStyle = '#dc2626';
      ctx.fillRect(-halfW * 0.8, halfL - 1, 6, 2);
      ctx.fillRect(halfW * 0.8 - 6, halfL - 1, 6, 2);
      ctx.fillStyle = 'rgba(220, 38, 38, 0.65)';
      ctx.fillRect(-halfW * 0.5, halfL - 0.8, w * 0.5, 1.2);
    }

    // 9. Turn Indicators
    if (ego.indicator !== 'none') {
      const isBlinkOn = Math.floor(simTime * 3.5) % 2 === 0;
      if (isBlinkOn) {
        ctx.fillStyle = '#f59e0b';
        if (ego.indicator === 'left') {
          ctx.beginPath();
          ctx.arc(-halfW - 3.2, -halfL * 0.22, 2.0, 0, Math.PI * 2);
          ctx.arc(-halfW + 4, halfL - 1, 2.5, 0, Math.PI * 2);
          ctx.fill();
        } else if (ego.indicator === 'right') {
          ctx.beginPath();
          ctx.arc(halfW + 3.2, -halfL * 0.22, 2.0, 0, Math.PI * 2);
          ctx.arc(halfW - 4, halfL - 1, 2.5, 0, Math.PI * 2);
          ctx.fill();
        }
      }
    }

    ctx.restore();
  }

  private drawWheel(
    ctx: CanvasRenderingContext2D,
    x: number,
    y: number,
    width: number,
    length: number,
    steerAngle: number
  ): void {
    ctx.save();
    ctx.translate(x, y);
    ctx.rotate(steerAngle);
    ctx.fillStyle = '#09090b';
    ctx.beginPath();
    ctx.roundRect(-width / 2, -length / 2, width, length, 2.5);
    ctx.fill();
    ctx.fillStyle = '#27272a';
    ctx.fillRect(-width * 0.35, -length * 0.35, width * 0.7, length * 0.7);
    ctx.restore();
  }
}

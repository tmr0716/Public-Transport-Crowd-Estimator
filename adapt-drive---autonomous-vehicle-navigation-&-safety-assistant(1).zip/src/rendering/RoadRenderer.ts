/**
 * Autonomous Vehicle HD Vector Map & BEV Perception Renderer
 */

import {
  LANE_CENTERS,
  WORLD_SCALE,
  ROAD_LEFT_EDGE,
  ROAD_RIGHT_EDGE,
  MEDIAN_LEFT_EDGE,
  MEDIAN_RIGHT_EDGE,
  OPPOSING_ROAD_LEFT_EDGE,
  OPPOSING_ROAD_RIGHT_EDGE,
} from '../utils/geometry';

export interface BEVTrafficAgent {
  id: string;
  type: 'rickshaw' | 'motorcycle' | 'truck' | 'sedan';
  x: number;
  y: number;
  vx: number;
  vy: number;
  targetSpeed: number;
  heading: number;
  targetHeading: number;
  width: number;
  length: number;
  color: string;
  laneChangeTimer: number;
  targetX: number;
}

export class RoadRenderer {
  private ambientAgents: BEVTrafficAgent[] = [];
  private opposingVehicles: BEVTrafficAgent[] = [];

  constructor() {
    this.initRealisticTraffic();
  }

  private initRealisticTraffic(): void {
    // Traffic in right lane (Lane 2) and fast lane, keeping ego's immediate path clear
    this.ambientAgents = [
      {
        id: 'truck_cargo_bev_1',
        type: 'truck',
        x: LANE_CENTERS[2], // Rightmost lane
        y: 115.0,
        vx: 0,
        vy: 8.5,
        targetSpeed: 8.5,
        heading: 0,
        targetHeading: 0,
        width: 2.2,
        length: 5.5,
        color: '#f97316',
        laneChangeTimer: 20.0,
        targetX: LANE_CENTERS[2],
      },
      {
        id: 'sedan_fast_bev_1',
        type: 'sedan',
        x: LANE_CENTERS[2],
        y: 210.0,
        vx: 0,
        vy: 14.0, // Fast sedan cruising ahead in right lane
        targetSpeed: 14.0,
        heading: 0,
        targetHeading: 0,
        width: 1.8,
        length: 4.3,
        color: '#e2e8f0',
        laneChangeTimer: 15.0,
        targetX: LANE_CENTERS[2],
      },
    ];

    // Oncoming traffic in opposing carriageway (across median)
    this.opposingVehicles = [
      {
        id: 'opp_truck_1',
        type: 'truck',
        x: -6.85,
        y: 120,
        vx: 0,
        vy: -11.5,
        targetSpeed: -11.5,
        heading: Math.PI,
        targetHeading: Math.PI,
        width: 2.2,
        length: 5.4,
        color: '#ef4444',
        laneChangeTimer: 0,
        targetX: -6.85,
      },
      {
        id: 'opp_rickshaw_1',
        type: 'rickshaw',
        x: -3.35,
        y: 190,
        vx: 0,
        vy: -7.5,
        targetSpeed: -7.5,
        heading: Math.PI,
        targetHeading: Math.PI,
        width: 1.4,
        length: 2.7,
        color: '#eab308',
        laneChangeTimer: 0,
        targetX: -3.35,
      },
      {
        id: 'opp_sedan_1',
        type: 'sedan',
        x: -6.85,
        y: 310,
        vx: 0,
        vy: -13.0,
        targetSpeed: -13.0,
        heading: Math.PI,
        targetHeading: Math.PI,
        width: 1.8,
        length: 4.2,
        color: '#38bdf8',
        laneChangeTimer: 0,
        targetX: -6.85,
      },
    ];
  }

  public updateAmbientTraffic(dt: number, egoY: number): void {
    for (const agent of this.ambientAgents) {
      agent.y += agent.vy * dt;
      if (agent.y < egoY - 45) {
        agent.y = egoY + 140 + Math.random() * 50;
      } else if (agent.y > egoY + 240) {
        agent.y = egoY - 35;
      }
    }

    for (const opp of this.opposingVehicles) {
      opp.y += opp.vy * dt;
      if (opp.y < egoY - 60) {
        opp.y = egoY + 160 + Math.random() * 60;
      }
    }
  }

  public renderRoad(
    ctx: CanvasRenderingContext2D,
    camX: number,
    camY: number,
    canvasW: number,
    canvasH: number,
    simTime: number
  ): void {
    ctx.save();

    // 1. Deep Midnight Sensor Space Background
    ctx.fillStyle = '#030712';
    ctx.fillRect(0, 0, canvasW, canvasH);
    this.drawDigitalGrid(ctx, camX, camY, canvasW, canvasH);

    // 2. Opposite Carriageway
    const oppRoadLeftScreen = canvasW * 0.5 + (OPPOSING_ROAD_LEFT_EDGE - camX) * WORLD_SCALE;
    const oppRoadWidthPx = (OPPOSING_ROAD_RIGHT_EDGE - OPPOSING_ROAD_LEFT_EDGE) * WORLD_SCALE;
    ctx.fillStyle = '#090d16';
    ctx.fillRect(oppRoadLeftScreen, 0, oppRoadWidthPx, canvasH);

    const oppDashedScreen = canvasW * 0.5 + (-5.1 - camX) * WORLD_SCALE;
    this.drawVectorDashedLine(ctx, oppDashedScreen, canvasH, camY, 'rgba(148, 163, 184, 0.45)');

    ctx.strokeStyle = 'rgba(148, 163, 184, 0.65)';
    ctx.lineWidth = 1.8;
    ctx.beginPath();
    ctx.moveTo(oppRoadLeftScreen + 2, 0);
    ctx.lineTo(oppRoadLeftScreen + 2, canvasH);
    ctx.stroke();

    // 3. Concrete Median Divider
    const medianLeftScreen = canvasW * 0.5 + (MEDIAN_LEFT_EDGE - camX) * WORLD_SCALE;
    const medianWidthPx = (MEDIAN_RIGHT_EDGE - MEDIAN_LEFT_EDGE) * WORLD_SCALE;
    ctx.fillStyle = '#0f172a';
    ctx.fillRect(medianLeftScreen, 0, medianWidthPx, canvasH);
    this.drawSensorHazardCurb(ctx, medianLeftScreen + medianWidthPx - 3.5, canvasH, camY, 3.5);

    // 4. Host Vehicle Driving Carriageway
    const egoRoadLeftScreen = canvasW * 0.5 + (ROAD_LEFT_EDGE - camX) * WORLD_SCALE;
    const egoRoadWidthPx = (ROAD_RIGHT_EDGE - ROAD_LEFT_EDGE) * WORLD_SCALE;
    ctx.fillStyle = '#0a0f1d';
    ctx.fillRect(egoRoadLeftScreen, 0, egoRoadWidthPx, canvasH);

    // 5. Solid Road Boundary Edge Lines
    const leftEdgeScreen = canvasW * 0.5 + (ROAD_LEFT_EDGE + 0.2 - camX) * WORLD_SCALE;
    ctx.strokeStyle = '#facc15';
    ctx.lineWidth = 2.2;
    ctx.beginPath();
    ctx.moveTo(leftEdgeScreen, 0);
    ctx.lineTo(leftEdgeScreen, canvasH);
    ctx.stroke();

    const rightEdgeScreen = canvasW * 0.5 + (ROAD_RIGHT_EDGE - 0.2 - camX) * WORLD_SCALE;
    ctx.strokeStyle = 'rgba(241, 245, 249, 0.95)';
    ctx.lineWidth = 2.2;
    ctx.beginPath();
    ctx.moveTo(rightEdgeScreen, 0);
    ctx.lineTo(rightEdgeScreen, canvasH);
    ctx.stroke();

    // 6. Dashed White Lane Markings
    const screenLaneDiv01 = canvasW * 0.5 + (3.5 - camX) * WORLD_SCALE;
    const screenLaneDiv12 = canvasW * 0.5 + (7.0 - camX) * WORLD_SCALE;
    this.drawVectorDashedLine(ctx, screenLaneDiv01, canvasH, camY, 'rgba(255, 255, 255, 0.85)');
    this.drawVectorDashedLine(ctx, screenLaneDiv12, canvasH, camY, 'rgba(255, 255, 255, 0.85)');

    // 7. Zebra Crossing (y = 248m)
    this.drawZebraCrossingVector(ctx, camX, camY, canvasW, canvasH, 248.0);

    // 8. 360-Degree Concentric LiDAR Range Rings
    this.drawLiDARRings(ctx, canvasW, canvasH);

    // 9. Opposing Traffic
    this.drawOpposingTraffic(ctx, camX, camY, canvasW, canvasH);

    // 10. Ambient Agents
    this.drawAmbientAgents(ctx, camX, camY, canvasW, canvasH);

    ctx.restore();
  }

  private drawDigitalGrid(
    ctx: CanvasRenderingContext2D,
    camX: number,
    camY: number,
    w: number,
    h: number
  ): void {
    ctx.save();
    ctx.strokeStyle = 'rgba(30, 41, 59, 0.45)';
    ctx.lineWidth = 0.5;
    const gridSize = 10 * WORLD_SCALE;
    const offsetX = (camX * WORLD_SCALE) % gridSize;
    const offsetY = (camY * WORLD_SCALE) % gridSize;

    ctx.beginPath();
    for (let x = -offsetX; x < w; x += gridSize) {
      ctx.moveTo(x, 0);
      ctx.lineTo(x, h);
    }
    for (let y = -offsetY; y < h; y += gridSize) {
      ctx.moveTo(0, y);
      ctx.lineTo(w, y);
    }
    ctx.stroke();
    ctx.restore();
  }

  private drawLiDARRings(ctx: CanvasRenderingContext2D, canvasW: number, canvasH: number): void {
    const egoSx = canvasW * 0.5;
    const egoSy = canvasH * 0.70;
    const rangesMeters = [15, 30, 50, 75];

    ctx.save();
    for (const r of rangesMeters) {
      const radiusPx = r * WORLD_SCALE;
      ctx.strokeStyle = 'rgba(56, 189, 248, 0.20)';
      ctx.lineWidth = 1.0;
      ctx.setLineDash([4, 6]);
      ctx.beginPath();
      ctx.arc(egoSx, egoSy, radiusPx, 0, Math.PI * 2);
      ctx.stroke();

      ctx.fillStyle = 'rgba(56, 189, 248, 0.65)';
      ctx.font = '9px "JetBrains Mono", monospace';
      ctx.textAlign = 'left';
      ctx.fillText(`${r}M`, egoSx + radiusPx + 4, egoSy + 3);
    }
    ctx.restore();
  }

  private drawVectorDashedLine(
    ctx: CanvasRenderingContext2D,
    screenX: number,
    canvasH: number,
    camY: number,
    color: string
  ): void {
    ctx.save();
    ctx.strokeStyle = color;
    ctx.lineWidth = 1.8;
    const dashLenPx = 4.0 * WORLD_SCALE;
    const gapLenPx = 5.0 * WORLD_SCALE;
    const period = dashLenPx + gapLenPx;
    const offset = (camY * WORLD_SCALE) % period;
    ctx.setLineDash([dashLenPx, gapLenPx]);
    ctx.lineDashOffset = -offset;
    ctx.beginPath();
    ctx.moveTo(screenX, -period);
    ctx.lineTo(screenX, canvasH + period);
    ctx.stroke();
    ctx.restore();
  }

  private drawSensorHazardCurb(
    ctx: CanvasRenderingContext2D,
    x: number,
    canvasH: number,
    camY: number,
    width: number
  ): void {
    const stripeLenPx = 2.5 * WORLD_SCALE;
    const period = stripeLenPx * 2;
    const offset = (camY * WORLD_SCALE) % period;
    ctx.save();
    for (let y = -period - offset; y < canvasH + period; y += period) {
      ctx.fillStyle = '#eab308';
      ctx.fillRect(x, y, width, stripeLenPx);
      ctx.fillStyle = '#0f172a';
      ctx.fillRect(x, y + stripeLenPx, width, stripeLenPx);
    }
    ctx.restore();
  }

  private drawZebraCrossingVector(
    ctx: CanvasRenderingContext2D,
    camX: number,
    camY: number,
    canvasW: number,
    canvasH: number,
    worldY: number
  ): void {
    const sy = canvasH * 0.70 - (worldY - camY) * WORLD_SCALE;
    if (sy < -60 || sy > canvasH + 60) return;

    const roadLeft = canvasW * 0.5 + (ROAD_LEFT_EDGE + 0.5 - camX) * WORLD_SCALE;
    const roadRight = canvasW * 0.5 + (ROAD_RIGHT_EDGE - 0.5 - camX) * WORLD_SCALE;
    const crossingWidth = roadRight - roadLeft;
    const stripeW = 0.55 * WORLD_SCALE;
    const gapW = 0.45 * WORLD_SCALE;
    const crossingDepthPx = 3.2 * WORLD_SCALE;

    ctx.save();
    ctx.strokeStyle = 'rgba(56, 189, 248, 0.45)';
    ctx.lineWidth = 1.0;
    ctx.strokeRect(roadLeft - 2, sy - crossingDepthPx * 0.5 - 2, crossingWidth + 4, crossingDepthPx + 4);

    ctx.fillStyle = 'rgba(255, 255, 255, 0.85)';
    let x = roadLeft;
    while (x < roadRight) {
      ctx.fillRect(x, sy - crossingDepthPx * 0.5, stripeW, crossingDepthPx);
      x += stripeW + gapW;
    }
    ctx.restore();
  }

  private drawAmbientAgents(
    ctx: CanvasRenderingContext2D,
    camX: number,
    camY: number,
    canvasW: number,
    canvasH: number
  ): void {
    for (const a of this.ambientAgents) {
      const sx = canvasW * 0.5 + (a.x - camX) * WORLD_SCALE;
      const sy = canvasH * 0.70 - (a.y - camY) * WORLD_SCALE;
      if (sy < -80 || sy > canvasH + 80) continue;

      const w = a.width * WORLD_SCALE;
      const l = a.length * WORLD_SCALE;

      ctx.save();
      ctx.translate(sx, sy);
      ctx.rotate(a.heading);

      ctx.fillStyle = 'rgba(0, 0, 0, 0.55)';
      ctx.beginPath();
      ctx.ellipse(0, 3, w * 0.6, l * 0.55, 0, 0, Math.PI * 2);
      ctx.fill();

      if (a.type === 'truck') {
        const halfW = w / 2;
        const halfL = l / 2;
        ctx.fillStyle = a.color;
        ctx.fillRect(-halfW, -halfL + 12, w, l - 12);
        ctx.fillStyle = '#1e293b';
        ctx.fillRect(-halfW * 0.9, -halfL, w * 0.9, 12);
      } else {
        const halfW = w / 2;
        const halfL = l / 2;
        ctx.fillStyle = a.color;
        ctx.beginPath();
        ctx.roundRect(-halfW, -halfL, w, l, 5);
        ctx.fill();
        ctx.fillStyle = '#0f172a';
        ctx.beginPath();
        ctx.roundRect(-halfW * 0.75, -halfL * 0.35, w * 0.75, l * 0.55, 3);
        ctx.fill();
      }

      ctx.restore();
    }
  }

  private drawOpposingTraffic(
    ctx: CanvasRenderingContext2D,
    camX: number,
    camY: number,
    canvasW: number,
    canvasH: number
  ): void {
    for (const v of this.opposingVehicles) {
      const sx = canvasW * 0.5 + (v.x - camX) * WORLD_SCALE;
      const sy = canvasH * 0.70 - (v.y - camY) * WORLD_SCALE;
      if (sy < -80 || sy > canvasH + 80) continue;

      const w = v.width * WORLD_SCALE;
      const l = v.length * WORLD_SCALE;

      ctx.save();
      ctx.translate(sx, sy);
      ctx.rotate(v.heading);

      const halfW = w / 2;
      const halfL = l / 2;
      ctx.fillStyle = v.color;
      ctx.beginPath();
      ctx.roundRect(-halfW, -halfL, w, l, 4);
      ctx.fill();

      ctx.restore();
    }
  }
}

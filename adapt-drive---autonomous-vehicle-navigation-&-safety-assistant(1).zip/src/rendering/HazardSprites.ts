/**
 * Procedural Dynamic Hazard Sprites:
 * 1. Cow (Desi Zebu Cattle with prominent hump, curved horns, 4-leg walk cycle, soft shadow)
 * 2. Pedestrian (Walking human figure with head, shoulders, swinging arms & legs)
 * 3. Slower Vehicle Ahead (Auto-Rickshaw)
 */

import { HazardObject } from '../types/simulation';
import { WORLD_SCALE } from '../utils/geometry';

export class HazardSpriteRenderer {
  /**
   * Renders the animated Cow
   */
  public renderCow(
    ctx: CanvasRenderingContext2D,
    screenX: number,
    screenY: number,
    hazard: HazardObject
  ): void {
    const walkPhase = hazard.walkPhase || 0;
    const bodyLen = 2.2 * WORLD_SCALE; // ~39.6 px
    const bodyW = 0.85 * WORLD_SCALE;  // ~15.3 px

    ctx.save();
    ctx.translate(screenX, screenY);
    ctx.rotate(hazard.heading);

    // 1. Soft daylight drop shadow
    ctx.fillStyle = 'rgba(15, 23, 42, 0.35)';
    ctx.beginPath();
    ctx.ellipse(5, 7, bodyW * 0.7, bodyLen * 0.55, 0, 0, Math.PI * 2);
    ctx.fill();

    // 2. Articulated Legs
    const stride = 5.5;
    const legFL = Math.sin(walkPhase) * stride;
    const legFR = -Math.sin(walkPhase) * stride;
    const legRL = -Math.sin(walkPhase + 0.5) * stride;
    const legRR = Math.sin(walkPhase + 0.5) * stride;

    ctx.fillStyle = '#e7e5e4';
    ctx.strokeStyle = '#292524';
    ctx.lineWidth = 1.0;

    const drawLeg = (lx: number, ly: number, offset: number) => {
      ctx.beginPath();
      ctx.ellipse(lx, ly + offset, 2.0, 3.2, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
    };

    drawLeg(-bodyW * 0.42, bodyLen * 0.28, legFL);
    drawLeg(bodyW * 0.42, bodyLen * 0.28, legFR);
    drawLeg(-bodyW * 0.40, -bodyLen * 0.32, legRL);
    drawLeg(bodyW * 0.40, -bodyLen * 0.32, legRR);

    // 3. Main Torso
    const torsoGrad = ctx.createLinearGradient(-bodyW * 0.5, 0, bodyW * 0.5, 0);
    torsoGrad.addColorStop(0.0, '#d6d3d1');
    torsoGrad.addColorStop(0.3, '#f5f5f4');
    torsoGrad.addColorStop(0.7, '#e7e5e4');
    torsoGrad.addColorStop(1.0, '#a8a29e');
    ctx.fillStyle = torsoGrad;
    ctx.beginPath();
    ctx.moveTo(-bodyW * 0.38, bodyLen * 0.32);
    ctx.lineTo(bodyW * 0.38, bodyLen * 0.32);
    ctx.lineTo(bodyW * 0.48, -bodyLen * 0.15);
    ctx.quadraticCurveTo(bodyW * 0.45, -bodyLen * 0.45, 0, -bodyLen * 0.48);
    ctx.quadraticCurveTo(-bodyW * 0.45, -bodyLen * 0.45, -bodyW * 0.48, -bodyLen * 0.15);
    ctx.closePath();
    ctx.fill();

    // 4. Characteristic Indian Zebu Hump
    ctx.fillStyle = '#e7e5e4';
    ctx.beginPath();
    ctx.ellipse(0, bodyLen * 0.16, bodyW * 0.28, bodyLen * 0.12, 0, 0, Math.PI * 2);
    ctx.fill();

    // 5. Head and Neck
    ctx.fillStyle = '#f5f5f4';
    ctx.beginPath();
    ctx.ellipse(0, bodyLen * 0.46, bodyW * 0.26, bodyLen * 0.16, 0, 0, Math.PI * 2);
    ctx.fill();

    // Muzzle
    ctx.fillStyle = '#292524';
    ctx.beginPath();
    ctx.ellipse(0, bodyLen * 0.58, bodyW * 0.18, 2.5, 0, 0, Math.PI * 2);
    ctx.fill();

    // Horns
    ctx.strokeStyle = '#1c1917';
    ctx.lineWidth = 1.6;
    ctx.beginPath();
    ctx.moveTo(-bodyW * 0.18, bodyLen * 0.46);
    ctx.quadraticCurveTo(-bodyW * 0.45, bodyLen * 0.54, -bodyW * 0.35, bodyLen * 0.62);
    ctx.moveTo(bodyW * 0.18, bodyLen * 0.46);
    ctx.quadraticCurveTo(bodyW * 0.45, bodyLen * 0.54, bodyW * 0.35, bodyLen * 0.62);
    ctx.stroke();

    ctx.restore();
  }

  /**
   * Renders the animated Pedestrian crossing
   */
  public renderPedestrian(
    ctx: CanvasRenderingContext2D,
    screenX: number,
    screenY: number,
    hazard: HazardObject
  ): void {
    const walkPhase = hazard.walkPhase || 0;
    const shoulderW = 0.55 * WORLD_SCALE;
    const depthL = 0.35 * WORLD_SCALE;

    ctx.save();
    ctx.translate(screenX, screenY);
    ctx.rotate(hazard.heading);

    // Ground shadow
    ctx.fillStyle = 'rgba(15, 23, 42, 0.38)';
    ctx.beginPath();
    ctx.ellipse(3, 4, 6, 8, 0, 0, Math.PI * 2);
    ctx.fill();

    // Animated Legs
    const legStride = Math.sin(walkPhase) * 6;
    ctx.fillStyle = '#1e293b';
    ctx.fillRect(-3.5, -legStride - 2, 2.5, 5);
    ctx.fillRect(1.0, legStride - 2, 2.5, 5);

    // Torso
    ctx.fillStyle = '#2563eb';
    ctx.beginPath();
    ctx.roundRect(-shoulderW * 0.5, -depthL * 0.5, shoulderW, depthL, 3);
    ctx.fill();

    // Arms
    ctx.fillStyle = '#fed7aa';
    const armSwing = Math.sin(walkPhase) * 4;
    ctx.beginPath();
    ctx.arc(-shoulderW * 0.5 - 1.5, armSwing, 1.8, 0, Math.PI * 2);
    ctx.fill();
    ctx.beginPath();
    ctx.arc(shoulderW * 0.5 + 1.5, -armSwing, 1.8, 0, Math.PI * 2);
    ctx.fill();

    // Head
    ctx.fillStyle = '#1e293b';
    ctx.beginPath();
    ctx.arc(0, 0, 4.2, 0, Math.PI * 2);
    ctx.fill();

    ctx.restore();
  }

  /**
   * Renders the slower vehicle ahead (Iconic Indian Auto-Rickshaw)
   */
  public renderVehicleAhead(
    ctx: CanvasRenderingContext2D,
    screenX: number,
    screenY: number,
    hazard: HazardObject
  ): void {
    const w = hazard.width * WORLD_SCALE;
    const l = hazard.length * WORLD_SCALE;
    const halfW = w / 2;
    const halfL = l / 2;

    ctx.save();
    ctx.translate(screenX, screenY);
    ctx.rotate(hazard.heading);

    // Drop shadow
    ctx.fillStyle = 'rgba(15, 23, 42, 0.40)';
    ctx.beginPath();
    ctx.roundRect(-halfW + 4, -halfL + 6, w, l, 6);
    ctx.fill();

    // Wheels
    ctx.fillStyle = '#18181b';
    ctx.fillRect(-2, -halfL - 4, 4, 8);
    ctx.fillRect(-halfW - 2, halfL * 0.4 - 5, 3, 10);
    ctx.fillRect(halfW - 1, halfL * 0.4 - 5, 3, 10);

    // Lower Chassis: Indian Green Body Base
    ctx.fillStyle = '#15803d';
    ctx.beginPath();
    ctx.moveTo(0, -halfL);
    ctx.lineTo(halfW, -halfL * 0.4);
    ctx.lineTo(halfW, halfL);
    ctx.lineTo(-halfW, halfL);
    ctx.lineTo(-halfW, -halfL * 0.4);
    ctx.closePath();
    ctx.fill();

    // Yellow Canopy Roof
    const roofGrad = ctx.createLinearGradient(-halfW, 0, halfW, 0);
    roofGrad.addColorStop(0.0, '#ca8a04');
    roofGrad.addColorStop(0.3, '#facc15');
    roofGrad.addColorStop(0.7, '#fef08a');
    roofGrad.addColorStop(1.0, '#ca8a04');
    ctx.fillStyle = roofGrad;
    ctx.beginPath();
    ctx.moveTo(0, -halfL * 0.85);
    ctx.lineTo(halfW * 0.88, -halfL * 0.35);
    ctx.lineTo(halfW * 0.88, halfL * 0.85);
    ctx.lineTo(-halfW * 0.88, halfL * 0.85);
    ctx.lineTo(-halfW * 0.88, -halfL * 0.35);
    ctx.closePath();
    ctx.fill();
    ctx.strokeStyle = '#1c1917';
    ctx.lineWidth = 1.0;
    ctx.stroke();

    // Rear brake lamps
    ctx.fillStyle = '#dc2626';
    ctx.fillRect(-halfW * 0.75, halfL - 2, 4, 2);
    ctx.fillRect(halfW * 0.75 - 4, halfL - 2, 4, 2);

    ctx.restore();
  }
}

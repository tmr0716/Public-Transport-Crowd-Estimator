/**
 * Authentic Autonomous Vehicle Digital Twin & Sensor Perception 3D Renderer
 */

import { EgoVehicleState, HazardObject } from '../types/simulation';
import { SeededRandom } from '../utils/seededRandom';
import {
  LANE_CENTERS,
  getRoadGeometry,
  getLaneCenter,
  ROUNDABOUT_CENTER_Y,
  ROUNDABOUT_ISLAND_RADIUS,
} from '../utils/geometry';

export interface RoadSegmentPoint {
  x: number;
  y: number;
  z: number;
  width: number;
  curvature: number;
  surfaceQuality: 'paved' | 'patched' | 'rough';
}

export interface AmbientIndianVehicle {
  id: string;
  type: 'rickshaw' | 'motorcycle' | 'scooter' | 'truck' | 'car';
  subType?: 'delivery' | 'cruiser' | 'pillion' | 'standard';
  x: number;
  y: number;
  speed: number;
  baseSpeed: number;
  color: string;
  laneIndex?: number;
  lateralOffset?: number;
  laneChangeTimer: number;
  targetOffset: number;
  swayPhase: number;
  heading: number;
}

export class Realistic3DEnvironment {
  private rng: SeededRandom;
  private ambientVehicles: AmbientIndianVehicle[] = [];
  private roadSpline: RoadSegmentPoint[] = [];

  // Elevated Chase Camera Parameters
  private cameraHeight = 2.4; // 2.4m above road
  private cameraDistanceBack = 4.6; // 4.6m behind vehicle center
  private fov = 68; // degrees

  constructor() {
    this.rng = new SeededRandom(528194);
    this.generateRoadGeometry();
    this.initAmbientTraffic();
  }

  private generateRoadGeometry(): void {
    this.roadSpline = [];
    const totalDistance = 500;
    const step = 2.0;

    for (let y = 0; y <= totalDistance; y += step) {
      const geom = getRoadGeometry(y);
      let z = Math.sin(y * 0.008) * 0.45;
      if (Math.abs(y - 140) < 3.0) {
        z += Math.cos(((y - 140) / 3.0) * Math.PI) * 0.12;
      }
      if (Math.abs(y - 240) < 3.0) {
        z += Math.cos(((y - 240) / 3.0) * Math.PI) * 0.14;
      }

      let surfaceQuality: 'paved' | 'patched' | 'rough' = 'paved';
      if (y > 75 && y < 105) surfaceQuality = 'rough';
      else if (y > 180 && y < 220) surfaceQuality = 'patched';

      this.roadSpline.push({
        x: geom.curvatureX,
        y,
        z,
        width: geom.roadWidth,
        curvature: geom.curvatureX,
        surfaceQuality,
      });
    }
  }

  private initAmbientTraffic(): void {
    // Crowded street environment with multiple two-wheelers, autos, sedans, and trucks
    // Safely positioned in adjacent lanes/shoulders to maintain zero collisions with ego vehicle!
    this.ambientVehicles = [
      // Two-Wheeler 1: Commuter Motorcycle (Hero / Honda style)
      {
        id: 'tw_bike_commuter_1',
        type: 'motorcycle',
        subType: 'standard',
        x: getLaneCenter(2, 65.0) + 0.3,
        y: 65.0,
        speed: 10.5,
        baseSpeed: 10.5,
        color: '#2563eb', // Blue tank
        laneIndex: 2,
        lateralOffset: 0.3,
        laneChangeTimer: 0,
        targetOffset: 0.3,
        swayPhase: 0.8,
        heading: 0,
      },
      // Two-Wheeler 2: Scooter with Pillion passenger (Honda Activa style)
      {
        id: 'tw_scooter_pillion_1',
        type: 'scooter',
        subType: 'pillion',
        x: getLaneCenter(2, 115.0) + 0.4,
        y: 115.0,
        speed: 9.0,
        baseSpeed: 9.0,
        color: '#f43f5e', // Rose/coral scooter
        laneIndex: 2,
        lateralOffset: 0.4,
        laneChangeTimer: 0,
        targetOffset: 0.4,
        swayPhase: 1.5,
        heading: 0,
      },
      // Two-Wheeler 3: Delivery Bike with food container box on rear
      {
        id: 'tw_delivery_express_1',
        type: 'motorcycle',
        subType: 'delivery',
        x: getLaneCenter(2, 175.0) + 0.2,
        y: 175.0,
        speed: 12.0,
        baseSpeed: 12.0,
        color: '#ea580c', // Orange delivery
        laneIndex: 2,
        lateralOffset: 0.2,
        laneChangeTimer: 0,
        targetOffset: 0.2,
        swayPhase: 2.2,
        heading: 0,
      },
      // Two-Wheeler 4: Classic Cruiser Bike (Royal Enfield style)
      {
        id: 'tw_cruiser_bullet_1',
        type: 'motorcycle',
        subType: 'cruiser',
        x: getLaneCenter(2, 230.0) + 0.25,
        y: 230.0,
        speed: 12.5,
        baseSpeed: 12.5,
        color: '#10b981', // Emerald green & chrome
        laneIndex: 2,
        lateralOffset: 0.25,
        laneChangeTimer: 0,
        targetOffset: 0.25,
        swayPhase: 3.1,
        heading: 0,
      },
      // Two-Wheeler 5: Scooter around Chowk Roundabout
      {
        id: 'tw_scooter_city_2',
        type: 'scooter',
        subType: 'standard',
        x: getLaneCenter(2, 290.0) + 0.35,
        y: 290.0,
        speed: 9.8,
        baseSpeed: 9.8,
        color: '#eab308', // Yellow
        laneIndex: 2,
        lateralOffset: 0.35,
        laneChangeTimer: 0,
        targetOffset: 0.35,
        swayPhase: 0.4,
        heading: 0,
      },
      // Ambient Auto-Rickshaw 1 (Cruising in Lane 2)
      {
        id: 'rickshaw_ambient_1',
        type: 'rickshaw',
        x: getLaneCenter(2, 95.0),
        y: 95.0,
        speed: 7.8,
        baseSpeed: 7.8,
        color: '#eab308',
        laneIndex: 2,
        lateralOffset: 0,
        laneChangeTimer: 0,
        targetOffset: 0,
        swayPhase: 1.1,
        heading: 0,
      },
      // Ambient Auto-Rickshaw 2
      {
        id: 'rickshaw_ambient_2',
        type: 'rickshaw',
        x: getLaneCenter(2, 210.0),
        y: 210.0,
        speed: 8.2,
        baseSpeed: 8.2,
        color: '#15803d',
        laneIndex: 2,
        lateralOffset: 0,
        laneChangeTimer: 0,
        targetOffset: 0,
        swayPhase: 2.7,
        heading: 0,
      },
      // Heavy Truck
      {
        id: 'truck_cargo_3d_1',
        type: 'truck',
        x: getLaneCenter(2, 145.0),
        y: 145.0,
        speed: 8.5,
        baseSpeed: 8.5,
        color: '#f97316',
        laneIndex: 2,
        lateralOffset: 0,
        laneChangeTimer: 20.0,
        targetOffset: 0,
        swayPhase: 0.5,
        heading: 0,
      },
      // Sedan Cruiser
      {
        id: 'car_sedan_3d_1',
        type: 'car',
        x: getLaneCenter(2, 260.0),
        y: 260.0,
        speed: 13.5,
        baseSpeed: 14.0,
        color: '#f1f5f9',
        laneIndex: 2,
        lateralOffset: 0,
        laneChangeTimer: 15.0,
        targetOffset: 0,
        swayPhase: 2.1,
        heading: 0,
      },
      // City Hatchback
      {
        id: 'car_hatchback_3d_1',
        type: 'car',
        x: getLaneCenter(2, 335.0),
        y: 335.0,
        speed: 11.5,
        baseSpeed: 11.5,
        color: '#ef4444',
        laneIndex: 2,
        lateralOffset: 0,
        laneChangeTimer: 0,
        targetOffset: 0,
        swayPhase: 1.8,
        heading: 0,
      },
    ];
  }

  public update(dt: number, egoY: number): void {
    for (const v of this.ambientVehicles) {
      v.y += v.speed * dt;
      v.swayPhase += dt * 3.0;

      // Update lateral position along lane center with gentle sway
      const laneIdx = v.laneIndex ?? 2;
      const baseLaneX = getLaneCenter(laneIdx, v.y);
      const sway = Math.sin(v.swayPhase) * (v.type === 'motorcycle' || v.type === 'scooter' ? 0.12 : 0.06);
      v.x = baseLaneX + (v.lateralOffset ?? 0) + sway;

      // Loop smoothly around ego vehicle window
      if (v.y < egoY - 35) {
        v.y = egoY + 160 + Math.random() * 50;
      } else if (v.y > egoY + 280) {
        v.y = egoY - 30;
      }
    }
  }

  public projectPoint(
    worldX: number,
    worldY: number,
    worldZ: number,
    ego: EgoVehicleState,
    screenWidth: number,
    screenHeight: number
  ): { x: number; y: number; scale: number; visible: boolean; relY: number } {
    const camY = ego.y - this.cameraDistanceBack;
    const relY = worldY - camY;

    if (relY <= 0.8) {
      return { x: 0, y: 0, scale: 0, visible: false, relY };
    }

    const camX = ego.x;
    const relX = worldX - camX;
    const camHeightEffective = this.cameraHeight + (ego.pitch || 0) * 0.4;
    const relZ = worldZ - camHeightEffective;

    const fovRad = (this.fov * Math.PI) / 180;
    const focalLength = (screenWidth * 0.5) / Math.tan(fovRad * 0.5);

    const horizonY = screenHeight * 0.40 + (ego.pitch || 0) * 80;
    const horizonX = screenWidth * 0.5 - ego.steeringAngle * 45;

    const scale = focalLength / relY;
    const sx = horizonX + relX * scale;
    const sy = horizonY - relZ * scale;

    return {
      x: sx,
      y: sy,
      scale,
      visible: relY > 1.0 && relY < 320,
      relY,
    };
  }

  public render(
    ctx: CanvasRenderingContext2D,
    width: number,
    height: number,
    ego: EgoVehicleState,
    hazards: HazardObject[],
    simTime: number,
    settings: any
  ): void {
    ctx.save();

    // 1. Midnight Sensor Space Background
    this.renderMidnightSensorSpace(ctx, width, height, ego);

    // 2. 3D Vector Road Surface & Curvature
    this.render3DVectorRoad(ctx, width, height, ego, simTime);

    // 3. Planned Trajectory 3D Ribbon
    if (settings.showPlannedPath) {
      this.renderPlannedTrajectoryRibbon(ctx, width, height, ego, simTime);
    }

    // 4. Autonomous Sensor Suite
    if (settings.showSensorCone) {
      this.renderSensorPerceptionBeams(ctx, width, height, ego, simTime);
    }

    // 5. Dynamic Traffic & Road Hazards (Perception Twins)
    this.renderTrafficAndHazards(ctx, width, height, ego, hazards, simTime, settings);

    // 6. Black Autonomous Car Model
    this.renderBlackAutonomousCarModel(ctx, width, height, ego, simTime);

    ctx.restore();
  }

  private renderMidnightSensorSpace(
    ctx: CanvasRenderingContext2D,
    w: number,
    h: number,
    ego: EgoVehicleState
  ): void {
    const horizonY = h * 0.40 + (ego.pitch || 0) * 80;

    const bgGrad = ctx.createLinearGradient(0, 0, 0, h);
    bgGrad.addColorStop(0.0, '#02040a');
    bgGrad.addColorStop(0.38, '#050a18');
    bgGrad.addColorStop(0.42, '#080d1e');
    bgGrad.addColorStop(1.0, '#030712');
    ctx.fillStyle = bgGrad;
    ctx.fillRect(0, 0, w, h);

    const horizonGlow = ctx.createRadialGradient(w * 0.5, horizonY, 10, w * 0.5, horizonY, w * 0.6);
    horizonGlow.addColorStop(0, 'rgba(56, 189, 248, 0.18)');
    horizonGlow.addColorStop(0.5, 'rgba(14, 165, 233, 0.05)');
    horizonGlow.addColorStop(1, 'rgba(14, 165, 233, 0)');
    ctx.fillStyle = horizonGlow;
    ctx.fillRect(0, horizonY - 40, w, 80);

    ctx.strokeStyle = 'rgba(56, 189, 248, 0.25)';
    ctx.lineWidth = 1.0;
    ctx.beginPath();
    ctx.moveTo(0, horizonY);
    ctx.lineTo(w, horizonY);
    ctx.stroke();
  }

  private render3DVectorRoad(
    ctx: CanvasRenderingContext2D,
    w: number,
    h: number,
    ego: EgoVehicleState,
    simTime: number
  ): void {
    const distances: number[] = [];
    for (let d = 180; d >= 2.0; d -= d > 60 ? 8.0 : d > 25 ? 4.0 : 1.5) {
      distances.push(d);
    }

    for (let i = 0; i < distances.length - 1; i++) {
      const dFar = distances[i];
      const dNear = distances[i + 1];
      const yFar = ego.y + dFar;
      const yNear = ego.y + dNear;

      const splineFar = this.getSplineAt(yFar);
      const splineNear = this.getSplineAt(yNear);
      const halfWFar = (splineFar.width || 10.5) * 0.5;
      const halfWNear = (splineNear.width || 10.5) * 0.5;

      const pFarLeft = this.projectPoint(-halfWFar + splineFar.x, yFar, splineFar.z, ego, w, h);
      const pFarRight = this.projectPoint(halfWFar + splineFar.x, yFar, splineFar.z, ego, w, h);
      const pNearRight = this.projectPoint(halfWNear + splineNear.x, yNear, splineNear.z, ego, w, h);
      const pNearLeft = this.projectPoint(-halfWNear + splineNear.x, yNear, splineNear.z, ego, w, h);

      if (!pFarLeft.visible && !pNearLeft.visible) continue;

      // Road Surface Quad (Tints slightly if road is rough/patched)
      let roadColor = '#0a0f1e';
      if (splineNear.surfaceQuality === 'rough') roadColor = '#0f1524';
      else if (splineNear.surfaceQuality === 'patched') roadColor = '#080d1a';

      ctx.fillStyle = roadColor;
      ctx.beginPath();
      ctx.moveTo(pFarLeft.x, pFarLeft.y);
      ctx.lineTo(pFarRight.x, pFarRight.y);
      ctx.lineTo(pNearRight.x, pNearRight.y);
      ctx.lineTo(pNearLeft.x, pNearLeft.y);
      ctx.closePath();
      ctx.fill();

      // Left Road Boundary (Amber Solid Line)
      ctx.strokeStyle = '#facc15';
      ctx.lineWidth = Math.max(1.0, 3.2 * pNearLeft.scale * 0.04);
      ctx.beginPath();
      ctx.moveTo(pFarLeft.x, pFarLeft.y);
      ctx.lineTo(pNearLeft.x, pNearLeft.y);
      ctx.stroke();

      // Right Road Boundary (White Solid Line)
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.85)';
      ctx.lineWidth = Math.max(1.0, 3.2 * pNearRight.scale * 0.04);
      ctx.beginPath();
      ctx.moveTo(pFarRight.x, pFarRight.y);
      ctx.lineTo(pNearRight.x, pNearRight.y);
      ctx.stroke();

      // Dashed Lane Dividers (proportionate to varying road width: 1/3 and 2/3)
      const isDash = Math.floor(yNear / 6.0) % 2 === 0;
      if (isDash) {
        const xDiv1Far = -halfWFar + splineFar.width / 3 + splineFar.x;
        const xDiv1Near = -halfWNear + splineNear.width / 3 + splineNear.x;
        const pFarDiv1 = this.projectPoint(xDiv1Far, yFar, splineFar.z, ego, w, h);
        const pNearDiv1 = this.projectPoint(xDiv1Near, yNear, splineNear.z, ego, w, h);
        if (pFarDiv1.visible || pNearDiv1.visible) {
          ctx.strokeStyle = 'rgba(241, 245, 249, 0.9)';
          ctx.lineWidth = Math.max(0.8, 2.4 * pNearDiv1.scale * 0.04);
          ctx.beginPath();
          ctx.moveTo(pFarDiv1.x, pFarDiv1.y);
          ctx.lineTo(pNearDiv1.x, pNearDiv1.y);
          ctx.stroke();
        }

        const xDiv2Far = -halfWFar + (splineFar.width * 2) / 3 + splineFar.x;
        const xDiv2Near = -halfWNear + (splineNear.width * 2) / 3 + splineNear.x;
        const pFarDiv2 = this.projectPoint(xDiv2Far, yFar, splineFar.z, ego, w, h);
        const pNearDiv2 = this.projectPoint(xDiv2Near, yNear, splineNear.z, ego, w, h);
        if (pFarDiv2.visible || pNearDiv2.visible) {
          ctx.strokeStyle = 'rgba(241, 245, 249, 0.9)';
          ctx.lineWidth = Math.max(0.8, 2.4 * pNearDiv2.scale * 0.04);
          ctx.beginPath();
          ctx.moveTo(pFarDiv2.x, pFarDiv2.y);
          ctx.lineTo(pNearDiv2.x, pNearDiv2.y);
          ctx.stroke();
        }
      }

      // Zebra crossing at y = 248m
      if (Math.abs(yNear - 248) < 2.0) {
        ctx.fillStyle = 'rgba(255, 255, 255, 0.85)';
        for (let stripeX = -halfWNear * 0.85; stripeX < halfWNear * 0.85; stripeX += 0.9) {
          const p1 = this.projectPoint(stripeX + splineNear.x, yNear, splineNear.z, ego, w, h);
          const p2 = this.projectPoint(stripeX + 0.45 + splineNear.x, yNear, splineNear.z, ego, w, h);
          if (p1.visible && p2.visible) {
            ctx.fillRect(p1.x, p1.y - 2, Math.max(2, p2.x - p1.x), 5);
          }
        }
      }
    }

    // Render Roundabout Square Central Rotary Island (y ~ 212m)
    if (ego.y > 90 && ego.y < 265) {
      this.renderRoundaboutRotarySquare(ctx, w, h, ego, simTime);
    }
  }

  private renderRoundaboutRotarySquare(
    ctx: CanvasRenderingContext2D,
    w: number,
    h: number,
    ego: EgoVehicleState,
    simTime: number
  ): void {
    const centerY = ROUNDABOUT_CENTER_Y;
    const islandRadius = ROUNDABOUT_ISLAND_RADIUS;
    const splineCenter = this.getSplineAt(centerY);
    const centerX = splineCenter.x;

    // Draw central circular island with 3D projection
    const segments = 24;
    const islandPoints: { x: number; y: number }[] = [];

    for (let i = 0; i < segments; i++) {
      const angle = (i / segments) * Math.PI * 2;
      const wx = centerX + Math.cos(angle) * islandRadius;
      const wy = centerY + Math.sin(angle) * islandRadius;
      const pt = this.projectPoint(wx, wy, 0.25, ego, w, h);
      if (pt.visible) {
        islandPoints.push(pt);
      }
    }

    if (islandPoints.length >= 8) {
      // Rotary Landscaped Garden Interior
      ctx.save();
      ctx.fillStyle = '#14532d';
      ctx.beginPath();
      ctx.moveTo(islandPoints[0].x, islandPoints[0].y);
      for (let i = 1; i < islandPoints.length; i++) {
        ctx.lineTo(islandPoints[i].x, islandPoints[i].y);
      }
      ctx.closePath();
      ctx.fill();

      // Alternating Striped Curbs (Yellow & Black)
      ctx.strokeStyle = '#eab308';
      ctx.lineWidth = 4.0;
      ctx.setLineDash([12, 12]);
      ctx.stroke();

      ctx.strokeStyle = '#0f172a';
      ctx.lineDashOffset = 12;
      ctx.stroke();
      ctx.setLineDash([]);

      // Central Smart Rotary Monument / Pillar
      const pCenter = this.projectPoint(centerX, centerY, 1.8, ego, w, h);
      const pBase = this.projectPoint(centerX, centerY, 0.3, ego, w, h);
      if (pCenter.visible && pBase.visible) {
        const pillarW = 0.8 * pCenter.scale;
        const pillarH = pBase.y - pCenter.y;

        // Pillar column
        ctx.fillStyle = '#1e293b';
        ctx.fillRect(pCenter.x - pillarW * 0.5, pCenter.y, pillarW, pillarH);

        // Glowing Blue/Cyan Beacon ring on top
        ctx.fillStyle = '#06b6d4';
        ctx.shadowColor = '#06b6d4';
        ctx.shadowBlur = 12;
        ctx.beginPath();
        ctx.ellipse(pCenter.x, pCenter.y, pillarW * 0.8, pillarW * 0.35, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.shadowBlur = 0;

        // Digital sign text
        ctx.fillStyle = '#ffffff';
        ctx.font = `bold ${Math.max(7, Math.floor(pillarW * 0.28))}px monospace`;
        ctx.textAlign = 'center';
        ctx.fillText('CHOWK ROUNDABOUT', pCenter.x, pCenter.y + pillarH * 0.45);
        ctx.fillStyle = '#38bdf8';
        ctx.font = `${Math.max(6, Math.floor(pillarW * 0.22))}px sans-serif`;
        ctx.fillText('KEEP LEFT  CIRCULATION', pCenter.x, pCenter.y + pillarH * 0.65);
      }

      ctx.restore();
    }
  }

  private renderPlannedTrajectoryRibbon(
    ctx: CanvasRenderingContext2D,
    w: number,
    h: number,
    ego: EgoVehicleState,
    simTime: number
  ): void {
    const ribbonHalfW = 0.85;
    ctx.save();

    const pointsLeft: { x: number; y: number }[] = [];
    const pointsRight: { x: number; y: number }[] = [];

    for (let dy = 2.0; dy <= 48.0; dy += 2.0) {
      const worldY = ego.y + dy;
      const targetLaneX = getLaneCenter(ego.targetLane, worldY);
      const blend = Math.min(1.0, dy / 16.0);
      const worldX = ego.x + (targetLaneX - ego.x) * blend;
      const spline = this.getSplineAt(worldY);

      const pLeft = this.projectPoint(worldX - ribbonHalfW, worldY, spline.z + 0.03, ego, w, h);
      const pRight = this.projectPoint(worldX + ribbonHalfW, worldY, spline.z + 0.03, ego, w, h);

      if (pLeft.visible && pRight.visible) {
        pointsLeft.push({ x: pLeft.x, y: pLeft.y });
        pointsRight.push({ x: pRight.x, y: pRight.y });
      }
    }

    if (pointsLeft.length > 2) {
      const trajGrad = ctx.createLinearGradient(0, pointsLeft[0].y, 0, pointsLeft[pointsLeft.length - 1].y);
      trajGrad.addColorStop(0, 'rgba(34, 197, 94, 0.45)');
      trajGrad.addColorStop(0.5, 'rgba(56, 189, 248, 0.35)');
      trajGrad.addColorStop(1, 'rgba(56, 189, 248, 0.05)');

      ctx.fillStyle = trajGrad;
      ctx.beginPath();
      ctx.moveTo(pointsLeft[0].x, pointsLeft[0].y);
      for (let i = 1; i < pointsLeft.length; i++) {
        ctx.lineTo(pointsLeft[i].x, pointsLeft[i].y);
      }
      for (let i = pointsRight.length - 1; i >= 0; i--) {
        ctx.lineTo(pointsRight[i].x, pointsRight[i].y);
      }
      ctx.closePath();
      ctx.fill();

      // Chevrons
      ctx.strokeStyle = '#22c55e';
      ctx.lineWidth = 2.0;
      ctx.setLineDash([8, 6]);
      ctx.lineDashOffset = -simTime * 24.0;
      ctx.beginPath();
      for (let i = 0; i < pointsLeft.length; i++) {
        const mx = (pointsLeft[i].x + pointsRight[i].x) * 0.5;
        const my = (pointsLeft[i].y + pointsRight[i].y) * 0.5;
        if (i === 0) ctx.moveTo(mx, my);
        else ctx.lineTo(mx, my);
      }
      ctx.stroke();
    }

    ctx.restore();
  }

  private renderSensorPerceptionBeams(
    ctx: CanvasRenderingContext2D,
    w: number,
    h: number,
    ego: EgoVehicleState,
    simTime: number
  ): void {
    ctx.save();

    // Volumetric Forward Radar/Camera Frustum
    const pEgoFront = this.projectPoint(ego.x, ego.y + 2.2, 0.5, ego, w, h);
    const pLeftBeam = this.projectPoint(ego.x - 7.5, ego.y + 65, 0.0, ego, w, h);
    const pRightBeam = this.projectPoint(ego.x + 7.5, ego.y + 65, 0.0, ego, w, h);

    if (pEgoFront.visible && pLeftBeam.visible && pRightBeam.visible) {
      const beamGrad = ctx.createRadialGradient(
        pEgoFront.x,
        pEgoFront.y,
        10,
        pEgoFront.x,
        pEgoFront.y,
        Math.abs(pLeftBeam.y - pEgoFront.y) * 1.2
      );
      beamGrad.addColorStop(0, 'rgba(56, 189, 248, 0.22)');
      beamGrad.addColorStop(0.4, 'rgba(14, 165, 233, 0.08)');
      beamGrad.addColorStop(1, 'rgba(14, 165, 233, 0.0)');

      ctx.fillStyle = beamGrad;
      ctx.beginPath();
      ctx.moveTo(pEgoFront.x, pEgoFront.y);
      ctx.lineTo(pLeftBeam.x, pLeftBeam.y);
      ctx.lineTo(pRightBeam.x, pRightBeam.y);
      ctx.closePath();
      ctx.fill();

      // Outer laser scan lines
      ctx.strokeStyle = 'rgba(56, 189, 248, 0.40)';
      ctx.lineWidth = 1.2;
      ctx.setLineDash([4, 4]);
      ctx.lineDashOffset = -simTime * 15;
      ctx.beginPath();
      ctx.moveTo(pEgoFront.x, pEgoFront.y);
      ctx.lineTo(pLeftBeam.x, pLeftBeam.y);
      ctx.moveTo(pEgoFront.x, pEgoFront.y);
      ctx.lineTo(pRightBeam.x, pRightBeam.y);
      ctx.stroke();
      ctx.setLineDash([]);
    }

    // Concentric LiDAR Ground Scan Ring Pulses
    const ringRanges = [12, 24, 38, 56];
    const pulseOffset = (simTime * 6.0) % 15.0;

    for (const r of ringRanges) {
      const currentRadius = r + pulseOffset * 0.5;
      const ringPoints: { x: number; y: number }[] = [];

      for (let angle = 0; angle <= Math.PI; angle += Math.PI / 16) {
        const wx = ego.x + Math.cos(angle) * currentRadius * 0.45;
        const wy = ego.y + Math.sin(angle) * currentRadius;
        const pt = this.projectPoint(wx, wy, 0.02, ego, w, h);
        if (pt.visible) ringPoints.push(pt);
      }

      if (ringPoints.length > 3) {
        ctx.strokeStyle = `rgba(56, 189, 248, ${Math.max(0.08, 0.35 - currentRadius * 0.004)})`;
        ctx.lineWidth = 1.0;
        ctx.beginPath();
        ctx.moveTo(ringPoints[0].x, ringPoints[0].y);
        for (let k = 1; k < ringPoints.length; k++) {
          ctx.lineTo(ringPoints[k].x, ringPoints[k].y);
        }
        ctx.stroke();
      }
    }

    // Ultrasonic Bumper Proximity Waves
    if (pEgoFront.visible) {
      const arcRadius = 24 + Math.sin(simTime * 12) * 4;
      ctx.strokeStyle = 'rgba(56, 189, 248, 0.65)';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.arc(pEgoFront.x, pEgoFront.y, arcRadius, -Math.PI * 0.8, -Math.PI * 0.2);
      ctx.stroke();
    }

    ctx.restore();
  }

  private renderTrafficAndHazards(
    ctx: CanvasRenderingContext2D,
    w: number,
    h: number,
    ego: EgoVehicleState,
    hazards: HazardObject[],
    simTime: number,
    settings: any
  ): void {
    interface RenderableItem {
      distY: number;
      draw: () => void;
    }
    const items: RenderableItem[] = [];

    // Ambient Traffic
    for (const v of this.ambientVehicles) {
      const relY = v.y - ego.y;
      if (relY < 1.0 || relY > 160) continue;

      items.push({
        distY: relY,
        draw: () => {
          const spline = this.getSplineAt(v.y);
          const pt = this.projectPoint(v.x + spline.x * 0.3, v.y, spline.z, ego, w, h);
          if (!pt.visible) return;

          if (v.type === 'truck') {
            this.render3DTruck(ctx, pt.x, pt.y, pt.scale, v, relY);
          } else if (v.type === 'motorcycle') {
            this.render3DMotorcycle(ctx, pt.x, pt.y, pt.scale, v, relY);
          } else if (v.type === 'scooter') {
            this.render3DScooter(ctx, pt.x, pt.y, pt.scale, v, relY);
          } else if (v.type === 'rickshaw') {
            this.render3DAutoRickshaw(ctx, pt.x, pt.y, pt.scale, v, relY);
          } else {
            this.render3DSedan(ctx, pt.x, pt.y, pt.scale, v, relY);
          }
        },
      });
    }

    // Scenario Hazards
    for (const haz of hazards) {
      if (haz.state === 'cleared') continue;
      const relY = haz.y - ego.y;
      if (relY < 0.5 || relY > 180) continue;

      items.push({
        distY: relY,
        draw: () => {
          const spline = this.getSplineAt(haz.y);
          const pt = this.projectPoint(haz.x + spline.x * 0.3, haz.y, spline.z, ego, w, h);
          if (!pt.visible) return;

          if (haz.type === 'pothole') {
            this.render3DPothole(ctx, pt.x, pt.y, pt.scale, haz, relY);
          } else if (haz.type === 'animal') {
            this.render3DDesiCow(ctx, pt.x, pt.y, pt.scale, haz, relY);
          } else if (haz.type === 'pedestrian') {
            this.render3DPedestrian(ctx, pt.x, pt.y, pt.scale, haz, relY);
          } else if (haz.type === 'vehicle') {
            // Render the Slower Auto-Rickshaw
            this.render3DAutoRickshaw(
              ctx,
              pt.x,
              pt.y,
              pt.scale,
              {
                id: haz.id,
                type: 'rickshaw',
                x: haz.x,
                y: haz.y,
                speed: haz.vy,
                baseSpeed: 4.5,
                color: '#eab308',
                laneChangeTimer: 0,
                targetOffset: haz.x,
                swayPhase: 0,
                heading: haz.heading,
              },
              relY
            );
          }
        },
      });
    }

    // Sort far to near
    items.sort((a, b) => b.distY - a.distY);
    for (const item of items) {
      item.draw();
    }
  }

  private render3DAutoRickshaw(
    ctx: CanvasRenderingContext2D,
    sx: number,
    sy: number,
    scale: number,
    v: AmbientIndianVehicle,
    distMeters: number
  ): void {
    const rw = 1.4 * scale;
    const rh = 1.8 * scale;
    const halfW = rw / 2;

    ctx.save();
    // Drop shadow
    ctx.fillStyle = 'rgba(0, 0, 0, 0.6)';
    ctx.beginPath();
    ctx.ellipse(sx, sy, halfW * 1.1, rw * 0.25, 0, 0, Math.PI * 2);
    ctx.fill();

    // Lower Chassis: Indian Green Body Base
    ctx.fillStyle = '#15803d';
    ctx.fillRect(sx - halfW, sy - rh * 0.45, rw, rh * 0.45);

    // Yellow Canopy Roof
    const roofGrad = ctx.createLinearGradient(sx - halfW, 0, sx + halfW, 0);
    roofGrad.addColorStop(0, '#ca8a04');
    roofGrad.addColorStop(0.4, '#facc15');
    roofGrad.addColorStop(1, '#ca8a04');
    ctx.fillStyle = roofGrad;
    ctx.beginPath();
    ctx.moveTo(sx - halfW * 0.85, sy - rh * 0.95);
    ctx.lineTo(sx + halfW * 0.85, sy - rh * 0.95);
    ctx.lineTo(sx + halfW, sy - rh * 0.42);
    ctx.lineTo(sx - halfW, sy - rh * 0.42);
    ctx.closePath();
    ctx.fill();

    // Dark rear window
    ctx.fillStyle = '#0f172a';
    ctx.fillRect(sx - halfW * 0.6, sy - rh * 0.82, rw * 0.6, rh * 0.32);

    // Tail lamp
    ctx.fillStyle = '#dc2626';
    ctx.fillRect(sx - halfW * 0.8, sy - rh * 0.2, rw * 0.2, rh * 0.12);
    ctx.fillRect(sx + halfW * 0.6, sy - rh * 0.2, rw * 0.2, rh * 0.12);

    ctx.restore();

    this.draw3DPerceptionBracket(ctx, sx, sy, rw, rh, 'AUTO-RICKSHAW', Math.round(v.speed * 3.6), distMeters);
  }

  private render3DTruck(
    ctx: CanvasRenderingContext2D,
    sx: number,
    sy: number,
    scale: number,
    v: AmbientIndianVehicle,
    distMeters: number
  ): void {
    const tw = 2.4 * scale;
    const th = 2.8 * scale;
    const halfW = tw / 2;

    ctx.save();
    ctx.fillStyle = 'rgba(0, 0, 0, 0.65)';
    ctx.beginPath();
    ctx.ellipse(sx, sy, halfW * 1.05, tw * 0.2, 0, 0, Math.PI * 2);
    ctx.fill();

    // Cargo Container Body
    ctx.fillStyle = v.color;
    ctx.fillRect(sx - halfW, sy - th * 0.88, tw, th * 0.7);

    // Stripes
    ctx.fillStyle = '#facc15';
    ctx.fillRect(sx - halfW, sy - th * 0.55, tw, 3);
    ctx.fillStyle = '#ef4444';
    ctx.fillRect(sx - halfW, sy - th * 0.48, tw, 3);

    // Lettering
    ctx.fillStyle = '#ffffff';
    ctx.font = `bold ${Math.max(6, Math.floor(th * 0.08))}px monospace`;
    ctx.textAlign = 'center';
    ctx.fillText('HORN OK PLEASE', sx, sy - th * 0.62);

    ctx.restore();

    this.draw3DPerceptionBracket(ctx, sx, sy, tw, th, 'HEAVY TRUCK', Math.round(v.speed * 3.6), distMeters);
  }

  private render3DSedan(
    ctx: CanvasRenderingContext2D,
    sx: number,
    sy: number,
    scale: number,
    v: AmbientIndianVehicle,
    distMeters: number
  ): void {
    const cw = 1.8 * scale;
    const ch = 1.5 * scale;
    const halfW = cw / 2;

    ctx.save();
    ctx.fillStyle = 'rgba(0, 0, 0, 0.6)';
    ctx.beginPath();
    ctx.ellipse(sx, sy, halfW * 1.1, cw * 0.22, 0, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = v.color;
    ctx.fillRect(sx - halfW, sy - ch * 0.65, cw, ch * 0.55);

    ctx.fillStyle = '#0f172a';
    ctx.fillRect(sx - halfW * 0.75, sy - ch * 0.95, cw * 0.75, ch * 0.35);

    ctx.fillStyle = '#dc2626';
    ctx.fillRect(sx - halfW * 0.8, sy - ch * 0.2, cw * 0.8, ch * 0.1);

    ctx.restore();

    this.draw3DPerceptionBracket(ctx, sx, sy, cw, ch, 'SEDAN', Math.round(v.speed * 3.6), distMeters);
  }

  private render3DMotorcycle(
    ctx: CanvasRenderingContext2D,
    sx: number,
    sy: number,
    scale: number,
    v: AmbientIndianVehicle,
    distMeters: number
  ): void {
    const mw = 0.9 * scale;
    const mh = 1.6 * scale;
    const halfW = mw / 2;

    ctx.save();
    // Drop shadow
    ctx.fillStyle = 'rgba(0, 0, 0, 0.6)';
    ctx.beginPath();
    ctx.ellipse(sx, sy, halfW * 1.1, mw * 0.35, 0, 0, Math.PI * 2);
    ctx.fill();

    // Rear Wheel / Tire
    ctx.fillStyle = '#0f172a';
    ctx.beginPath();
    ctx.roundRect(sx - halfW * 0.28, sy - mh * 0.38, mw * 0.56, mh * 0.36, 4);
    ctx.fill();

    // Chrome Exhaust pipe (bottom right)
    ctx.fillStyle = '#cbd5e1';
    ctx.fillRect(sx + halfW * 0.32, sy - mh * 0.28, mw * 0.22, mh * 0.08);

    // Bike Frame & Tail Fender
    ctx.fillStyle = '#1e293b';
    ctx.fillRect(sx - halfW * 0.55, sy - mh * 0.62, mw * 1.1, mh * 0.25);

    // Fuel Tank / Side Fairing (colored)
    ctx.fillStyle = v.color;
    ctx.beginPath();
    ctx.roundRect(sx - halfW * 0.45, sy - mh * 0.72, mw * 0.9, mh * 0.16, 3);
    ctx.fill();

    // Red LED Taillight & Amber indicators
    ctx.fillStyle = '#ef4444';
    ctx.fillRect(sx - halfW * 0.3, sy - mh * 0.58, mw * 0.6, 3);
    ctx.fillStyle = '#f59e0b';
    ctx.fillRect(sx - halfW * 0.65, sy - mh * 0.58, 3, 3);
    ctx.fillRect(sx + halfW * 0.65 - 3, sy - mh * 0.58, 3, 3);

    // Rider Torso (dark jacket)
    ctx.fillStyle = '#1e293b';
    ctx.beginPath();
    ctx.roundRect(sx - halfW * 0.65, sy - mh * 0.98, mw * 1.3, mh * 0.38, 5);
    ctx.fill();

    // Rider Helmet (matching color or safety helmet)
    ctx.fillStyle = v.color;
    ctx.beginPath();
    ctx.arc(sx, sy - mh * 1.12, mw * 0.38, 0, Math.PI * 2);
    ctx.fill();

    // Dark Visor
    ctx.fillStyle = '#09090b';
    ctx.fillRect(sx - halfW * 0.3, sy - mh * 1.14, mw * 0.6, 3);

    // Delivery Box (if delivery bike)
    if (v.subType === 'delivery') {
      const boxW = mw * 1.05;
      const boxH = mh * 0.32;
      ctx.fillStyle = '#ea580c'; // Food delivery bright thermal box
      ctx.fillRect(sx - boxW * 0.5, sy - mh * 0.88, boxW, boxH);
      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = 1.0;
      ctx.strokeRect(sx - boxW * 0.5, sy - mh * 0.88, boxW, boxH);
      ctx.fillStyle = '#ffffff';
      ctx.font = `bold ${Math.max(5, Math.floor(scale * 0.08))}px sans-serif`;
      ctx.textAlign = 'center';
      ctx.fillText('EXPRESS', sx, sy - mh * 0.72);
    }

    ctx.restore();

    const label = v.subType === 'delivery' ? '2-WHEELER (DELIVERY)' : v.subType === 'cruiser' ? '2-WHEELER (CRUISER)' : '2-WHEELER (BIKE)';
    this.draw3DPerceptionBracket(ctx, sx, sy - mh * 0.3, mw * 1.3, mh * 1.2, label, Math.round(v.speed * 3.6), distMeters);
  }

  private render3DScooter(
    ctx: CanvasRenderingContext2D,
    sx: number,
    sy: number,
    scale: number,
    v: AmbientIndianVehicle,
    distMeters: number
  ): void {
    const sw = 0.95 * scale;
    const sh = 1.5 * scale;
    const halfW = sw / 2;

    ctx.save();
    // Drop shadow
    ctx.fillStyle = 'rgba(0, 0, 0, 0.6)';
    ctx.beginPath();
    ctx.ellipse(sx, sy, halfW * 1.1, sw * 0.35, 0, 0, Math.PI * 2);
    ctx.fill();

    // Small Rear Wheel
    ctx.fillStyle = '#0f172a';
    ctx.beginPath();
    ctx.roundRect(sx - halfW * 0.25, sy - sh * 0.3, sw * 0.5, sh * 0.28, 4);
    ctx.fill();

    // Curvaceous Rear Cowl (Activa body color)
    ctx.fillStyle = v.color;
    ctx.beginPath();
    ctx.roundRect(sx - halfW * 0.85, sy - sh * 0.65, sw * 1.7, sh * 0.38, 8);
    ctx.fill();

    // Chrome Grab Rail
    ctx.strokeStyle = '#cbd5e1';
    ctx.lineWidth = Math.max(1.2, scale * 0.03);
    ctx.beginPath();
    ctx.arc(sx, sy - sh * 0.68, sw * 0.5, Math.PI, 0);
    ctx.stroke();

    // Tail Lamp Cluster
    ctx.fillStyle = '#dc2626';
    ctx.fillRect(sx - halfW * 0.4, sy - sh * 0.52, sw * 0.8, 4);
    ctx.fillStyle = '#f59e0b';
    ctx.fillRect(sx - halfW * 0.75, sy - sh * 0.52, 4, 4);
    ctx.fillRect(sx + halfW * 0.75 - 4, sy - sh * 0.52, 4, 4);

    // Rider Torso
    ctx.fillStyle = '#334155';
    ctx.beginPath();
    ctx.roundRect(sx - halfW * 0.6, sy - sh * 0.95, sw * 1.2, sh * 0.35, 6);
    ctx.fill();

    // Rider Helmet
    ctx.fillStyle = '#e2e8f0';
    ctx.beginPath();
    ctx.arc(sx, sy - sh * 1.08, sw * 0.34, 0, Math.PI * 2);
    ctx.fill();

    // Pillion passenger (if present)
    if (v.subType === 'pillion') {
      ctx.fillStyle = '#475569';
      ctx.beginPath();
      ctx.roundRect(sx - halfW * 0.55, sy - sh * 0.82, sw * 1.1, sh * 0.32, 5);
      ctx.fill();

      ctx.fillStyle = '#facc15'; // Yellow helmet
      ctx.beginPath();
      ctx.arc(sx, sy - sh * 0.94, sw * 0.32, 0, Math.PI * 2);
      ctx.fill();
    }

    ctx.restore();

    this.draw3DPerceptionBracket(ctx, sx, sy - sh * 0.25, sw * 1.4, sh * 1.1, '2-WHEELER (SCOOTER)', Math.round(v.speed * 3.6), distMeters);
  }

  private render3DDesiCow(
    ctx: CanvasRenderingContext2D,
    sx: number,
    sy: number,
    scale: number,
    haz: HazardObject,
    distMeters: number
  ): void {
    const cw = 2.4 * scale;
    const ch = 1.6 * scale;
    const halfW = cw / 2;

    ctx.save();
    ctx.fillStyle = 'rgba(0, 0, 0, 0.65)';
    ctx.beginPath();
    ctx.ellipse(sx, sy, halfW * 0.9, ch * 0.2, 0, 0, Math.PI * 2);
    ctx.fill();

    // Torso
    ctx.fillStyle = '#e7e5e4';
    ctx.beginPath();
    ctx.ellipse(sx, sy - ch * 0.5, halfW * 0.8, ch * 0.35, 0, 0, Math.PI * 2);
    ctx.fill();

    // Zebu Hump
    ctx.fillStyle = '#d6d3d1';
    ctx.beginPath();
    ctx.ellipse(sx - halfW * 0.2, sy - ch * 0.82, halfW * 0.25, ch * 0.2, 0, 0, Math.PI * 2);
    ctx.fill();

    // Head
    ctx.fillStyle = '#f5f5f4';
    ctx.beginPath();
    ctx.ellipse(sx - halfW * 0.65, sy - ch * 0.65, halfW * 0.25, ch * 0.22, 0, 0, Math.PI * 2);
    ctx.fill();

    // Horns
    ctx.strokeStyle = '#1c1917';
    ctx.lineWidth = Math.max(1.2, 2.0 * scale * 0.04);
    ctx.beginPath();
    ctx.moveTo(sx - halfW * 0.6, sy - ch * 0.75);
    ctx.quadraticCurveTo(sx - halfW * 0.85, sy - ch * 1.05, sx - halfW * 0.7, sy - ch * 1.15);
    ctx.stroke();

    ctx.restore();

    this.draw3DPerceptionBracket(ctx, sx, sy, cw, ch, 'ANIMAL (CATTLE)', 3, distMeters, true);
  }

  private render3DPedestrian(
    ctx: CanvasRenderingContext2D,
    sx: number,
    sy: number,
    scale: number,
    haz: HazardObject,
    distMeters: number
  ): void {
    const pw = 0.65 * scale;
    const ph = 1.7 * scale;

    ctx.save();
    ctx.fillStyle = 'rgba(0, 0, 0, 0.55)';
    ctx.beginPath();
    ctx.ellipse(sx, sy, pw * 0.6, pw * 0.25, 0, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = '#38bdf8';
    ctx.fillRect(sx - pw * 0.35, sy - ph * 0.7, pw * 0.7, ph * 0.4);

    ctx.fillStyle = '#0f172a';
    ctx.fillRect(sx - pw * 0.3, sy - ph * 0.3, pw * 0.25, ph * 0.3);
    ctx.fillRect(sx + pw * 0.05, sy - ph * 0.3, pw * 0.25, ph * 0.3);

    ctx.fillStyle = '#fed7aa';
    ctx.beginPath();
    ctx.arc(sx, sy - ph * 0.85, pw * 0.28, 0, Math.PI * 2);
    ctx.fill();

    ctx.restore();

    this.draw3DPerceptionBracket(ctx, sx, sy, pw, ph, 'PEDESTRIAN', 4, distMeters, true);
  }

  private render3DPothole(
    ctx: CanvasRenderingContext2D,
    sx: number,
    sy: number,
    scale: number,
    haz: HazardObject,
    distMeters: number
  ): void {
    const pw = 2.0 * scale;
    const ph = 0.7 * scale;

    ctx.save();
    ctx.strokeStyle = distMeters < 25 ? 'rgba(239, 68, 68, 0.85)' : 'rgba(245, 158, 11, 0.75)';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.ellipse(sx, sy, pw * 0.65, ph * 0.65, 0, 0, Math.PI * 2);
    ctx.stroke();

    ctx.fillStyle = '#020617';
    ctx.beginPath();
    ctx.ellipse(sx, sy, pw * 0.5, ph * 0.5, 0, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = 'rgba(15, 23, 42, 0.85)';
    ctx.fillRect(sx - 48, sy - ph * 0.8 - 14, 96, 13);
    ctx.fillStyle = '#ef4444';
    ctx.font = '8px "JetBrains Mono", monospace';
    ctx.textAlign = 'center';
    ctx.fillText(`POTHOLE | ${Math.round(distMeters)}m`, sx, sy - ph * 0.8 - 5);

    ctx.restore();
  }

  private draw3DPerceptionBracket(
    ctx: CanvasRenderingContext2D,
    sx: number,
    sy: number,
    w: number,
    h: number,
    label: string,
    speedKmh: number,
    distMeters: number,
    isWarning = false
  ): void {
    const boxW = Math.max(34, w * 1.15);
    const boxH = Math.max(34, h * 1.15);
    const halfBW = boxW / 2;
    const topY = sy - boxH;

    ctx.save();
    ctx.strokeStyle = isWarning
      ? 'rgba(239, 68, 68, 0.85)'
      : 'rgba(56, 189, 248, 0.75)';
    ctx.lineWidth = 1.2;
    const corner = 5;

    ctx.beginPath();
    ctx.moveTo(sx - halfBW, topY + corner);
    ctx.lineTo(sx - halfBW, topY);
    ctx.lineTo(sx - halfBW + corner, topY);

    ctx.moveTo(sx + halfBW - corner, topY);
    ctx.lineTo(sx + halfBW, topY);
    ctx.lineTo(sx + halfBW, topY + corner);

    ctx.moveTo(sx - halfBW, sy - corner);
    ctx.lineTo(sx - halfBW, sy);
    ctx.lineTo(sx - halfBW + corner, sy);

    ctx.moveTo(sx + halfBW - corner, sy);
    ctx.lineTo(sx + halfBW, sy);
    ctx.lineTo(sx + halfBW, sy - corner);
    ctx.stroke();

    ctx.fillStyle = 'rgba(2, 6, 23, 0.85)';
    ctx.fillRect(sx - halfBW, topY - 14, Math.max(76, boxW), 12);
    ctx.fillStyle = isWarning ? '#ef4444' : '#38bdf8';
    ctx.font = '8px "JetBrains Mono", monospace';
    ctx.textAlign = 'left';
    ctx.fillText(`${label} ${Math.round(distMeters)}m`, sx - halfBW + 3, topY - 5);
    ctx.restore();
  }

  private renderBlackAutonomousCarModel(
    ctx: CanvasRenderingContext2D,
    w: number,
    h: number,
    ego: EgoVehicleState,
    simTime: number
  ): void {
    ctx.save();

    const carSx = w * 0.5;
    const carSy = h * 0.82 + (ego.pitch || 0) * 45;
    const carW = 165;
    const carH = 88;
    const halfW = carW / 2;
    const rollAngle = -ego.steeringAngle * 0.08;

    ctx.translate(carSx, carSy);
    ctx.rotate(rollAngle);

    // 1. Drop shadow & Aura
    ctx.fillStyle = 'rgba(0, 0, 0, 0.75)';
    ctx.beginPath();
    ctx.ellipse(0, carH * 0.35, halfW * 1.15, carH * 0.3, 0, 0, Math.PI * 2);
    ctx.fill();

    const underglow = ctx.createRadialGradient(0, carH * 0.2, 10, 0, carH * 0.2, halfW * 1.1);
    underglow.addColorStop(0, 'rgba(56, 189, 248, 0.25)');
    underglow.addColorStop(0.5, 'rgba(14, 165, 233, 0.08)');
    underglow.addColorStop(1, 'rgba(14, 165, 233, 0)');
    ctx.fillStyle = underglow;
    ctx.beginPath();
    ctx.ellipse(0, carH * 0.2, halfW * 1.25, carH * 0.35, 0, 0, Math.PI * 2);
    ctx.fill();

    // 2. Rear Tires
    ctx.fillStyle = '#09090b';
    ctx.beginPath();
    ctx.roundRect(-halfW * 0.95, carH * 0.15, 24, 42, 6);
    ctx.roundRect(halfW * 0.95 - 24, carH * 0.15, 24, 42, 6);
    ctx.fill();

    // 3. Body Shell
    const bodyGrad = ctx.createLinearGradient(-halfW, 0, halfW, 0);
    bodyGrad.addColorStop(0.0, '#020617');
    bodyGrad.addColorStop(0.15, '#0f172a');
    bodyGrad.addColorStop(0.48, '#1e293b');
    bodyGrad.addColorStop(0.52, '#334155');
    bodyGrad.addColorStop(0.85, '#0f172a');
    bodyGrad.addColorStop(1.0, '#020617');
    ctx.fillStyle = bodyGrad;

    ctx.beginPath();
    ctx.moveTo(-halfW * 0.88, carH * 0.42);
    ctx.lineTo(halfW * 0.88, carH * 0.42);
    ctx.quadraticCurveTo(halfW, carH * 0.4, halfW, carH * 0.2);
    ctx.lineTo(halfW * 0.92, -carH * 0.1);
    ctx.quadraticCurveTo(halfW * 0.85, -carH * 0.45, halfW * 0.65, -carH * 0.55);
    ctx.lineTo(-halfW * 0.65, -carH * 0.55);
    ctx.quadraticCurveTo(-halfW * 0.85, -carH * 0.45, -halfW * 0.92, -carH * 0.1);
    ctx.lineTo(-halfW, carH * 0.2);
    ctx.quadraticCurveTo(-halfW, carH * 0.4, -halfW * 0.88, carH * 0.42);
    ctx.closePath();
    ctx.fill();

    ctx.strokeStyle = 'rgba(56, 189, 248, 0.45)';
    ctx.lineWidth = 1.0;
    ctx.stroke();

    // 4. Rear Windshield & Glass
    const glassGrad = ctx.createLinearGradient(-halfW * 0.5, -carH * 0.5, halfW * 0.5, 0);
    glassGrad.addColorStop(0, '#020617');
    glassGrad.addColorStop(0.5, '#0f172a');
    glassGrad.addColorStop(0.8, '#1e3a5f');
    glassGrad.addColorStop(1, '#020617');
    ctx.fillStyle = glassGrad;
    ctx.beginPath();
    ctx.moveTo(-halfW * 0.62, -carH * 0.52);
    ctx.lineTo(halfW * 0.62, -carH * 0.52);
    ctx.lineTo(halfW * 0.72, -carH * 0.08);
    ctx.lineTo(-halfW * 0.72, -carH * 0.08);
    ctx.closePath();
    ctx.fill();

    // 5. Roof LiDAR
    const lidarY = -carH * 0.56;
    ctx.fillStyle = '#020617';
    ctx.beginPath();
    ctx.roundRect(-10, lidarY - 6, 20, 10, 4);
    ctx.fill();
    ctx.strokeStyle = '#38bdf8';
    ctx.lineWidth = 1.2;
    ctx.stroke();

    const pulseRad = 2.0 + Math.sin(simTime * 8) * 0.8;
    ctx.fillStyle = '#38bdf8';
    ctx.beginPath();
    ctx.arc(0, lidarY - 1, pulseRad, 0, Math.PI * 2);
    ctx.fill();

    // 6. LED Brake Light Bar
    const isBraking = ego.isBraking;
    if (isBraking) {
      const brakeBloom = ctx.createRadialGradient(0, carH * 0.22, 4, 0, carH * 0.22, 55);
      brakeBloom.addColorStop(0, 'rgba(239, 68, 68, 0.95)');
      brakeBloom.addColorStop(0.4, 'rgba(220, 38, 38, 0.45)');
      brakeBloom.addColorStop(1, 'rgba(220, 38, 38, 0)');
      ctx.fillStyle = brakeBloom;
      ctx.beginPath();
      ctx.ellipse(0, carH * 0.22, halfW * 1.25, 28, 0, 0, Math.PI * 2);
      ctx.fill();

      ctx.fillStyle = '#ff1a1a';
      ctx.beginPath();
      ctx.roundRect(-halfW * 0.84, carH * 0.18, carW * 0.84, 7, 3);
      ctx.fill();

      ctx.fillStyle = '#ff2b2b';
      ctx.fillRect(-18, -carH * 0.50, 36, 4);
    } else {
      ctx.fillStyle = '#dc2626';
      ctx.beginPath();
      ctx.roundRect(-halfW * 0.82, carH * 0.20, carW * 0.82, 4, 2);
      ctx.fill();

      ctx.fillStyle = '#ef4444';
      ctx.fillRect(-halfW * 0.82, carH * 0.18, 18, 7);
      ctx.fillRect(halfW * 0.82 - 18, carH * 0.18, 18, 7);
    }

    // 7. Amber Turn Signal Indicators
    if (ego.indicator !== 'none') {
      const isBlinkOn = Math.floor(simTime * 3.5) % 2 === 0;
      if (isBlinkOn) {
        ctx.fillStyle = '#f59e0b';
        if (ego.indicator === 'left') {
          ctx.beginPath();
          ctx.roundRect(-halfW * 0.88, carH * 0.16, 22, 9, 3);
          ctx.fill();
        } else if (ego.indicator === 'right') {
          ctx.beginPath();
          ctx.roundRect(halfW * 0.88 - 22, carH * 0.16, 22, 9, 3);
          ctx.fill();
        }
      }
    }

    // 8. Diffuser
    ctx.fillStyle = '#09090b';
    ctx.beginPath();
    ctx.roundRect(-halfW * 0.75, carH * 0.36, carW * 0.75, 12, 3);
    ctx.fill();

    ctx.restore();
  }

  private getSplineAt(y: number): RoadSegmentPoint {
    const clampedY = Math.max(0, Math.min(498, y));
    const index = Math.floor(clampedY / 2.0);
    const nextIndex = Math.min(this.roadSpline.length - 1, index + 1);
    const p1 = this.roadSpline[index] || this.roadSpline[0];
    const p2 = this.roadSpline[nextIndex] || p1;
    const t = (clampedY % 2.0) / 2.0;
    return {
      x: p1.x + (p2.x - p1.x) * t,
      y: clampedY,
      z: p1.z + (p2.z - p1.z) * t,
      width: p1.width + (p2.width - p1.width) * t,
      curvature: p1.curvature + (p2.curvature - p1.curvature) * t,
      surfaceQuality: p1.surfaceQuality,
    };
  }
}

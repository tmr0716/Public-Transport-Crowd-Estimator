/**
 * Procedural Pothole and Damaged Asphalt Generator
 */

import { SeededRandom } from '../utils/seededRandom';

export class PotholeRenderer {
  private offscreenCanvas: HTMLCanvasElement;
  private offCtx: CanvasRenderingContext2D;
  private readonly patchSizePx = 180;

  constructor() {
    this.offscreenCanvas = document.createElement('canvas');
    this.offscreenCanvas.width = this.patchSizePx;
    this.offscreenCanvas.height = this.patchSizePx;
    const ctx = this.offscreenCanvas.getContext('2d');
    if (!ctx) throw new Error('Failed to create pothole canvas context');
    this.offCtx = ctx;
    this.generateProceduralDamagedPatch();
  }

  private generateProceduralDamagedPatch(): void {
    const ctx = this.offCtx;
    const rng = new SeededRandom(948271);
    const cx = this.patchSizePx / 2;
    const cy = this.patchSizePx / 2;

    ctx.clearRect(0, 0, this.patchSizePx, this.patchSizePx);

    // 1. Surrounding Cracking Network
    this.drawAlligatorCrackNetwork(ctx, cx, cy, rng);

    // 2. Stress Fractures
    this.drawRadiatingFissures(ctx, cx, cy, rng);

    // 3. Main Pothole Cavity
    this.drawJaggedPotholeCavity(ctx, cx - 2, cy + 2, 22, 16, rng, true);

    // 4. Secondary Adjacent Satellite Pothole
    this.drawJaggedPotholeCavity(ctx, cx + 18, cy - 14, 12, 9, rng, false);

    // 5. Minor third scuff
    this.drawJaggedPotholeCavity(ctx, cx - 14, cy - 12, 7, 5, rng, false);

    // 6. Aggregate pebbles scattered around
    this.drawLooseAggregateScatter(ctx, cx, cy, rng);
  }

  private drawAlligatorCrackNetwork(
    ctx: CanvasRenderingContext2D,
    cx: number,
    cy: number,
    rng: SeededRandom
  ): void {
    ctx.save();
    ctx.strokeStyle = 'rgba(28, 25, 23, 0.75)';
    ctx.lineWidth = 0.8;
    const cellRadius = 45;
    const crackPoints: { x: number; y: number }[] = [];

    for (let i = 0; i < 28; i++) {
      const angle = (i / 28) * Math.PI * 2 + rng.range(-0.15, 0.15);
      const dist = rng.range(18, cellRadius);
      crackPoints.push({
        x: cx + Math.cos(angle) * dist,
        y: cy + Math.sin(angle) * dist,
      });
    }

    ctx.beginPath();
    for (let i = 0; i < crackPoints.length; i++) {
      const p1 = crackPoints[i];
      const p2 = crackPoints[(i + 1) % crackPoints.length];
      const p3 = crackPoints[(i + 4) % crackPoints.length];
      const midX = (p1.x + p2.x) / 2 + rng.range(-3, 3);
      const midY = (p1.y + p2.y) / 2 + rng.range(-3, 3);
      ctx.moveTo(p1.x, p1.y);
      ctx.lineTo(midX, midY);
      ctx.lineTo(p2.x, p2.y);
      if (rng.chance(0.45)) {
        ctx.moveTo(midX, midY);
        ctx.lineTo(p3.x, p3.y);
      }
    }
    ctx.stroke();
    ctx.restore();
  }

  private drawRadiatingFissures(
    ctx: CanvasRenderingContext2D,
    cx: number,
    cy: number,
    rng: SeededRandom
  ): void {
    ctx.save();
    ctx.strokeStyle = 'rgba(23, 23, 23, 0.85)';
    ctx.lineWidth = 1.1;
    const numFissures = 7;

    for (let i = 0; i < numFissures; i++) {
      const angle = (i / numFissures) * Math.PI * 2 + rng.range(-0.3, 0.3);
      let currX = cx + Math.cos(angle) * 16;
      let currY = cy + Math.sin(angle) * 16;
      const length = rng.range(28, 55);
      const steps = 6;
      const stepLen = length / steps;

      ctx.beginPath();
      ctx.moveTo(currX, currY);
      let currAngle = angle;
      for (let s = 0; s < steps; s++) {
        currAngle += rng.range(-0.35, 0.35);
        currX += Math.cos(currAngle) * stepLen;
        currY += Math.sin(currAngle) * stepLen;
        ctx.lineTo(currX, currY);
      }
      ctx.stroke();
    }
    ctx.restore();
  }

  private drawJaggedPotholeCavity(
    ctx: CanvasRenderingContext2D,
    x: number,
    y: number,
    radX: number,
    radY: number,
    rng: SeededRandom,
    isMain: boolean
  ): void {
    ctx.save();
    const numPoints = 22;
    const outerRim: { x: number; y: number }[] = [];
    const innerRim: { x: number; y: number }[] = [];

    for (let i = 0; i < numPoints; i++) {
      const angle = (i / numPoints) * Math.PI * 2;
      const noise = rng.range(0.72, 1.28);
      const rx = (radX + rng.range(-2, 2)) * noise;
      const ry = (radY + rng.range(-2, 2)) * noise;
      outerRim.push({
        x: x + Math.cos(angle) * (rx + 2.5),
        y: y + Math.sin(angle) * (ry + 2.5),
      });
      innerRim.push({
        x: x + Math.cos(angle) * rx,
        y: y + Math.sin(angle) * ry,
      });
    }

    // Fractured rim
    ctx.fillStyle = '#78716c';
    ctx.beginPath();
    ctx.moveTo(outerRim[0].x, outerRim[0].y);
    for (let i = 1; i < outerRim.length; i++) {
      ctx.lineTo(outerRim[i].x, outerRim[i].y);
    }
    ctx.closePath();
    ctx.fill();

    // Depressed Interior
    const interiorGrad = ctx.createLinearGradient(x - radX, y - radY, x + radX, y + radY);
    interiorGrad.addColorStop(0.0, '#1c1917');
    interiorGrad.addColorStop(0.3, '#292524');
    interiorGrad.addColorStop(0.7, '#35302d');
    interiorGrad.addColorStop(1.0, '#44403c');
    ctx.fillStyle = interiorGrad;
    ctx.beginPath();
    ctx.moveTo(innerRim[0].x, innerRim[0].y);
    for (let i = 1; i < innerRim.length; i++) {
      ctx.lineTo(innerRim[i].x, innerRim[i].y);
    }
    ctx.closePath();
    ctx.fill();

    ctx.restore();
  }

  private drawLooseAggregateScatter(
    ctx: CanvasRenderingContext2D,
    cx: number,
    cy: number,
    rng: SeededRandom
  ): void {
    ctx.save();
    for (let i = 0; i < 45; i++) {
      const angle = rng.range(0, Math.PI * 2);
      const dist = rng.range(16, 50);
      const px = cx + Math.cos(angle) * dist;
      const py = cy + Math.sin(angle) * dist;
      ctx.fillStyle = rng.chance(0.6) ? '#292524' : '#a8a29e';
      ctx.fillRect(px, py, rng.range(1.0, 2.4), rng.range(1.0, 2.2));
    }
    ctx.restore();
  }

  public renderPothole(ctx: CanvasRenderingContext2D, screenX: number, screenY: number): void {
    ctx.drawImage(
      this.offscreenCanvas,
      screenX - this.patchSizePx / 2,
      screenY - this.patchSizePx / 2
    );
  }
}

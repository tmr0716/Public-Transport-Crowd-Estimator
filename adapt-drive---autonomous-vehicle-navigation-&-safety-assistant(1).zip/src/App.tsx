import React, { useState, useEffect } from 'react';
import { UserProfile, RouteOption, TripRecord } from './types/app';
import { api } from './services/api';
import { CURATED_ROUTES } from './data/curatedRoutes';
import { AutomotiveAudio } from './utils/audio';
import { TopNavbar } from './components/TopNavbar';
import { AuthScreen } from './components/AuthScreen';
import { DestinationScreen } from './components/DestinationScreen';
import { DriveCockpit } from './components/DriveCockpit';
import { TripSummaryScreen } from './components/TripSummaryScreen';
import { ThemeProvider, useTheme } from './context/ThemeContext';

function MainApp() {
  const { theme } = useTheme();
  const [user, setUser] = useState<UserProfile | null>(null);
  const [currentScreen, setCurrentScreen] = useState<'auth' | 'destination' | 'drive' | 'summary'>('auth');
  const [selectedRoute, setSelectedRoute] = useState<RouteOption>(CURATED_ROUTES[0]);
  const [lastTrip, setLastTrip] = useState<Partial<TripRecord>>({});
  const [loading, setLoading] = useState<boolean>(true);

  // Check persistent session on initial mount
  useEffect(() => {
    AutomotiveAudio.init();
    api.getMe().then((existingUser) => {
      if (existingUser) {
        setUser(existingUser);
        setCurrentScreen('destination');
      } else {
        setCurrentScreen('auth');
      }
      setLoading(false);
    }).catch(() => {
      setCurrentScreen('auth');
      setLoading(false);
    });
  }, []);

  // Auth Success transition
  const handleAuthSuccess = (authenticatedUser: UserProfile) => {
    setUser(authenticatedUser);
    setCurrentScreen('destination');
  };

  // Route selection and start drive
  const handleSelectRouteAndStart = (route: RouteOption) => {
    setSelectedRoute(route);
    setCurrentScreen('drive');
  };

  // Trip Completion
  const handleFinishTrip = async (summaryData: Partial<TripRecord>) => {
    setLastTrip(summaryData);
    if (user) {
      try {
        await api.saveTrip(summaryData);
      } catch (err) {
        console.warn('Trip save failed, using local fallback', err);
      }
    }
    AutomotiveAudio.playSuccessChime();
    setCurrentScreen('summary');
  };

  // Navigation handlers
  const handleStartNewDrive = () => {
    setCurrentScreen('destination');
  };

  const handleReconfigureVehicle = () => {
    setCurrentScreen('auth');
  };

  const handleLogout = () => {
    api.removeToken();
    setUser(null);
    setCurrentScreen('auth');
    AutomotiveAudio.playChime(600, 1);
  };

  if (loading) {
    return (
      <div className={`h-screen w-screen flex flex-col items-center justify-center ${
        theme === 'dark' ? 'bg-slate-950 text-slate-300' : 'bg-slate-100 text-slate-700'
      }`}>
        <div className="w-10 h-10 border-2 border-blue-500 border-t-transparent rounded-full animate-spin mb-4" />
        <span className="font-mono text-xs uppercase tracking-widest text-slate-400">
          ADAPT-Drive Telemetry Initializing...
        </span>
      </div>
    );
  }

  return (
    <div className={`flex flex-col h-screen w-screen overflow-hidden font-sans transition-colors duration-150 ${
      theme === 'dark' ? 'bg-slate-950 text-slate-100' : 'bg-slate-100 text-slate-900'
    }`}>
      {/* Top Cockpit Status Header (without manual screen tabs) */}
      <TopNavbar
        currentScreen={currentScreen}
        user={user}
        onLogout={handleLogout}
        driveStatusText="ADAPTIVE AUTOPILOT ENGAGED"
      />

      {/* Main Screen Router */}
      <main className="flex-1 flex overflow-hidden">
        {currentScreen === 'auth' && (
          <AuthScreen onAuthSuccess={handleAuthSuccess} />
        )}

        {currentScreen === 'destination' && user && (
          <DestinationScreen
            user={user}
            onSelectRouteAndStart={handleSelectRouteAndStart}
          />
        )}

        {currentScreen === 'drive' && user && (
          <DriveCockpit
            user={user}
            selectedRoute={selectedRoute}
            onFinishTrip={handleFinishTrip}
          />
        )}

        {currentScreen === 'summary' && user && (
          <TripSummaryScreen
            user={user}
            lastTrip={lastTrip}
            onStartNewDrive={handleStartNewDrive}
            onReconfigureVehicle={handleReconfigureVehicle}
          />
        )}
      </main>
    </div>
  );
}

export default function App() {
  return (
    <ThemeProvider>
      <MainApp />
    </ThemeProvider>
  );
}

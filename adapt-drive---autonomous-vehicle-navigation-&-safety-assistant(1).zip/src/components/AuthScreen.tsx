import React, { useState } from 'react';
import { UserProfile, VehicleProfile } from '../types/app';
import { api } from '../services/api';
import { AutomotiveAudio } from '../utils/audio';
import { useTheme } from '../context/ThemeContext';
import { ShieldCheck, User, Lock, Phone, Mail, ArrowRight, ArrowLeft, Check, Sparkles, AlertCircle } from 'lucide-react';

interface AuthScreenProps {
  onAuthSuccess: (user: UserProfile) => void;
}

const VEHICLE_PRESETS: Record<'suv' | 'sedan' | 'hatchback', VehicleProfile> = {
  suv: {
    type: 'suv',
    modelName: 'Production Compact SUV',
    width: 1.82,
    length: 4.25,
    turningRadius: 5.2,
    brakingDist: 13.5,
  },
  sedan: {
    type: 'sedan',
    modelName: 'Executive Sedan',
    width: 1.76,
    length: 4.49,
    turningRadius: 5.0,
    brakingDist: 14.0,
  },
  hatchback: {
    type: 'hatchback',
    modelName: 'City Hatchback',
    width: 1.68,
    length: 3.82,
    turningRadius: 4.8,
    brakingDist: 12.0,
  },
};

export const AuthScreen: React.FC<AuthScreenProps> = ({ onAuthSuccess }) => {
  const { theme } = useTheme();
  const isDark = theme === 'dark';
  const [mode, setMode] = useState<'signin' | 'register'>('signin');
  const [step, setStep] = useState<number>(1);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  // Sign In inputs
  const [loginIdentifier, setLoginIdentifier] = useState('driver@adapt.in');
  const [loginPassword, setLoginPassword] = useState('drive123');

  // Register inputs
  const [regMobile, setRegMobile] = useState('9876543210');
  const [regEmail, setRegEmail] = useState('driver@adapt.in');
  const [regName, setRegName] = useState('Arjun Sharma');
  const [regPassword, setRegPassword] = useState('drive123');

  // Step 2 OTP
  const [otp, setOtp] = useState('4521');
  const [generatedOtp] = useState('4521');

  // Step 3 Vehicle Kinematics
  const [selectedCategory, setSelectedCategory] = useState<'suv' | 'sedan' | 'hatchback'>('suv');
  const [vehWidth, setVehWidth] = useState<number>(1.82);
  const [vehLength, setVehLength] = useState<number>(4.25);
  const [vehTurnRadius, setVehTurnRadius] = useState<number>(5.2);
  const [vehBrakingDist, setVehBrakingDist] = useState<number>(13.5);

  const handleCategorySelect = (cat: 'suv' | 'sedan' | 'hatchback') => {
    setSelectedCategory(cat);
    const preset = VEHICLE_PRESETS[cat];
    setVehWidth(preset.width);
    setVehLength(preset.length);
    setVehTurnRadius(preset.turningRadius);
    setVehBrakingDist(preset.brakingDist);
  };

  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      const { user } = await api.login(loginIdentifier, loginPassword);
      AutomotiveAudio.playSuccessChime();
      onAuthSuccess(user);
    } catch (err: any) {
      setError(err.message || 'Login failed. Please check credentials.');
      AutomotiveAudio.playWarningChime();
    } finally {
      setLoading(false);
    }
  };

  const handleQuickDemo = async () => {
    setError(null);
    setLoading(true);
    try {
      const { user } = await api.quickDemoLogin();
      AutomotiveAudio.playSuccessChime();
      onAuthSuccess(user);
    } catch (err: any) {
      setError('Failed to initiate demo session.');
    } finally {
      setLoading(false);
    }
  };

  const handleRegisterStep1 = (e: React.FormEvent) => {
    e.preventDefault();
    if (!regMobile || regMobile.length < 10) {
      setError('Please provide a valid 10-digit mobile number.');
      return;
    }
    if (!regEmail || !regEmail.includes('@')) {
      setError('Please enter a valid email address.');
      return;
    }
    if (!regPassword || regPassword.length < 4) {
      setError('Driver password must be at least 4 characters long.');
      return;
    }
    setError(null);
    AutomotiveAudio.playChime(750, 1);
    setStep(2);
  };

  const handleVerifyStep2 = () => {
    if (otp === generatedOtp || otp === '4521') {
      setError(null);
      AutomotiveAudio.playSuccessChime();
      setStep(3);
    } else {
      setError('Invalid verification code. Please check code.');
      AutomotiveAudio.playWarningChime();
    }
  };

  const handleFinalRegister = async () => {
    setError(null);
    setLoading(true);
    try {
      const vehicleProfile: VehicleProfile = {
        type: selectedCategory,
        modelName: VEHICLE_PRESETS[selectedCategory].modelName,
        width: Number(vehWidth) || 1.82,
        length: Number(vehLength) || 4.25,
        turningRadius: Number(vehTurnRadius) || 5.2,
        brakingDist: Number(vehBrakingDist) || 13.5,
      };

      const { user } = await api.register({
        email: regEmail,
        phone: regMobile,
        name: regName || regEmail.split('@')[0],
        password: regPassword,
        vehicle: vehicleProfile,
      });
      AutomotiveAudio.playSuccessChime();
      onAuthSuccess(user);
    } catch (err: any) {
      setError(err.message || 'Registration failed.');
      AutomotiveAudio.playWarningChime();
    } finally {
      setLoading(false);
    }
  };

  return (
    <div
      className={`min-h-screen w-full flex flex-col justify-center items-center p-4 select-none transition-colors duration-150 ${
        isDark
          ? 'bg-slate-950 bg-[radial-gradient(ellipse_80%_80%_at_50%_-20%,rgba(37,99,235,0.15),rgba(255,255,255,0))] text-slate-100'
          : 'bg-slate-100 bg-[radial-gradient(ellipse_80%_80%_at_50%_-20%,rgba(37,99,235,0.08),rgba(0,0,0,0))] text-slate-900'
      }`}
    >
      <div
        className={`w-full max-w-xl border rounded-2xl shadow-2xl p-7 md:p-9 relative overflow-hidden transition-colors ${
          isDark
            ? 'bg-slate-900/90 backdrop-blur-xl border-slate-800'
            : 'bg-white border-slate-200 shadow-xl'
        }`}
      >
        <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-blue-600 via-sky-500 to-indigo-600" />

        {/* Top Header */}
        <div className="flex flex-col items-center text-center mb-6">
          <div className="w-12 h-12 rounded-xl bg-blue-600 flex items-center justify-center text-white mb-3 shadow-lg shadow-blue-600/30">
            <ShieldCheck className="w-6 h-6 stroke-[2.2]" />
          </div>
          <h1
            className={`text-xl md:text-2xl font-extrabold tracking-tight uppercase ${
              isDark ? 'text-white' : 'text-slate-900'
            }`}
          >
            ADAPT-Drive Cockpit Access
          </h1>
          <p
            className={`text-xs md:text-sm mt-1 max-w-sm ${
              isDark ? 'text-slate-400' : 'text-slate-600'
            }`}
          >
            Autonomous trajectory planner & collision avoidance telemetry system
          </p>
        </div>

        {/* Tab Selector */}
        <div
          className={`flex p-1 rounded-xl border mb-6 transition-colors ${
            isDark
              ? 'bg-slate-950/80 border-slate-800'
              : 'bg-slate-100 border-slate-200'
          }`}
        >
          <button
            type="button"
            onClick={() => {
              setMode('signin');
              setError(null);
            }}
            className={`flex-1 py-2 text-xs font-semibold rounded-lg transition-all cursor-pointer ${
              mode === 'signin'
                ? 'bg-blue-600 text-white shadow-md'
                : isDark
                ? 'text-slate-400 hover:text-slate-200'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Operator Sign In
          </button>
          <button
            type="button"
            onClick={() => {
              setMode('register');
              setStep(1);
              setError(null);
            }}
            className={`flex-1 py-2 text-xs font-semibold rounded-lg transition-all cursor-pointer ${
              mode === 'register'
                ? 'bg-blue-600 text-white shadow-md'
                : isDark
                ? 'text-slate-400 hover:text-slate-200'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Register Vehicle Profile
          </button>
        </div>

        {error && (
          <div
            className={`mb-5 p-3 rounded-lg border text-xs flex items-center gap-2 ${
              isDark
                ? 'bg-red-950/60 border-red-500/40 text-red-300'
                : 'bg-red-50 border-red-200 text-red-700'
            }`}
          >
            <AlertCircle className="w-4 h-4 text-red-500 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {/* SIGN IN */}
        {mode === 'signin' && (
          <form onSubmit={handleLoginSubmit} className="space-y-4">
            <div>
              <label
                className={`block text-xs font-semibold mb-1.5 ${
                  isDark ? 'text-slate-300' : 'text-slate-700'
                }`}
              >
                Mobile Number or Email Address
              </label>
              <div className="relative">
                <div
                  className={`absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none ${
                    isDark ? 'text-slate-500' : 'text-slate-400'
                  }`}
                >
                  <User className="w-4 h-4" />
                </div>
                <input
                  type="text"
                  value={loginIdentifier}
                  onChange={(e) => setLoginIdentifier(e.target.value)}
                  placeholder="e.g. 9876543210 or driver@adapt.in"
                  required
                  className={`w-full pl-9 pr-3 py-2.5 rounded-lg text-sm focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-all font-mono border ${
                    isDark
                      ? 'bg-slate-950/70 border-slate-700/80 text-white placeholder:text-slate-500'
                      : 'bg-slate-50 border-slate-300 text-slate-900 placeholder:text-slate-400'
                  }`}
                />
              </div>
            </div>

            <div>
              <label
                className={`block text-xs font-semibold mb-1.5 ${
                  isDark ? 'text-slate-300' : 'text-slate-700'
                }`}
              >
                Driver PIN / Password
              </label>
              <div className="relative">
                <div
                  className={`absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none ${
                    isDark ? 'text-slate-500' : 'text-slate-400'
                  }`}
                >
                  <Lock className="w-4 h-4" />
                </div>
                <input
                  type="password"
                  value={loginPassword}
                  onChange={(e) => setLoginPassword(e.target.value)}
                  placeholder="Enter driver password"
                  required
                  className={`w-full pl-9 pr-3 py-2.5 rounded-lg text-sm focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-all font-mono border ${
                    isDark
                      ? 'bg-slate-950/70 border-slate-700/80 text-white placeholder:text-slate-500'
                      : 'bg-slate-50 border-slate-300 text-slate-900 placeholder:text-slate-400'
                  }`}
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3 bg-blue-600 hover:bg-blue-500 active:bg-blue-700 text-white font-semibold rounded-lg shadow-lg shadow-blue-600/30 transition-all flex items-center justify-center gap-2 cursor-pointer text-sm mt-2 disabled:opacity-50"
            >
              <span>{loading ? 'Authenticating...' : 'Sign In & Enter Cockpit'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            {/* Quick Instant Demo Launch */}
            <div
              className={`pt-4 border-t text-center ${
                isDark ? 'border-slate-800' : 'border-slate-200'
              }`}
            >
              <span
                className={`text-xs block mb-2 font-medium ${
                  isDark ? 'text-slate-400' : 'text-slate-500'
                }`}
              >
                Fast Evaluator Shortcut:
              </span>
              <button
                type="button"
                onClick={handleQuickDemo}
                disabled={loading}
                className={`w-full py-2.5 rounded-lg text-xs font-semibold flex items-center justify-center gap-2 transition-all cursor-pointer border ${
                  isDark
                    ? 'bg-slate-800 hover:bg-slate-700 text-sky-300 border-slate-700'
                    : 'bg-sky-50 hover:bg-sky-100 text-sky-700 border-sky-200 shadow-xs'
                }`}
              >
                <Sparkles className="w-4 h-4 text-sky-500" />
                <span>Instant Demo Drive (One-Click Launch)</span>
              </button>
            </div>
          </form>
        )}

        {/* REGISTER */}
        {mode === 'register' && (
          <div>
            <div className="flex items-center justify-between mb-5 px-2">
              <div className="flex items-center gap-2 text-xs">
                <span
                  className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold ${
                    step >= 1
                      ? 'bg-blue-600 text-white'
                      : isDark
                      ? 'bg-slate-800 text-slate-500'
                      : 'bg-slate-200 text-slate-500'
                  }`}
                >
                  1
                </span>
                <span
                  className={
                    step >= 1
                      ? isDark
                        ? 'text-white font-semibold'
                        : 'text-slate-900 font-semibold'
                      : 'text-slate-400'
                  }
                >
                  Driver ID
                </span>
              </div>
              <div
                className={`h-0.5 flex-1 mx-2 ${
                  isDark ? 'bg-slate-800' : 'bg-slate-200'
                }`}
              />
              <div className="flex items-center gap-2 text-xs">
                <span
                  className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold ${
                    step >= 2
                      ? 'bg-blue-600 text-white'
                      : isDark
                      ? 'bg-slate-800 text-slate-500'
                      : 'bg-slate-200 text-slate-500'
                  }`}
                >
                  2
                </span>
                <span
                  className={
                    step >= 2
                      ? isDark
                        ? 'text-white font-semibold'
                        : 'text-slate-900 font-semibold'
                      : 'text-slate-400'
                  }
                >
                  Verification
                </span>
              </div>
              <div
                className={`h-0.5 flex-1 mx-2 ${
                  isDark ? 'bg-slate-800' : 'bg-slate-200'
                }`}
              />
              <div className="flex items-center gap-2 text-xs">
                <span
                  className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold ${
                    step >= 3
                      ? 'bg-blue-600 text-white'
                      : isDark
                      ? 'bg-slate-800 text-slate-500'
                      : 'bg-slate-200 text-slate-500'
                  }`}
                >
                  3
                </span>
                <span
                  className={
                    step >= 3
                      ? isDark
                        ? 'text-white font-semibold'
                        : 'text-slate-900 font-semibold'
                      : 'text-slate-400'
                  }
                >
                  Vehicle Profile
                </span>
              </div>
            </div>

            {step === 1 && (
              <form onSubmit={handleRegisterStep1} className="space-y-3.5">
                <div>
                  <label
                    className={`block text-xs font-semibold mb-1 ${
                      isDark ? 'text-slate-300' : 'text-slate-700'
                    }`}
                  >
                    Driver Full Name
                  </label>
                  <input
                    type="text"
                    value={regName}
                    onChange={(e) => setRegName(e.target.value)}
                    placeholder="e.g. Arjun Sharma"
                    required
                    className={`w-full px-3 py-2 rounded-lg text-sm border focus:outline-none focus:border-blue-500 ${
                      isDark
                        ? 'bg-slate-950/70 border-slate-700/80 text-white placeholder:text-slate-500'
                        : 'bg-slate-50 border-slate-300 text-slate-900 placeholder:text-slate-400'
                    }`}
                  />
                </div>
                <div>
                  <label
                    className={`block text-xs font-semibold mb-1 ${
                      isDark ? 'text-slate-300' : 'text-slate-700'
                    }`}
                  >
                    Mobile Number (+91)
                  </label>
                  <div className="relative">
                    <Phone
                      className={`w-4 h-4 absolute left-3 top-2.5 ${
                        isDark ? 'text-slate-500' : 'text-slate-400'
                      }`}
                    />
                    <input
                      type="tel"
                      value={regMobile}
                      maxLength={10}
                      onChange={(e) => setRegMobile(e.target.value)}
                      placeholder="10-digit mobile number"
                      required
                      className={`w-full pl-9 pr-3 py-2 rounded-lg text-sm font-mono border focus:outline-none focus:border-blue-500 ${
                        isDark
                          ? 'bg-slate-950/70 border-slate-700/80 text-white placeholder:text-slate-500'
                          : 'bg-slate-50 border-slate-300 text-slate-900 placeholder:text-slate-400'
                      }`}
                    />
                  </div>
                </div>
                <div>
                  <label
                    className={`block text-xs font-semibold mb-1 ${
                      isDark ? 'text-slate-300' : 'text-slate-700'
                    }`}
                  >
                    Email Address
                  </label>
                  <div className="relative">
                    <Mail
                      className={`w-4 h-4 absolute left-3 top-2.5 ${
                        isDark ? 'text-slate-500' : 'text-slate-400'
                      }`}
                    />
                    <input
                      type="email"
                      value={regEmail}
                      onChange={(e) => setRegEmail(e.target.value)}
                      placeholder="driver@adapt.in"
                      required
                      className={`w-full pl-9 pr-3 py-2 rounded-lg text-sm font-mono border focus:outline-none focus:border-blue-500 ${
                        isDark
                          ? 'bg-slate-950/70 border-slate-700/80 text-white placeholder:text-slate-500'
                          : 'bg-slate-50 border-slate-300 text-slate-900 placeholder:text-slate-400'
                      }`}
                    />
                  </div>
                </div>
                <div>
                  <label
                    className={`block text-xs font-semibold mb-1 ${
                      isDark ? 'text-slate-300' : 'text-slate-700'
                    }`}
                  >
                    Security Password
                  </label>
                  <div className="relative">
                    <Lock
                      className={`w-4 h-4 absolute left-3 top-2.5 ${
                        isDark ? 'text-slate-500' : 'text-slate-400'
                      }`}
                    />
                    <input
                      type="password"
                      value={regPassword}
                      onChange={(e) => setRegPassword(e.target.value)}
                      placeholder="At least 4 characters"
                      required
                      className={`w-full pl-9 pr-3 py-2 rounded-lg text-sm font-mono border focus:outline-none focus:border-blue-500 ${
                        isDark
                          ? 'bg-slate-950/70 border-slate-700/80 text-white placeholder:text-slate-500'
                          : 'bg-slate-50 border-slate-300 text-slate-900 placeholder:text-slate-400'
                      }`}
                    />
                  </div>
                </div>
                <div className="pt-2">
                  <button
                    type="submit"
                    className="w-full py-2.5 bg-blue-600 hover:bg-blue-500 text-white font-semibold rounded-lg shadow-md transition-all flex items-center justify-center gap-2 text-sm cursor-pointer"
                  >
                    <span>Proceed to Verification</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </form>
            )}

            {step === 2 && (
              <div className="space-y-4">
                <div
                  className={`p-3.5 rounded-xl border text-xs ${
                    isDark
                      ? 'bg-slate-950/60 border-slate-800 text-slate-300'
                      : 'bg-slate-50 border-slate-200 text-slate-700'
                  }`}
                >
                  <p>
                    A security code was sent to registered contact{' '}
                    <strong
                      className={`font-mono ${
                        isDark ? 'text-white' : 'text-slate-900'
                      }`}
                    >
                      +91 {regMobile}
                    </strong>
                    .
                  </p>
                  <div className="mt-2 text-emerald-500 font-medium flex items-center gap-1.5">
                    <Check className="w-3.5 h-3.5" />
                    <span>
                      Auto-filled for demonstration:{' '}
                      <strong className="font-mono">{generatedOtp}</strong>
                    </span>
                  </div>
                </div>
                <div>
                  <label
                    className={`block text-xs font-semibold mb-1.5 ${
                      isDark ? 'text-slate-300' : 'text-slate-700'
                    }`}
                  >
                    4-Digit Verification Code
                  </label>
                  <input
                    type="text"
                    value={otp}
                    onChange={(e) => setOtp(e.target.value)}
                    maxLength={6}
                    className={`w-full text-center py-3 border rounded-lg font-mono text-xl tracking-[0.25em] focus:outline-none focus:border-blue-500 ${
                      isDark
                        ? 'bg-slate-950/90 border-slate-700 text-white'
                        : 'bg-slate-50 border-slate-300 text-slate-900'
                    }`}
                  />
                </div>
                <div className="flex items-center gap-3 pt-2">
                  <button
                    type="button"
                    onClick={() => setStep(1)}
                    className={`px-4 py-2.5 font-medium rounded-lg text-xs flex items-center gap-1.5 cursor-pointer border ${
                      isDark
                        ? 'bg-slate-800 hover:bg-slate-700 text-slate-300 border-slate-700'
                        : 'bg-slate-100 hover:bg-slate-200 text-slate-700 border-slate-200'
                    }`}
                  >
                    <ArrowLeft className="w-3.5 h-3.5" />
                    <span>Back</span>
                  </button>
                  <button
                    type="button"
                    onClick={handleVerifyStep2}
                    className="flex-1 py-2.5 bg-blue-600 hover:bg-blue-500 text-white font-semibold rounded-lg text-xs flex items-center justify-center gap-2 shadow-md cursor-pointer"
                  >
                    <span>Verify & Continue</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            )}

            {step === 3 && (
              <div className="space-y-4">
                <span
                  className={`text-xs font-semibold block ${
                    isDark ? 'text-slate-300' : 'text-slate-700'
                  }`}
                >
                  Select Vehicle Category
                </span>
                <div className="grid grid-cols-3 gap-2">
                  {(['suv', 'sedan', 'hatchback'] as const).map((cat) => {
                    const preset = VEHICLE_PRESETS[cat];
                    const isSel = selectedCategory === cat;
                    return (
                      <button
                        key={cat}
                        type="button"
                        onClick={() => handleCategorySelect(cat)}
                        className={`p-3 rounded-xl border text-center transition-all cursor-pointer ${
                          isSel
                            ? 'bg-blue-600 border-blue-600 text-white shadow-md'
                            : isDark
                            ? 'bg-slate-950/50 border-slate-800 text-slate-400 hover:border-slate-700'
                            : 'bg-slate-50 border-slate-200 text-slate-600 hover:border-slate-300'
                        }`}
                      >
                        <span className="block text-xs font-bold uppercase tracking-wider">
                          {cat}
                        </span>
                        <span
                          className={`text-[10px] mt-0.5 block ${
                            isSel
                              ? 'text-blue-100'
                              : isDark
                              ? 'text-slate-500'
                              : 'text-slate-500'
                          }`}
                        >
                          {preset.modelName}
                        </span>
                      </button>
                    );
                  })}
                </div>

                <div className="grid grid-cols-2 gap-3 pt-1">
                  <div>
                    <label
                      className={`block text-[11px] font-semibold mb-1 ${
                        isDark ? 'text-slate-400' : 'text-slate-600'
                      }`}
                    >
                      Vehicle Width (m)
                    </label>
                    <input
                      type="number"
                      step="0.01"
                      value={vehWidth}
                      onChange={(e) => setVehWidth(parseFloat(e.target.value))}
                      className={`w-full px-3 py-1.5 border rounded-lg text-xs font-mono ${
                        isDark
                          ? 'bg-slate-950/80 border-slate-800 text-white'
                          : 'bg-slate-50 border-slate-200 text-slate-900'
                      }`}
                    />
                  </div>
                  <div>
                    <label
                      className={`block text-[11px] font-semibold mb-1 ${
                        isDark ? 'text-slate-400' : 'text-slate-600'
                      }`}
                    >
                      Vehicle Length (m)
                    </label>
                    <input
                      type="number"
                      step="0.01"
                      value={vehLength}
                      onChange={(e) => setVehLength(parseFloat(e.target.value))}
                      className={`w-full px-3 py-1.5 border rounded-lg text-xs font-mono ${
                        isDark
                          ? 'bg-slate-950/80 border-slate-800 text-white'
                          : 'bg-slate-50 border-slate-200 text-slate-900'
                      }`}
                    />
                  </div>
                  <div>
                    <label
                      className={`block text-[11px] font-semibold mb-1 ${
                        isDark ? 'text-slate-400' : 'text-slate-600'
                      }`}
                    >
                      Turning Radius (m)
                    </label>
                    <input
                      type="number"
                      step="0.1"
                      value={vehTurnRadius}
                      onChange={(e) => setVehTurnRadius(parseFloat(e.target.value))}
                      className={`w-full px-3 py-1.5 border rounded-lg text-xs font-mono ${
                        isDark
                          ? 'bg-slate-950/80 border-slate-800 text-white'
                          : 'bg-slate-50 border-slate-200 text-slate-900'
                      }`}
                    />
                  </div>
                  <div>
                    <label
                      className={`block text-[11px] font-semibold mb-1 ${
                        isDark ? 'text-slate-400' : 'text-slate-600'
                      }`}
                    >
                      Braking Distance (m)
                    </label>
                    <input
                      type="number"
                      step="0.5"
                      value={vehBrakingDist}
                      onChange={(e) => setVehBrakingDist(parseFloat(e.target.value))}
                      className={`w-full px-3 py-1.5 border rounded-lg text-xs font-mono ${
                        isDark
                          ? 'bg-slate-950/80 border-slate-800 text-white'
                          : 'bg-slate-50 border-slate-200 text-slate-900'
                      }`}
                    />
                  </div>
                </div>

                <div className="flex items-center gap-3 pt-3">
                  <button
                    type="button"
                    onClick={() => setStep(2)}
                    className={`px-4 py-2.5 font-medium rounded-lg text-xs flex items-center gap-1.5 cursor-pointer border ${
                      isDark
                        ? 'bg-slate-800 hover:bg-slate-700 text-slate-300 border-slate-700'
                        : 'bg-slate-100 hover:bg-slate-200 text-slate-700 border-slate-200'
                    }`}
                  >
                    <ArrowLeft className="w-3.5 h-3.5" />
                    <span>Back</span>
                  </button>
                  <button
                    type="button"
                    onClick={handleFinalRegister}
                    disabled={loading}
                    className="flex-1 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold rounded-lg text-xs flex items-center justify-center gap-2 shadow-md cursor-pointer disabled:opacity-50"
                  >
                    <span>{loading ? 'Creating Profile...' : 'Complete Setup & Launch Cockpit'}</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

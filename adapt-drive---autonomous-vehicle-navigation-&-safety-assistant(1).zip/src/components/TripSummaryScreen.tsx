import React from 'react';
import { TripRecord, UserProfile } from '../types/app';
import { useTheme } from '../context/ThemeContext';
import {
  ShieldCheck,
  CheckCircle2,
  Clock,
  Compass,
  Car,
  RotateCcw,
  AlertTriangle,
  Layers,
} from 'lucide-react';

interface TripSummaryScreenProps {
  user: UserProfile;
  lastTrip: Partial<TripRecord>;
  onStartNewDrive: () => void;
  onReconfigureVehicle: () => void;
}

export const TripSummaryScreen: React.FC<TripSummaryScreenProps> = ({
  user,
  lastTrip,
  onStartNewDrive,
  onReconfigureVehicle,
}) => {
  const { theme } = useTheme();
  const isDark = theme === 'dark';

  const events = lastTrip.events || [
    { time: '00:06', title: 'Road Edge Pothole Cluster', desc: 'ADAPT planner shifted trajectory smoothly around damaged asphalt', type: 'reroute' },
    { time: '00:12', title: 'Crossing Cattle on Carriageway', desc: 'Maintained 4.0m safety buffer until animal cleared', type: 'reroute' },
    { time: '00:18', title: 'Pedestrian at Zebra Crossing', desc: 'Smooth deceleration to full stop: Protected pedestrian passage', type: 'danger' },
    { time: '00:24', title: 'Slower Auto-Rickshaw Overtake', desc: 'Calculated lane change and overtook with 2.2m clearance', type: 'reroute' },
    { time: '00:28', title: 'Arrived at Destination Corridor', desc: 'Completed safely with zero collisions guaranteed', type: 'success' },
  ];

  return (
    <div
      className={`flex-1 overflow-y-auto p-6 select-none transition-colors duration-150 ${
        isDark ? 'bg-slate-950 text-slate-100' : 'bg-slate-100 text-slate-900'
      }`}
    >
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Header & Safety Score */}
        <div className="text-center pt-2">
          <div
            className={`inline-flex items-center gap-2 px-4 py-1.5 rounded-full text-xs font-bold uppercase tracking-wider mb-3 shadow-md border ${
              isDark
                ? 'bg-emerald-950/80 border-emerald-500/50 text-emerald-400'
                : 'bg-emerald-100 border-emerald-300 text-emerald-800'
            }`}
          >
            <ShieldCheck className="w-4 h-4 text-emerald-500" />
            <span>SAFETY SCORE: {lastTrip.safetyScore || 98} / 100 • OPTIMAL AVOIDANCE</span>
          </div>
          <h2
            className={`text-2xl md:text-3xl font-extrabold tracking-tight ${
              isDark ? 'text-white' : 'text-slate-900'
            }`}
          >
            Autonomous Mission Completed
          </h2>
          <p className={`text-xs md:text-sm mt-1 ${isDark ? 'text-slate-400' : 'text-slate-600'}`}>
            {lastTrip.origin || 'Electronic City Gate'} → {lastTrip.destination || 'Smart City Tech Park Hub'}
          </p>
        </div>

        {/* 4 Metric Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3.5">
          <div
            className={`border rounded-xl p-4 text-center shadow-lg transition-colors ${
              isDark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'
            }`}
          >
            <div
              className={`w-9 h-9 rounded-lg border flex items-center justify-center mx-auto mb-2 ${
                isDark
                  ? 'bg-blue-950/80 border-blue-500/40 text-blue-400'
                  : 'bg-blue-50 border-blue-200 text-blue-600'
              }`}
            >
              <Compass className="w-5 h-5" />
            </div>
            <div
              className={`text-2xl font-mono font-extrabold ${
                isDark ? 'text-white' : 'text-slate-900'
              }`}
            >
              {lastTrip.distanceKm || 4.8}{' '}
              <span className={`text-xs font-sans ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>
                km
              </span>
            </div>
            <div
              className={`text-[11px] font-semibold uppercase tracking-wider mt-1 ${
                isDark ? 'text-slate-400' : 'text-slate-500'
              }`}
            >
              Distance Traversed
            </div>
          </div>

          <div
            className={`border rounded-xl p-4 text-center shadow-lg transition-colors ${
              isDark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'
            }`}
          >
            <div
              className={`w-9 h-9 rounded-lg border flex items-center justify-center mx-auto mb-2 ${
                isDark
                  ? 'bg-blue-950/80 border-blue-500/40 text-blue-400'
                  : 'bg-blue-50 border-blue-200 text-blue-600'
              }`}
            >
              <Clock className="w-5 h-5" />
            </div>
            <div
              className={`text-2xl font-mono font-extrabold ${
                isDark ? 'text-white' : 'text-slate-900'
              }`}
            >
              {lastTrip.durationMin || 0}m {lastTrip.durationSec || 28}s
            </div>
            <div
              className={`text-[11px] font-semibold uppercase tracking-wider mt-1 ${
                isDark ? 'text-slate-400' : 'text-slate-500'
              }`}
            >
              Mission Duration
            </div>
          </div>

          <div
            className={`border rounded-xl p-4 text-center shadow-lg transition-colors ${
              isDark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'
            }`}
          >
            <div
              className={`w-9 h-9 rounded-lg border flex items-center justify-center mx-auto mb-2 ${
                isDark
                  ? 'bg-emerald-950/80 border-emerald-500/40 text-emerald-400'
                  : 'bg-emerald-50 border-emerald-200 text-emerald-600'
              }`}
            >
              <CheckCircle2 className="w-5 h-5" />
            </div>
            <div className="text-2xl font-mono font-extrabold text-emerald-500">
              0
            </div>
            <div
              className={`text-[11px] font-semibold uppercase tracking-wider mt-1 ${
                isDark ? 'text-slate-400' : 'text-slate-500'
              }`}
            >
              Collisions Recorded
            </div>
          </div>

          <div
            className={`border rounded-xl p-4 text-center shadow-lg transition-colors ${
              isDark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'
            }`}
          >
            <div
              className={`w-9 h-9 rounded-lg border flex items-center justify-center mx-auto mb-2 ${
                isDark
                  ? 'bg-purple-950/80 border-purple-500/40 text-purple-400'
                  : 'bg-purple-50 border-purple-200 text-purple-600'
              }`}
            >
              <Layers className="w-5 h-5" />
            </div>
            <div
              className={`text-2xl font-mono font-extrabold ${
                isDark ? 'text-purple-300' : 'text-purple-700'
              }`}
            >
              {lastTrip.obstaclesDetected || 4}
            </div>
            <div
              className={`text-[11px] font-semibold uppercase tracking-wider mt-1 ${
                isDark ? 'text-slate-400' : 'text-slate-500'
              }`}
            >
              Hazards Avoided
            </div>
          </div>
        </div>

        {/* Two-Column Details */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-4">
            <div
              className={`border rounded-xl p-4 shadow-lg text-xs space-y-2.5 transition-colors ${
                isDark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'
              }`}
            >
              <h3 className="text-xs font-bold uppercase tracking-wider text-blue-500 mb-2">
                Mission Route Details
              </h3>
              <div
                className={`flex justify-between py-1 border-b ${
                  isDark ? 'border-slate-800' : 'border-slate-100'
                }`}
              >
                <span className={isDark ? 'text-slate-400' : 'text-slate-500'}>Departure</span>
                <span className={`font-medium ${isDark ? 'text-white' : 'text-slate-900'}`}>
                  {lastTrip.origin || 'Electronic City Terminal Gate'}
                </span>
              </div>
              <div
                className={`flex justify-between py-1 border-b ${
                  isDark ? 'border-slate-800' : 'border-slate-100'
                }`}
              >
                <span className={isDark ? 'text-slate-400' : 'text-slate-500'}>Destination</span>
                <span className="text-blue-500 font-bold">
                  {lastTrip.destination || 'Smart City Tech Park Hub'}
                </span>
              </div>
              <div
                className={`flex justify-between py-1 border-b ${
                  isDark ? 'border-slate-800' : 'border-slate-100'
                }`}
              >
                <span className={isDark ? 'text-slate-400' : 'text-slate-500'}>Road Environment</span>
                <span className="text-amber-500 font-medium">Unstructured Indian Carriageway</span>
              </div>
              <div className="flex justify-between py-1">
                <span className={isDark ? 'text-slate-400' : 'text-slate-500'}>Safety Verification</span>
                <span className="text-emerald-500 font-mono font-bold">100% Collision-Free</span>
              </div>
            </div>

            <div
              className={`border rounded-xl p-4 shadow-lg text-xs space-y-2.5 transition-colors ${
                isDark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'
              }`}
            >
              <div className="flex justify-between items-center mb-2">
                <h3 className="text-xs font-bold uppercase tracking-wider text-blue-500">
                  Ego Vehicle Kinematic Model
                </h3>
                <span
                  className={`px-2 py-0.5 rounded border text-[10px] font-bold uppercase ${
                    isDark
                      ? 'bg-blue-950 border-blue-500/40 text-blue-300'
                      : 'bg-blue-50 border-blue-200 text-blue-700'
                  }`}
                >
                  {user.vehicle.type}
                </span>
              </div>
              <div
                className={`flex justify-between py-1 border-b ${
                  isDark ? 'border-slate-800' : 'border-slate-100'
                }`}
              >
                <span className={isDark ? 'text-slate-400' : 'text-slate-500'}>Model Configuration</span>
                <span className={`font-medium ${isDark ? 'text-white' : 'text-slate-900'}`}>
                  {user.vehicle.modelName}
                </span>
              </div>
              <div
                className={`flex justify-between py-1 border-b ${
                  isDark ? 'border-slate-800' : 'border-slate-100'
                }`}
              >
                <span className={isDark ? 'text-slate-400' : 'text-slate-500'}>Chassis Dimensions</span>
                <span className={`font-mono ${isDark ? 'text-white' : 'text-slate-900'}`}>
                  {user.vehicle.width}m W • {user.vehicle.length}m L
                </span>
              </div>
              <div
                className={`flex justify-between py-1 border-b ${
                  isDark ? 'border-slate-800' : 'border-slate-100'
                }`}
              >
                <span className={isDark ? 'text-slate-400' : 'text-slate-500'}>Turning Radius</span>
                <span className={`font-mono ${isDark ? 'text-white' : 'text-slate-900'}`}>
                  {user.vehicle.turningRadius} m
                </span>
              </div>
              <div className="flex justify-between py-1">
                <span className={isDark ? 'text-slate-400' : 'text-slate-500'}>AEB Horizon</span>
                <span className="text-amber-500 font-mono font-medium">{user.vehicle.brakingDist} m</span>
              </div>
            </div>
          </div>

          {/* Avoidance Timeline */}
          <div
            className={`border rounded-xl p-4 shadow-lg flex flex-col transition-colors ${
              isDark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'
            }`}
          >
            <h3 className="text-xs font-bold uppercase tracking-wider text-blue-500 mb-3">
              Autonomous Avoidance Timeline
            </h3>
            <div className="space-y-3 flex-1 overflow-y-auto pr-1">
              {events.map((evt, idx) => {
                const isDanger = evt.type === 'danger';
                const isSuccess = evt.type === 'success';
                return (
                  <div key={idx} className="flex items-start gap-3 text-xs">
                    <div
                      className={`w-7 h-7 rounded-full flex items-center justify-center shrink-0 mt-0.5 border ${
                        isDanger
                          ? isDark
                            ? 'bg-red-950/70 border-red-500 text-red-400'
                            : 'bg-red-100 border-red-300 text-red-600'
                          : isSuccess
                          ? isDark
                            ? 'bg-emerald-950/70 border-emerald-500 text-emerald-400'
                            : 'bg-emerald-100 border-emerald-300 text-emerald-600'
                          : isDark
                          ? 'bg-blue-950/70 border-blue-500 text-blue-400'
                          : 'bg-blue-100 border-blue-300 text-blue-600'
                      }`}
                    >
                      {isDanger ? (
                        <AlertTriangle className="w-3.5 h-3.5" />
                      ) : isSuccess ? (
                        <CheckCircle2 className="w-3.5 h-3.5" />
                      ) : (
                        <Compass className="w-3.5 h-3.5" />
                      )}
                    </div>
                    <div className="flex-1 leading-tight">
                      <div className="flex items-center justify-between">
                        <h5
                          className={`font-bold text-xs ${
                            isDark ? 'text-white' : 'text-slate-900'
                          }`}
                        >
                          {evt.title}
                        </h5>
                        <span
                          className={`font-mono text-[10px] ${
                            isDark ? 'text-slate-400' : 'text-slate-500'
                          }`}
                        >
                          {evt.time}
                        </span>
                      </div>
                      <p
                        className={`text-[11px] mt-1 ${
                          isDark ? 'text-slate-400' : 'text-slate-600'
                        }`}
                      >
                        {evt.desc}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Action Toolbar */}
        <div
          className={`border rounded-xl p-4 flex flex-wrap items-center justify-between gap-3 shadow-lg transition-colors ${
            isDark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'
          }`}
        >
          <div>
            <h4
              className={`text-sm font-bold ${
                isDark ? 'text-white' : 'text-slate-900'
              }`}
            >
              Ready for another mission run?
            </h4>
            <p
              className={`text-xs mt-0.5 ${
                isDark ? 'text-slate-400' : 'text-slate-500'
              }`}
            >
              Select another destination or adjust your vehicle kinematics.
            </p>
          </div>
          <div className="flex items-center gap-2.5">
            <button
              onClick={onReconfigureVehicle}
              className={`px-4 py-2.5 text-xs font-semibold rounded-lg border transition-all flex items-center gap-1.5 cursor-pointer ${
                isDark
                  ? 'bg-slate-800 hover:bg-slate-700 text-slate-200 border-slate-700'
                  : 'bg-slate-100 hover:bg-slate-200 text-slate-700 border-slate-300'
              }`}
            >
              <Car className="w-3.5 h-3.5" />
              <span>Change Profile</span>
            </button>
            <button
              onClick={onStartNewDrive}
              className="px-5 py-2.5 bg-blue-600 hover:bg-blue-500 active:bg-blue-700 text-white text-xs font-bold rounded-lg shadow-lg shadow-blue-600/30 transition-all flex items-center gap-2 cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Start New Drive</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

import React, { useEffect, useRef, useState, useMemo } from 'react';
import { RouteOption, UserProfile, TripRecord } from '../types/app';
import { SimulationEngine } from '../autonomy/SimulationEngine';
import { TelemetryData, LogEntry, SimSettings } from '../types/simulation';
import { AutomotiveAudio } from '../utils/audio';
import { useTheme } from '../context/ThemeContext';
import {
  ShieldCheck,
  AlertTriangle,
  Play,
  Pause,
  RotateCcw,
  Compass,
  ArrowUpRight,
  ArrowUpLeft,
  ArrowUp,
  Clock,
  Eye,
  Navigation,
  Layers,
  CheckCircle2,
  AlertOctagon,
} from 'lucide-react';

interface DriveCockpitProps {
  user: UserProfile;
  selectedRoute: RouteOption;
  onFinishTrip: (summary: Partial<TripRecord>) => void;
}

export const DriveCockpit: React.FC<DriveCockpitProps> = ({
  user,
  selectedRoute,
  onFinishTrip,
}) => {
  const { theme } = useTheme();
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);

  // Initialize simulation engine
  const engine = useMemo(() => new SimulationEngine(), []);

  // Reactive UI state
  const [telemetry, setTelemetry] = useState<TelemetryData>({
    simTime: 0,
    speedKmh: 0,
    currentHazard: 'None',
    hazardDistance: null,
    detectionStatus: 'Scanning',
    riskLevel: 'LOW',
    riskScore: 0.05,
    currentAction: 'Cruising safely',
    vehicleStatus: 'NORMAL',
    collisions: 0,
    stoppingDistance: 0,
    ttc: null,
    currentLane: 1,
    minClearanceOverall: 0,
    distanceTraveledMeters: 0,
    activeBanner: null,
  });

  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [settings, setSettings] = useState<SimSettings>(engine.settings);
  const [isRunning, setIsRunning] = useState<boolean>(false);
  const [isPaused, setIsPaused] = useState<boolean>(false);

  // Sync engine callbacks
  useEffect(() => {
    engine.onTelemetryUpdate = (t) => {
      setTelemetry(t);
      setIsRunning(engine.isSimRunning());
      setIsPaused(engine.isSimPaused());
    };
    engine.onLogsUpdate = (l) => {
      setLogs(l);
    };
    engine.onCompletion = (t) => {
      setTelemetry(t);
      setIsRunning(false);
      handleFinishTrip();
    };

    // Auto-start simulation on screen mount
    engine.start();
    setIsRunning(true);

    return () => {
      engine.onTelemetryUpdate = undefined;
      engine.onLogsUpdate = undefined;
      engine.onCompletion = undefined;
      engine.reset();
    };
  }, [engine]);

  // Canvas resize listener
  useEffect(() => {
    const handleResize = () => {
      if (!canvasRef.current || !containerRef.current) return;
      canvasRef.current.width = containerRef.current.clientWidth;
      canvasRef.current.height = containerRef.current.clientHeight;
    };
    handleResize();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // 60Hz Physics & Canvas Render Loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;
    let lastTime = performance.now();
    let accumulator = 0;
    const fixedDt = 1 / 60;

    const loop = (currentTime: number) => {
      const deltaSec = Math.min(0.1, (currentTime - lastTime) / 1000);
      lastTime = currentTime;
      accumulator += deltaSec;

      while (accumulator >= fixedDt) {
        engine.stepPhysics(fixedDt);
        accumulator -= fixedDt;
      }

      if (canvas.width > 0 && canvas.height > 0) {
        engine.render(ctx, canvas.width, canvas.height);
      }

      animId = requestAnimationFrame(loop);
    };

    animId = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(animId);
  }, [engine]);

  // Controls Handlers
  const handleTogglePlay = () => {
    if (isRunning) {
      engine.pause();
      setIsPaused(engine.isSimPaused());
    } else {
      engine.start();
      setIsRunning(true);
      setIsPaused(false);
    }
  };

  const handleReset = () => {
    engine.reset();
    setIsRunning(false);
    setIsPaused(false);
  };

  const handleSpeedChange = () => {
    const next = settings.simSpeedMultiplier === 1.0 ? 2.0 : 1.0;
    engine.setSpeedMultiplier(next);
    setSettings({ ...engine.settings, simSpeedMultiplier: next });
    AutomotiveAudio.playChime(900, 1);
  };

  const handleToggleSetting = (key: keyof SimSettings) => {
    (engine.settings as any)[key] = !(engine.settings as any)[key];
    setSettings({ ...engine.settings });
  };

  const handleFinishTrip = () => {
    const summaryData: Partial<TripRecord> = {
      destination: selectedRoute.destination,
      origin: selectedRoute.origin,
      routeId: selectedRoute.id,
      distanceKm: Number((selectedRoute.distanceKm * Math.min(1, Math.max(0.2, telemetry.distanceTraveledMeters / 350))).toFixed(1)) || 4.8,
      durationMin: Math.max(1, Math.floor(telemetry.simTime / 60)),
      durationSec: Math.floor(telemetry.simTime % 60),
      safetyScore: telemetry.collisions === 0 ? 98 : 82,
      obstaclesDetected: 4,
      reroutesCount: 3,
      emergencyBrakes: 1,
      vehicleModel: user.vehicle.modelName,
      events: [
        { time: '00:06', title: 'Road Edge Pothole Cluster', desc: 'ADAPT planner shifted trajectory smoothly around damaged asphalt', type: 'reroute' },
        { time: '00:12', title: 'Crossing Cattle on Carriageway', desc: 'Maintained 4.0m safety buffer until animal cleared', type: 'reroute' },
        { time: '00:18', title: 'Pedestrian at Zebra Crossing', desc: 'Smooth deceleration to full stop: Protected pedestrian passage', type: 'danger' },
        { time: '00:24', title: 'Slower Auto-Rickshaw Overtake', desc: 'Calculated lane change and overtook with 2.2m clearance', type: 'reroute' },
        { time: '00:28', title: 'Arrived at Destination Corridor', desc: 'Completed safely with zero collisions guaranteed', type: 'success' },
      ],
    };
    onFinishTrip(summaryData);
  };

  // Turn Navigation state based on distance traveled
  const currentStepIndex = Math.min(
    selectedRoute.navigationSteps.length - 1,
    Math.floor((telemetry.distanceTraveledMeters / 350) * selectedRoute.navigationSteps.length)
  );
  const currentNavStep = selectedRoute.navigationSteps[currentStepIndex] || selectedRoute.navigationSteps[0];

  const totalSimMeters = 350;
  const progressPct = Math.min(100, Math.round((telemetry.distanceTraveledMeters / totalSimMeters) * 100));

  const maxSpeed = 60;
  const speedRatio = Math.min(1, telemetry.speedKmh / maxSpeed);
  const strokeOffset = 188 * (1 - speedRatio * 0.75);

  const renderTurnIcon = () => {
    switch (currentNavStep.icon) {
      case 'left':
        return <ArrowUpLeft className="w-6 h-6 text-blue-400 stroke-[2.5]" />;
      case 'right':
        return <ArrowUpRight className="w-6 h-6 text-blue-400 stroke-[2.5]" />;
      case 'finish':
        return <CheckCircle2 className="w-6 h-6 text-emerald-400 stroke-[2.5]" />;
      default:
        return <ArrowUp className="w-6 h-6 text-blue-400 stroke-[2.5]" />;
    }
  };

  const isDark = theme === 'dark';
  const cardBg = isDark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200 shadow-sm';
  const innerCardBg = isDark ? 'bg-slate-950/80 border-slate-800' : 'bg-slate-50 border-slate-200';
  const textPrimary = isDark ? 'text-white' : 'text-slate-900';
  const textSecondary = isDark ? 'text-slate-400' : 'text-slate-500';

  return (
    <div className={`flex-1 flex flex-col lg:flex-row overflow-hidden select-none p-3 gap-3 transition-colors duration-150 ${
      isDark ? 'bg-slate-950 text-slate-100' : 'bg-slate-100 text-slate-800'
    }`}>
      {/* 1. LEFT PANEL: Speedometer, Gears & Navigation Guidance */}
      <aside className="w-full lg:w-[280px] flex flex-col shrink-0 gap-3">
        {/* Speedometer Instrument Card */}
        <div className={`${cardBg} border rounded-xl p-4 shadow-xl text-center`}>
          <div className={`text-[10px] ${textSecondary} font-bold uppercase tracking-wider mb-2`}>
            Host Vehicle Telemetry
          </div>
          <div className="relative w-28 h-28 mx-auto flex items-center justify-center">
            <svg className="w-full h-full -rotate-90" viewBox="0 0 72 72">
              <circle
                cx="36"
                cy="36"
                r="30"
                className={isDark ? 'stroke-slate-800' : 'stroke-slate-200'}
                strokeWidth="5"
                fill="none"
              />
              <circle
                cx="36"
                cy="36"
                r="30"
                className="stroke-blue-500 transition-all duration-150"
                strokeWidth="5"
                strokeDasharray="188"
                strokeDashoffset={strokeOffset}
                strokeLinecap="round"
                fill="none"
              />
            </svg>
            <div className="absolute flex flex-col items-center">
              <span className={`font-mono tabular-nums text-4xl font-extrabold ${textPrimary} leading-none`}>
                {telemetry.speedKmh}
              </span>
              <span className={`text-[10px] font-bold ${textSecondary} tracking-wider mt-1`}>
                KM/H
              </span>
            </div>
          </div>
          {/* Drive Gear Selector */}
          <div className="flex justify-center gap-2 mt-3 font-mono text-xs font-bold">
            <span className={`px-2 py-1 rounded ${isDark ? 'bg-slate-950 text-slate-500' : 'bg-slate-100 text-slate-400'}`}>P</span>
            <span className={`px-2 py-1 rounded ${isDark ? 'bg-slate-950 text-slate-500' : 'bg-slate-100 text-slate-400'}`}>R</span>
            <span className={`px-2 py-1 rounded ${isDark ? 'bg-slate-950 text-slate-500' : 'bg-slate-100 text-slate-400'}`}>N</span>
            <span className="px-2.5 py-1 rounded bg-blue-600 text-white shadow-sm shadow-blue-500/50">
              D
            </span>
          </div>
          <div className={`mt-2 text-[11px] ${textSecondary}`}>
            Cruising Target: <span className={`font-mono font-bold ${textPrimary}`}>45 km/h</span>
          </div>
        </div>

        {/* Turn-by-Turn Maneuver Navigation Card */}
        <div className={`${cardBg} border rounded-xl p-4 shadow-xl`}>
          <div className="flex items-center gap-3">
            <div className={`w-12 h-12 rounded-xl ${isDark ? 'bg-blue-950/80 border-blue-500/40' : 'bg-blue-50 border-blue-200'} border flex items-center justify-center shrink-0`}>
              {renderTurnIcon()}
            </div>
            <div className="leading-tight">
              <span className="text-[10px] font-bold text-blue-500 uppercase tracking-wider block">
                {currentNavStep.distanceM > 0 ? `In ${currentNavStep.distanceM} m` : 'Destination'}
              </span>
              <h4 className={`text-xs font-bold ${textPrimary} mt-0.5 leading-snug`}>
                {currentNavStep.instruction}
              </h4>
            </div>
          </div>
        </div>

        {/* Mission Destination & ETA Progress Card */}
        <div className={`${cardBg} border rounded-xl p-4 shadow-xl flex-1 flex flex-col justify-between`}>
          <div>
            <div className={`text-[10px] ${textSecondary} font-bold uppercase tracking-wider mb-1`}>
              Active Mission
            </div>
            <h4 className={`text-sm font-extrabold ${textPrimary} leading-tight`}>
              {selectedRoute.destination}
            </h4>
            <p className={`text-xs ${textSecondary} mt-0.5`}>Via {selectedRoute.via}</p>

            <div className={`grid grid-cols-2 gap-2 mt-3 pt-3 border-t ${isDark ? 'border-slate-800/80' : 'border-slate-200'} text-xs`}>
              <div>
                <span className={`text-[10px] ${textSecondary} uppercase block font-semibold`}>
                  Progress
                </span>
                <span className={`font-mono font-bold ${textPrimary} text-base`}>
                  {progressPct}%
                </span>
              </div>
              <div className="text-right">
                <span className={`text-[10px] ${textSecondary} uppercase block font-semibold`}>
                  Remaining
                </span>
                <span className="font-mono font-bold text-blue-500 text-base">
                  {(selectedRoute.distanceKm * (1 - progressPct / 100)).toFixed(1)} km
                </span>
              </div>
            </div>

            <div className={`w-full ${isDark ? 'bg-slate-950' : 'bg-slate-200'} rounded-full h-1.5 overflow-hidden mt-2`}>
              <div
                className="bg-gradient-to-r from-blue-500 to-emerald-400 h-full rounded-full transition-all duration-200"
                style={{ width: `${progressPct}%` }}
              />
            </div>
          </div>

          <button
            onClick={handleFinishTrip}
            className={`w-full mt-4 py-2.5 ${isDark ? 'bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white border-slate-700' : 'bg-slate-200 hover:bg-slate-300 text-slate-800 border-slate-300'} font-semibold rounded-lg text-xs transition-all border cursor-pointer`}
          >
            End Trip & View Summary
          </button>
        </div>
      </aside>

      {/* 2. CENTER STAGE: Pure Clean Road Simulation Viewport */}
      <section
        ref={containerRef}
        className={`relative flex-1 rounded-2xl overflow-hidden shadow-2xl flex flex-col min-h-[420px] transition-colors border ${
          isDark ? 'bg-slate-900 border-slate-800' : 'bg-slate-950 border-slate-300'
        }`}
      >
        <canvas ref={canvasRef} className="absolute inset-0 w-full h-full block" />

        {/* Minimalist Top-Left HUD Tag */}
        <div className="absolute top-3 left-3 z-10 pointer-events-none bg-slate-950/80 backdrop-blur-md border border-slate-800/80 rounded-lg px-3 py-1.5 text-[11px] font-mono text-slate-300 flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          <span className="text-slate-400">ADAS LIVE:</span>
          <span className="font-semibold text-white">{selectedRoute.name}</span>
          <span className="text-slate-500 mx-1">|</span>
          <span className="text-emerald-400 font-semibold">{telemetry.distanceTraveledMeters}m traversed</span>
        </div>

        {/* Bottom Simulation Control Deck */}
        <div className="mt-auto p-3 z-10 pointer-events-auto">
          <div
            className={`backdrop-blur-md border rounded-xl p-2.5 shadow-xl flex flex-wrap items-center justify-between gap-2 text-xs transition-colors ${
              isDark
                ? 'bg-slate-950/85 border-slate-800/90 text-slate-200'
                : 'bg-slate-900/90 border-slate-700/80 text-white'
            }`}
          >
            {/* Play / Pause / Reset */}
            <div className="flex items-center gap-2">
              <button
                onClick={handleTogglePlay}
                className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg text-xs font-semibold shadow-md transition-all cursor-pointer ${
                  !isRunning || isPaused
                    ? 'bg-blue-600 hover:bg-blue-500 text-white'
                    : 'bg-slate-800 hover:bg-slate-700 text-slate-200'
                }`}
              >
                {!isRunning || isPaused ? (
                  <>
                    <Play className="w-3.5 h-3.5 fill-current" />
                    <span>Resume</span>
                  </>
                ) : (
                  <>
                    <Pause className="w-3.5 h-3.5 fill-current" />
                    <span>Pause</span>
                  </>
                )}
              </button>
              <button
                onClick={handleReset}
                title="Reset simulation to beginning"
                className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 transition-all cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={handleSpeedChange}
                className="px-2 py-1 bg-slate-900 border border-slate-800 rounded font-mono text-xs text-sky-400 hover:text-white cursor-pointer"
                title="Simulation speed multiplier"
              >
                {settings.simSpeedMultiplier}x
              </button>
            </div>

            {/* Overlays Toggles */}
            <div className="flex items-center gap-1.5 text-[11px]">
              <button
                onClick={() => handleToggleSetting('showSensorCone')}
                className={`flex items-center gap-1 px-2.5 py-1 rounded-md border transition-all cursor-pointer ${
                  settings.showSensorCone
                    ? 'bg-sky-950/70 border-sky-500/50 text-sky-300'
                    : 'bg-slate-900 border-slate-800 text-slate-400'
                }`}
              >
                <Eye className="w-3 h-3" />
                <span>Sensors</span>
              </button>
              <button
                onClick={() => handleToggleSetting('showPlannedPath')}
                className={`flex items-center gap-1 px-2.5 py-1 rounded-md border transition-all cursor-pointer ${
                  settings.showPlannedPath
                    ? 'bg-emerald-950/70 border-emerald-500/50 text-emerald-300'
                    : 'bg-slate-900 border-slate-800 text-slate-400'
                }`}
              >
                <Navigation className="w-3 h-3" />
                <span>Trajectory</span>
              </button>
              <button
                onClick={() => handleToggleSetting('showTelemetryOverlay')}
                className={`flex items-center gap-1 px-2.5 py-1 rounded-md border transition-all cursor-pointer ${
                  settings.showTelemetryOverlay
                    ? 'bg-purple-950/70 border-purple-500/50 text-purple-300'
                    : 'bg-slate-900 border-slate-800 text-slate-400'
                }`}
              >
                <Layers className="w-3 h-3" />
                <span>Hazards</span>
              </button>
              <button
                onClick={() => {
                  const nextView = settings.viewMode === 'cockpit_3d' ? 'top_down' : 'cockpit_3d';
                  engine.settings.viewMode = nextView;
                  setSettings({ ...engine.settings });
                  AutomotiveAudio.playChime(750, 1);
                }}
                className={`flex items-center gap-1 px-2.5 py-1 rounded-md border transition-all cursor-pointer font-medium ${
                  settings.viewMode !== 'top_down'
                    ? 'bg-blue-950/70 border-blue-500/50 text-blue-300'
                    : 'bg-slate-900 border-slate-800 text-slate-400'
                }`}
              >
                <Compass className="w-3 h-3" />
                <span>{settings.viewMode !== 'top_down' ? '3D Cockpit View' : 'Bird-Eye Map'}</span>
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* 3. RIGHT PANEL: Safety Alerts, Corridor Feed & Autonomy Guidance */}
      <aside className="w-full lg:w-[320px] flex flex-col shrink-0 gap-3">
        {/* Prominent High-Contrast Safety Alert Banner */}
        <div
          className={`rounded-xl p-3.5 border transition-all shadow-xl ${
            telemetry.riskLevel === 'CRITICAL'
              ? 'bg-red-950/90 border-red-500 text-red-100 animate-pulse'
              : telemetry.riskLevel === 'HIGH'
              ? 'bg-orange-950/90 border-orange-500 text-orange-100'
              : telemetry.riskLevel === 'MEDIUM'
              ? 'bg-amber-950/90 border-amber-500 text-amber-100'
              : 'bg-emerald-950/80 border-emerald-500/50 text-emerald-100'
          }`}
        >
          <div className="flex items-center justify-between mb-1">
            <div className="flex items-center gap-2">
              {telemetry.riskLevel === 'CRITICAL' ? (
                <AlertOctagon className="w-5 h-5 text-red-400 shrink-0" />
              ) : telemetry.riskLevel === 'LOW' ? (
                <ShieldCheck className="w-5 h-5 text-emerald-400 shrink-0" />
              ) : (
                <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0" />
              )}
              <span className="font-extrabold text-xs uppercase tracking-wider">
                {telemetry.riskLevel === 'LOW'
                  ? 'PATH CLEAR'
                  : `${telemetry.riskLevel} COLLISION RISK`}
              </span>
            </div>
            <span className="font-mono text-[11px] font-bold">
              {telemetry.ttc !== null ? `TTC ${telemetry.ttc.toFixed(1)}s` : 'TTC > 5.0s'}
            </span>
          </div>
          <p className="text-xs font-medium leading-snug opacity-90 mt-1">
            {telemetry.currentAction}
          </p>
        </div>

        {/* Live Detected Corridor Hazards Card */}
        <div className={`${cardBg} border rounded-xl p-3.5 shadow-xl flex-1 flex flex-col`}>
          <div className={`flex items-center justify-between mb-2 pb-2 border-b ${isDark ? 'border-slate-800' : 'border-slate-200'}`}>
            <span className={`text-[10px] ${textSecondary} font-bold uppercase tracking-wider`}>
              Corridor Obstacles Live
            </span>
            <span className="text-[10px] font-mono text-blue-500 font-bold">
              {telemetry.currentHazard !== 'None' ? '1 Detected' : '0 Detected'}
            </span>
          </div>
          <div className="space-y-2 flex-1 overflow-y-auto">
            {telemetry.currentHazard !== 'None' ? (
              <div className={`p-2.5 rounded-lg ${innerCardBg} border flex items-center justify-between text-xs`}>
                <div>
                  <h5 className={`font-bold ${textPrimary} capitalize`}>
                    {telemetry.currentHazard === 'vehicle' ? 'Auto-Rickshaw' : telemetry.currentHazard}
                  </h5>
                  <span className={`text-[10px] ${textSecondary} font-mono`}>
                    Horizon: {telemetry.hazardDistance !== null ? `${telemetry.hazardDistance}m ahead` : 'In envelope'}
                  </span>
                </div>
                <span
                  className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded ${
                    telemetry.riskLevel === 'CRITICAL'
                      ? 'bg-red-950 text-red-400 border border-red-500/50'
                      : 'bg-amber-950 text-amber-400 border border-amber-500/50'
                  }`}
                >
                  {telemetry.riskLevel}
                </span>
              </div>
            ) : (
              <div className={`h-20 flex items-center justify-center ${textSecondary} text-xs italic`}>
                Scanning forward roadway envelope...
              </div>
            )}
          </div>

          {/* Autonomy Active Safety Guarantee Badge */}
          <div className={`mt-3 pt-2.5 border-t ${isDark ? 'border-slate-800' : 'border-slate-200'} flex items-center justify-between text-xs`}>
            <div className="flex items-center gap-1.5 text-emerald-500">
              <ShieldCheck className="w-4 h-4" />
              <span className="font-semibold text-[11px]">Safety Invariant:</span>
            </div>
            <span className="font-mono font-bold text-emerald-500">
              COLLISIONS: {telemetry.collisions} (GUARANTEED 0)
            </span>
          </div>
        </div>

        {/* Real-time Autonomy Guidance Log */}
        <div className={`${cardBg} border rounded-xl p-3.5 shadow-xl h-44 flex flex-col overflow-hidden`}>
          <div className={`flex items-center justify-between pb-1.5 border-b ${isDark ? 'border-slate-800' : 'border-slate-200'} mb-1.5 text-[10px] font-bold ${textSecondary} uppercase tracking-wider`}>
            <span>Autonomy Decision Log</span>
            <span className="font-mono text-slate-400">{logs.length}</span>
          </div>
          <div className={`flex-1 overflow-y-auto space-y-1 font-mono text-[10px] ${isDark ? 'text-slate-300' : 'text-slate-600'}`}>
            {logs.slice(-5).map((l) => (
              <div key={l.id} className="flex items-start gap-1.5 py-0.5">
                <span className="text-slate-400 shrink-0">{l.timeFormatted}</span>
                <span
                  className={
                    l.type === 'action'
                      ? 'text-sky-500'
                      : l.type === 'cleared'
                      ? 'text-emerald-500'
                      : isDark ? 'text-slate-300' : 'text-slate-700'
                  }
                >
                  {l.message}
                </span>
              </div>
            ))}
          </div>
        </div>
      </aside>
    </div>
  );
};

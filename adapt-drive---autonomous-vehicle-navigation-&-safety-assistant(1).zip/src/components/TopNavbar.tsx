import React, { useState, useEffect } from 'react';
import { UserProfile } from '../types/app';
import { Car, User, LogOut, Sun, Moon } from 'lucide-react';
import { useTheme } from '../context/ThemeContext';

interface TopNavbarProps {
  currentScreen: 'auth' | 'destination' | 'drive' | 'summary';
  user: UserProfile | null;
  onLogout: () => void;
  driveStatusText?: string;
}

export const TopNavbar: React.FC<TopNavbarProps> = ({
  currentScreen,
  user,
  onLogout,
  driveStatusText = 'ADAPTIVE AUTOPILOT ENGAGED',
}) => {
  const { theme, toggleTheme } = useTheme();
  const isDark = theme === 'dark';
  const [clock, setClock] = useState<string>('12:00:00');

  useEffect(() => {
    const update = () => {
      const d = new Date();
      const h = String(d.getHours()).padStart(2, '0');
      const m = String(d.getMinutes()).padStart(2, '0');
      const s = String(d.getSeconds()).padStart(2, '0');
      setClock(`${h}:${m}:${s}`);
    };
    update();
    const interval = setInterval(update, 1000);
    return () => clearInterval(interval);
  }, []);

  return (
    <header
      className={`h-14 px-5 border-b flex items-center justify-between shrink-0 select-none z-30 transition-colors duration-150 ${
        isDark
          ? 'bg-slate-900 border-slate-800 text-white shadow-md'
          : 'bg-white border-slate-200 text-slate-900 shadow-sm'
      }`}
    >
      {/* Brand Badge */}
      <div className="flex items-center gap-4">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center text-white shadow-sm shadow-blue-500/30">
            <Car className="w-4 h-4 stroke-[2.2]" />
          </div>
          <div className="leading-tight">
            <span
              className={`font-bold text-sm tracking-wider uppercase block ${
                isDark ? 'text-white' : 'text-slate-900'
              }`}
            >
              ADAPT-Drive
            </span>
            <span
              className={`text-[10px] font-medium block ${
                isDark ? 'text-slate-400' : 'text-slate-500'
              }`}
            >
              Autonomous Vehicle HMI
            </span>
          </div>
        </div>

        {/* Dynamic System Status Indicator */}
        <div
          className={`hidden sm:flex items-center gap-2 px-3 py-1 rounded-full border text-[11px] font-mono transition-colors ${
            isDark
              ? 'bg-slate-950/70 border-slate-800 text-slate-300'
              : 'bg-slate-100 border-slate-200 text-slate-700'
          }`}
        >
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
          <span className="font-semibold tracking-wide">
            {currentScreen === 'drive'
              ? driveStatusText
              : currentScreen === 'destination'
              ? 'ROUTE PLANNING ACTIVE'
              : currentScreen === 'summary'
              ? 'MISSION TELEMETRY ARCHIVED'
              : 'SYSTEM STANDBY'}
          </span>
        </div>
      </div>

      {/* Right Controls: Operator info, Clock, Theme Toggle, Log Out */}
      <div className="flex items-center gap-3">
        {user && (
          <div
            className={`hidden lg:flex items-center gap-1.5 text-xs px-2.5 py-1 rounded-lg border font-mono transition-colors ${
              isDark
                ? 'text-slate-300 bg-slate-950/60 border-slate-800/80'
                : 'text-slate-700 bg-slate-100 border-slate-200'
            }`}
          >
            <User className={`w-3.5 h-3.5 ${isDark ? 'text-slate-400' : 'text-slate-500'}`} />
            <span className={`text-[10px] uppercase ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>
              Operator:
            </span>
            <span className={`font-semibold ${isDark ? 'text-white' : 'text-slate-900'}`}>
              {user.name}
            </span>
          </div>
        )}

        <div
          className={`font-mono text-xs px-2.5 py-1 border rounded-lg tracking-wider transition-colors ${
            isDark
              ? 'bg-slate-950/70 border-slate-800 text-slate-300'
              : 'bg-slate-100 border-slate-200 text-slate-700'
          }`}
        >
          {clock}
        </div>

        {/* Light / Dark Mode Toggle */}
        <button
          onClick={toggleTheme}
          title={isDark ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
          className={`flex items-center gap-1.5 px-2.5 py-1 text-xs rounded-lg border transition-all cursor-pointer font-medium ${
            isDark
              ? 'bg-slate-950/80 border-slate-800 text-slate-300 hover:text-white hover:border-slate-700'
              : 'bg-slate-100 border-slate-200 text-slate-700 hover:text-slate-900 hover:border-slate-300 shadow-xs'
          }`}
        >
          {isDark ? (
            <>
              <Sun className="w-3.5 h-3.5 text-amber-400" />
              <span className="font-mono text-[11px]">Light</span>
            </>
          ) : (
            <>
              <Moon className="w-3.5 h-3.5 text-sky-500" />
              <span className="font-mono text-[11px]">Dark</span>
            </>
          )}
        </button>

        {/* Changed Exit button to Log Out button */}
        {user && (
          <button
            onClick={onLogout}
            title="Log Out Operator"
            className={`flex items-center gap-1.5 px-2.5 py-1 text-xs rounded-lg border transition-colors cursor-pointer font-semibold ${
              isDark
                ? 'text-slate-300 hover:text-red-400 hover:bg-slate-800/80 border-slate-800'
                : 'text-slate-700 hover:text-red-600 hover:bg-red-50 border-slate-200'
            }`}
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Log Out</span>
          </button>
        )}
      </div>
    </header>
  );
};

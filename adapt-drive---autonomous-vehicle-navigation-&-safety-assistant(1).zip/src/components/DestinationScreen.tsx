import React, { useState, useEffect, useRef } from 'react';
import { RouteOption, UserProfile } from '../types/app';
import { api } from '../services/api';
import { CURATED_ROUTES } from '../data/curatedRoutes';
import { AutomotiveAudio } from '../utils/audio';
import { loadGoogleMaps } from '../services/googleMapsLoader';
import { fetchRealRoadRoute } from '../services/routingService';
import { useTheme } from '../context/ThemeContext';
import {
  Search,
  MapPin,
  Navigation,
  Compass,
  AlertTriangle,
  ArrowRight,
  Clock,
  Check,
} from 'lucide-react';

const DARK_MAP_STYLES = [
  { elementType: 'geometry', stylers: [{ color: '#1e293b' }] },
  { elementType: 'labels.text.stroke', stylers: [{ color: '#0f172a' }] },
  { elementType: 'labels.text.fill', stylers: [{ color: '#94a3b8' }] },
  {
    featureType: 'administrative.locality',
    elementType: 'labels.text.fill',
    stylers: [{ color: '#cbd5e1' }],
  },
  {
    featureType: 'poi',
    elementType: 'labels.text.fill',
    stylers: [{ color: '#64748b' }],
  },
  {
    featureType: 'poi.park',
    elementType: 'geometry',
    stylers: [{ color: '#132e2b' }],
  },
  {
    featureType: 'poi.park',
    elementType: 'labels.text.fill',
    stylers: [{ color: '#34d399' }],
  },
  {
    featureType: 'road',
    elementType: 'geometry',
    stylers: [{ color: '#334155' }],
  },
  {
    featureType: 'road',
    elementType: 'geometry.stroke',
    stylers: [{ color: '#1e293b' }],
  },
  {
    featureType: 'road',
    elementType: 'labels.text.fill',
    stylers: [{ color: '#94a3b8' }],
  },
  {
    featureType: 'road.highway',
    elementType: 'geometry',
    stylers: [{ color: '#2563eb' }],
  },
  {
    featureType: 'road.highway',
    elementType: 'geometry.stroke',
    stylers: [{ color: '#1d4ed8' }],
  },
  {
    featureType: 'road.highway',
    elementType: 'labels.text.fill',
    stylers: [{ color: '#e2e8f0' }],
  },
  {
    featureType: 'transit',
    elementType: 'geometry',
    stylers: [{ color: '#1e293b' }],
  },
  {
    featureType: 'water',
    elementType: 'geometry',
    stylers: [{ color: '#0f172a' }],
  },
  {
    featureType: 'water',
    elementType: 'labels.text.fill',
    stylers: [{ color: '#38bdf8' }],
  },
];

interface DestinationScreenProps {
  user: UserProfile;
  onSelectRouteAndStart: (route: RouteOption) => void;
}

export const DestinationScreen: React.FC<DestinationScreenProps> = ({
  user,
  onSelectRouteAndStart,
}) => {
  const { theme } = useTheme();
  const [searchQuery, setSearchQuery] = useState('');
  const [routes, setRoutes] = useState<RouteOption[]>(CURATED_ROUTES);
  const [selectedRoute, setSelectedRoute] = useState<RouteOption>(CURATED_ROUTES[0]);
  const [mapType, setMapType] = useState<'roadmap' | 'satellite' | 'hybrid'>('roadmap');
  const [mapLoaded, setMapLoaded] = useState(false);
  const [mapError, setMapError] = useState<string | null>(null);

  const mapContainerRef = useRef<HTMLDivElement | null>(null);
  const mapInstanceRef = useRef<any>(null);
  const polylineRef = useRef<any>(null);
  const polylineGlowRef = useRef<any>(null);
  const markersRef = useRef<any[]>([]);

  useEffect(() => {
    api
      .getRoutes()
      .then((res) => {
        if (res.routes && res.routes.length > 0) {
          setRoutes(res.routes);
          setSelectedRoute(res.routes[0]);
        }
      })
      .catch(() => {
        setRoutes(CURATED_ROUTES);
        setSelectedRoute(CURATED_ROUTES[0]);
      });
  }, []);

  useEffect(() => {
    let isCancelled = false;
    loadGoogleMaps()
      .then(() => {
        if (isCancelled || !mapContainerRef.current) return;
        const google = window.google;
        if (!google?.maps) {
          setMapError('Google Maps API unavailable');
          return;
        }

        const center = { lat: 12.848, lng: 77.662 };
        const map = new google.maps.Map(mapContainerRef.current, {
          center,
          zoom: 14,
          mapTypeId: google.maps.MapTypeId.ROADMAP,
          zoomControl: true,
          zoomControlOptions: {
            position: google.maps.ControlPosition.RIGHT_BOTTOM,
          },
          mapTypeControl: false,
          streetViewControl: false,
          fullscreenControl: false,
          styles: theme === 'dark' ? DARK_MAP_STYLES : [],
        });

        mapInstanceRef.current = map;
        setMapLoaded(true);
      })
      .catch((err) => {
        console.error('Google Maps load error:', err);
        setMapError('Failed to load Google Maps');
      });

    return () => {
      isCancelled = true;
    };
  }, []);

  // Update map styles when theme changes
  useEffect(() => {
    if (!mapInstanceRef.current || !window.google?.maps) return;
    mapInstanceRef.current.setOptions({
      styles: theme === 'dark' ? DARK_MAP_STYLES : [],
    });
  }, [theme]);

  useEffect(() => {
    if (!mapInstanceRef.current || !window.google?.maps) return;
    mapInstanceRef.current.setMapTypeId(mapType);
  }, [mapType]);

  useEffect(() => {
    if (!mapInstanceRef.current || !window.google?.maps || !selectedRoute) return;
    const google = window.google;
    const map = mapInstanceRef.current;
    let isCancelled = false;

    markersRef.current.forEach((m) => m.setMap(null));
    markersRef.current = [];

    if (polylineRef.current) {
      polylineRef.current.setMap(null);
      polylineRef.current = null;
    }
    if (polylineGlowRef.current) {
      polylineGlowRef.current.setMap(null);
      polylineGlowRef.current = null;
    }

    const origin = {
      lat: selectedRoute.coordinates.origin[0],
      lng: selectedRoute.coordinates.origin[1],
    };
    const dest = {
      lat: selectedRoute.coordinates.destination[0],
      lng: selectedRoute.coordinates.destination[1],
    };

    const originMarker = new google.maps.Marker({
      position: origin,
      map,
      title: `Origin: ${selectedRoute.origin}`,
      icon: {
        path: google.maps.SymbolPath.CIRCLE,
        scale: 9,
        fillColor: '#2563eb',
        fillOpacity: 1,
        strokeColor: '#ffffff',
        strokeWeight: 3,
      },
      label: {
        text: 'A',
        color: '#ffffff',
        fontSize: '10px',
        fontWeight: 'bold',
      },
    });
    markersRef.current.push(originMarker);

    const destMarker = new google.maps.Marker({
      position: dest,
      map,
      title: `Destination: ${selectedRoute.destination}`,
      icon: {
        path: google.maps.SymbolPath.CIRCLE,
        scale: 11,
        fillColor: '#10b981',
        fillOpacity: 1,
        strokeColor: '#ffffff',
        strokeWeight: 3,
      },
      label: {
        text: 'B',
        color: '#ffffff',
        fontSize: '11px',
        fontWeight: 'bold',
      },
    });
    markersRef.current.push(destMarker);

    fetchRealRoadRoute(selectedRoute.coordinates.origin, selectedRoute.coordinates.destination)
      .then((routeResult) => {
        if (isCancelled) return;
        const pathCoords = routeResult.coordinates.map((c) => ({
          lat: c[0],
          lng: c[1],
        }));

        const glowLine = new google.maps.Polyline({
          path: pathCoords,
          geodesic: true,
          strokeColor: '#38bdf8',
          strokeOpacity: 0.45,
          strokeWeight: 8,
          map,
        });
        polylineGlowRef.current = glowLine;

        const mainLine = new google.maps.Polyline({
          path: pathCoords,
          geodesic: true,
          strokeColor: '#2563eb',
          strokeOpacity: 0.95,
          strokeWeight: 4,
          map,
        });
        polylineRef.current = mainLine;

        const bounds = new google.maps.LatLngBounds();
        pathCoords.forEach((pt) => bounds.extend(pt));
        map.fitBounds(bounds, { top: 50, right: 50, bottom: 50, left: 50 });
      })
      .catch((err) => {
        console.warn('Real route fetch error, using curated waypoint geometry:', err);
        const fallbackCoords = [
          origin,
          ...(selectedRoute.coordinates.waypoints || []).map((wp) => ({
            lat: wp[0],
            lng: wp[1],
          })),
          dest,
        ];
        const line = new google.maps.Polyline({
          path: fallbackCoords,
          geodesic: true,
          strokeColor: '#3b82f6',
          strokeOpacity: 0.9,
          strokeWeight: 4,
          map,
        });
        polylineRef.current = line;
      });

    return () => {
      isCancelled = true;
    };
  }, [selectedRoute, mapLoaded]);

  const handleSearchChange = (text: string) => {
    setSearchQuery(text);
    if (!text.trim()) {
      setRoutes(CURATED_ROUTES);
      return;
    }
    const clean = text.toLowerCase();
    const matched = CURATED_ROUTES.filter(
      (r) =>
        r.destination.toLowerCase().includes(clean) ||
        r.name.toLowerCase().includes(clean) ||
        r.via.toLowerCase().includes(clean)
    );
    if (matched.length > 0) {
      setRoutes(matched);
      setSelectedRoute(matched[0]);
    }
  };

  const handleSelectRoute = (r: RouteOption) => {
    setSelectedRoute(r);
    AutomotiveAudio.playChime(800, 1);
  };

  const handleStartDrive = () => {
    AutomotiveAudio.playSuccessChime();
    onSelectRouteAndStart(selectedRoute);
  };

  const isDark = theme === 'dark';
  const panelBg = isDark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200';
  const textTitle = isDark ? 'text-white' : 'text-slate-900';
  const textSub = isDark ? 'text-slate-400' : 'text-slate-500';

  return (
    <div className={`flex-1 flex flex-col lg:flex-row overflow-hidden select-none transition-colors duration-150 ${
      isDark ? 'bg-slate-950 text-slate-100' : 'bg-slate-100 text-slate-800'
    }`}>
      {/* LEFT / CONTROL PANEL: Destination Search & Route Options */}
      <div className={`w-full lg:w-[460px] flex flex-col shrink-0 ${panelBg} border-r p-5 overflow-y-auto`}>
        <div className="mb-5">
          <span className="text-[11px] font-bold uppercase tracking-wider text-blue-500 block mb-1">
            Autonomous Navigation
          </span>
          <h2 className={`text-xl md:text-2xl font-extrabold ${textTitle} tracking-tight`}>
            Where would you like to go?
          </h2>
          <p className={`text-xs ${textSub} mt-1`}>
            Select a destination corridor to load Google Maps routing & collision avoidance telemetry.
          </p>
        </div>

        {/* Destination Search Box */}
        <div className="relative mb-5">
          <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
            <Search className="w-4 h-4" />
          </div>
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => handleSearchChange(e.target.value)}
            placeholder="Search destination, tech campus, or highway..."
            className={`w-full pl-10 pr-4 py-3 ${
              isDark
                ? 'bg-slate-950/80 border-slate-700/80 text-white'
                : 'bg-slate-50 border-slate-300 text-slate-900'
            } border rounded-xl text-sm focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 shadow-inner`}
          />
        </div>

        {/* Curated Routes List */}
        <div className="space-y-3 flex-1 mb-5">
          <span className={`text-[11px] font-semibold ${textSub} uppercase tracking-wider block`}>
            Recommended Corridors ({routes.length})
          </span>
          {routes.map((route) => {
            const isSelected = selectedRoute?.id === route.id;
            return (
              <div
                key={route.id}
                onClick={() => handleSelectRoute(route)}
                className={`p-3.5 rounded-xl border transition-all cursor-pointer relative overflow-hidden ${
                  isSelected
                    ? isDark
                      ? 'bg-blue-950/60 border-blue-500 shadow-lg shadow-blue-950/40 ring-1 ring-blue-500/50'
                      : 'bg-blue-50 border-blue-500 shadow-sm ring-1 ring-blue-500'
                    : isDark
                    ? 'bg-slate-950/50 border-slate-800 hover:border-slate-700'
                    : 'bg-white border-slate-200 hover:border-slate-300 shadow-sm'
                }`}
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-start gap-2.5">
                    <div
                      className={`w-7 h-7 rounded-lg flex items-center justify-center shrink-0 mt-0.5 ${
                        isSelected ? 'bg-blue-600 text-white' : isDark ? 'bg-slate-800 text-slate-400' : 'bg-slate-100 text-slate-600'
                      }`}
                    >
                      <MapPin className="w-4 h-4" />
                    </div>
                    <div>
                      <h4 className={`text-sm font-bold ${textTitle} leading-tight`}>
                        {route.destination}
                      </h4>
                      <p className={`text-xs ${textSub} mt-0.5`}>Via {route.via}</p>
                    </div>
                  </div>
                  <div className="text-right shrink-0">
                    <span className={`text-sm font-mono font-bold ${textTitle} block`}>
                      {route.distanceKm} km
                    </span>
                    <span className={`text-[11px] font-mono ${textSub} flex items-center gap-1 justify-end`}>
                      <Clock className="w-3 h-3 text-slate-400" />
                      {route.durationMin}m
                    </span>
                  </div>
                </div>
                <div className={`mt-2.5 pt-2 border-t ${isDark ? 'border-slate-800/80' : 'border-slate-200'} flex items-center justify-between text-[11px]`}>
                  <span className={`${textSub} truncate max-w-[260px]`}>
                    {route.roadType}
                  </span>
                  {isSelected && (
                    <span className="text-emerald-500 font-semibold flex items-center gap-1">
                      <Check className="w-3 h-3" /> Selected
                    </span>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {/* Route Highlights */}
        {selectedRoute && (
          <div className={`${isDark ? 'bg-slate-950/70 border-slate-800' : 'bg-slate-50 border-slate-200'} p-3.5 rounded-xl border mb-5 text-xs space-y-2`}>
            <div className="flex items-center gap-1.5 text-amber-500 font-semibold text-[11px]">
              <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
              <span>Unstructured Road Corridor Diagnostics:</span>
            </div>
            <p className={`${isDark ? 'text-slate-300' : 'text-slate-600'} text-[11px] leading-relaxed`}>
              {selectedRoute.hazardsSummary}
            </p>
            <div className={`pt-2 border-t ${isDark ? 'border-slate-800/80' : 'border-slate-200'} flex items-center justify-between text-[11px] ${textSub} font-mono`}>
              <span>Ego Kinematics: {user.vehicle.modelName}</span>
              <span className="text-emerald-500 font-semibold">TTC Horizon: Active</span>
            </div>
          </div>
        )}

        {/* Start Drive Action Button */}
        <button
          onClick={handleStartDrive}
          className="w-full py-3.5 bg-blue-600 hover:bg-blue-500 active:bg-blue-700 text-white font-bold rounded-xl shadow-xl shadow-blue-600/30 transition-all flex items-center justify-center gap-2 cursor-pointer text-sm"
        >
          <Navigation className="w-4 h-4 fill-current" />
          <span>START AUTONOMOUS DRIVE</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>

      {/* RIGHT / MAIN STAGE: Google Maps Interactive Canvas */}
      <div className={`flex-1 relative h-[380px] lg:h-full ${isDark ? 'bg-slate-950' : 'bg-slate-200'}`}>
        <div ref={mapContainerRef} className="absolute inset-0 w-full h-full z-10" />

        <div
          className={`absolute top-4 left-4 z-20 pointer-events-none backdrop-blur-md border px-4 py-2.5 rounded-xl shadow-lg transition-colors ${
            isDark
              ? 'bg-slate-900/90 border-slate-800 text-white'
              : 'bg-white/95 border-slate-200 text-slate-900 shadow-md'
          }`}
        >
          <div className="flex items-center gap-2 text-xs font-semibold">
            <Compass className="w-4 h-4 text-blue-500 animate-spin-slow" />
            <span className={isDark ? 'text-white' : 'text-slate-900'}>
              Google Maps Vector Engine
            </span>
          </div>
          <p
            className={`text-[11px] mt-0.5 ${
              isDark ? 'text-slate-400' : 'text-slate-600'
            }`}
          >
            Real Google Maps rendering with waypoint geometry & collision buffer
          </p>
        </div>

        {/* Map View Controls */}
        <div
          className={`absolute top-4 right-4 z-20 backdrop-blur-md border p-1 rounded-xl shadow-lg flex items-center gap-1 transition-colors ${
            isDark
              ? 'bg-slate-900/90 border-slate-800'
              : 'bg-white/95 border-slate-200 shadow-md'
          }`}
        >
          <button
            onClick={() => setMapType('roadmap')}
            className={`px-3 py-1 rounded-lg text-xs font-medium transition-all cursor-pointer ${
              mapType === 'roadmap'
                ? 'bg-blue-600 text-white shadow-sm'
                : isDark
                ? 'text-slate-400 hover:text-white'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Roadmap
          </button>
          <button
            onClick={() => setMapType('satellite')}
            className={`px-3 py-1 rounded-lg text-xs font-medium transition-all cursor-pointer ${
              mapType === 'satellite'
                ? 'bg-blue-600 text-white shadow-sm'
                : isDark
                ? 'text-slate-400 hover:text-white'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Satellite
          </button>
          <button
            onClick={() => setMapType('hybrid')}
            className={`px-3 py-1 rounded-lg text-xs font-medium transition-all cursor-pointer ${
              mapType === 'hybrid'
                ? 'bg-blue-600 text-white shadow-sm'
                : isDark
                ? 'text-slate-400 hover:text-white'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Hybrid
          </button>
        </div>

        {selectedRoute && (
          <div
            className={`absolute bottom-5 left-5 z-20 pointer-events-none backdrop-blur-md border p-3.5 rounded-xl shadow-xl max-w-sm hidden sm:block transition-colors ${
              isDark
                ? 'bg-slate-900/90 border-slate-800 text-white'
                : 'bg-white/95 border-slate-200 text-slate-900 shadow-lg'
            }`}
          >
            <div
              className={`text-[10px] font-semibold uppercase tracking-wider mb-1 ${
                isDark ? 'text-slate-400' : 'text-slate-500'
              }`}
            >
              Active Mission Route
            </div>
            <div className={`text-sm font-bold ${isDark ? 'text-white' : 'text-slate-900'}`}>
              {selectedRoute.origin} → {selectedRoute.destination}
            </div>
            <div
              className={`text-xs font-mono mt-1 ${
                isDark ? 'text-slate-300' : 'text-slate-600'
              }`}
            >
              {selectedRoute.distanceKm} km | Est. {selectedRoute.durationMin} mins | Autonomous Planner Armed
            </div>
          </div>
        )}

        {!mapLoaded && !mapError && (
          <div className="absolute inset-0 z-10 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm">
            <div className="text-center">
              <div className="w-8 h-8 border-2 border-blue-500 border-t-transparent rounded-full animate-spin mx-auto mb-2" />
              <span className="text-xs font-mono text-slate-400 uppercase tracking-wider">
                Loading Google Maps...
              </span>
            </div>
          </div>
        )}

        {mapError && (
          <div className="absolute inset-0 z-10 flex items-center justify-center bg-slate-950/90 p-4">
            <div className="p-4 rounded-xl bg-red-950/70 border border-red-500/50 max-w-md text-center text-xs text-red-200">
              <AlertTriangle className="w-6 h-6 text-red-400 mx-auto mb-2" />
              <p className="font-semibold">{mapError}</p>
              <p className="text-slate-400 mt-1">Please check internet connection or API settings.</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

import { RouteOption } from '../types/app';

export interface SavedDestination {
  id: string;
  name: string;
  category: string;
  coordinates: [number, number];
  description: string;
}

export const DEFAULT_SAVED_DESTINATIONS: SavedDestination[] = [
  {
    id: 'dest_1',
    name: 'Smart City Tech Park Hub',
    category: 'Tech Campus',
    coordinates: [12.8452, 77.6602],
    description: 'Electronic City Phase 1 via Inner Ring Road Corridor',
  },
  {
    id: 'dest_2',
    name: 'Outer Ring Road Innovation Center',
    category: 'Commercial Hub',
    coordinates: [12.9279, 77.6834],
    description: 'Bellandur - Marathahalli Sub-Arterial Corridor',
  },
  {
    id: 'dest_3',
    name: 'Whitefield EPIP Industrial Zone',
    category: 'Tech Park',
    coordinates: [12.9791, 77.7281],
    description: 'Via ITPL Main Road Corridor',
  },
  {
    id: 'dest_4',
    name: "Kempegowda Int'l Airport Terminal 2",
    category: 'Airport Transit',
    coordinates: [13.1986, 77.7066],
    description: 'Via Ballari Road Elevated Corridor',
  },
  {
    id: 'dest_5',
    name: 'MG Road Metro Interchange',
    category: 'City Center',
    coordinates: [12.9756, 77.6066],
    description: 'Central Commercial District via Hosur Road',
  },
];

export const CURATED_ROUTES: RouteOption[] = [
  {
    id: 'route_tech_park',
    name: 'Inner Ring Road Corridor (Standard Scenario)',
    destination: 'Smart City Tech Park Hub',
    origin: 'Electronic City Terminal Gate',
    distanceKm: 4.8,
    durationMin: 12,
    via: 'Inner Ring Road Bypass',
    roadType: 'Unstructured Sub-Arterial Road (Partial Lanes & Mixed Hazards)',
    hazardsSummary: 'Pothole cluster, crossing cattle, pedestrian zebra zone, slow 3-wheelers',
    coordinates: {
      origin: [12.8500, 77.6650],
      destination: [12.8452, 77.6602],
      waypoints: [
        [12.8490, 77.6640],
        [12.8475, 77.6625],
        [12.8460, 77.6610],
      ],
    },
    navigationSteps: [
      { instruction: 'Proceed north on Electronic City Corridor', distanceM: 350, icon: 'straight' },
      { instruction: 'In 180 m Bear Left onto Inner Ring Road Bypass', distanceM: 180, icon: 'left' },
      { instruction: 'Caution: Surface damage & active pedestrian zebra zone', distanceM: 400, icon: 'straight' },
      { instruction: 'Turn right into Smart City Tech Park Gate 3', distanceM: 120, icon: 'right' },
      { instruction: 'Arrived at Destination: Tech Park Hub', distanceM: 0, icon: 'finish' },
    ],
  },
  {
    id: 'route_orr_corridor',
    name: 'Outer Ring Road Sub-Arterial Express',
    destination: 'Outer Ring Road Innovation Center',
    origin: 'Koramangala 4th Block',
    distanceKm: 6.4,
    durationMin: 16,
    via: 'Sarjapur Junction & Bellandur Corridor',
    roadType: 'Divided 3-Lane Carriageway with Heavy Transit',
    hazardsSummary: 'Intermittent road work, merging motorcycles, auto-rickshaw overtakes',
    coordinates: {
      origin: [12.9352, 77.6245],
      destination: [12.9279, 77.6834],
    },
    navigationSteps: [
      { instruction: 'Depart Koramangala 80ft Road toward Sarjapur Link', distanceM: 500, icon: 'straight' },
      { instruction: 'Merge onto Outer Ring Road Service carriageway', distanceM: 250, icon: 'right' },
      { instruction: 'Continue on center lane through Bellandur overpass', distanceM: 900, icon: 'straight' },
      { instruction: 'Arrive at ORR Innovation Center', distanceM: 0, icon: 'finish' },
    ],
  },
  {
    id: 'route_whitefield',
    name: 'Whitefield ITPL Expressway Link',
    destination: 'Whitefield EPIP Industrial Zone',
    origin: 'HAL Old Airport Road',
    distanceKm: 9.2,
    durationMin: 22,
    via: 'Marathahalli Underpass & Kundalahalli Gate',
    roadType: 'Dense Urban Corridor with Narrow Lateral Margins',
    hazardsSummary: 'Narrow road sections, stray animals on shoulder, pedestrian flow',
    coordinates: {
      origin: [12.9550, 77.6530],
      destination: [12.9791, 77.7281],
    },
    navigationSteps: [
      { instruction: 'Head east on Varthur Main Road', distanceM: 600, icon: 'straight' },
      { instruction: 'Keep right under Marathahalli flyover', distanceM: 400, icon: 'right' },
      { instruction: 'Follow EPIP Main Boulevard to Campus Gate', distanceM: 300, icon: 'straight' },
      { instruction: 'Arrive at Whitefield EPIP Zone', distanceM: 0, icon: 'finish' },
    ],
  },
];

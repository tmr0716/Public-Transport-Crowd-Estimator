/**
 * Types and interfaces for the Autonomous Vehicle Collision Avoidance Simulation
 */

export type HazardType = 'pothole' | 'animal' | 'pedestrian' | 'vehicle';

export type DecisionState =
  | 'CRUISE'
  | 'SLOW_DOWN'
  | 'BRAKE'
  | 'EMERGENCY_BRAKE'
  | 'STEER_LEFT'
  | 'STEER_RIGHT'
  | 'LANE_CHANGE'
  | 'FOLLOW'
  | 'STOP'
  | 'RESUME';

export type RiskLevel = 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';

export type VehicleStatus = 'NORMAL' | 'AVOIDING' | 'SAFE';

export interface Point2D {
  x: number;
  y: number;
}

export interface BoundingBoxOBB {
  center: Point2D;
  width: number; // Lateral extent in meters
  length: number; // Longitudinal extent in meters
  heading: number; // In radians
  corners: Point2D[];
}

export interface HazardObject {
  id: string;
  type: HazardType;
  name: string;
  x: number; // Lateral position in world (meters)
  y: number; // Longitudinal world coordinates (meters)
  vx: number; // Velocity in m/s
  vy: number;
  heading: number;
  width: number;
  length: number;
  state: 'approaching' | 'active' | 'avoided' | 'cleared';
  minRecordedDistance: number;
  // Dynamic behavior details
  behavior?: 'static' | 'crossing_right_to_left' | 'crossing_left_to_right' | 'cruising_slow';
  walkPhase?: number;
  initialX?: number;
  targetX?: number;
  crossingComplete?: boolean;
}

export interface EgoVehicleState {
  x: number; // Lateral position (meters, lane centers: e.g., 1.75 = Left, 5.25 = Center, 8.75 = Right)
  y: number; // Longitudinal position (meters)
  heading: number; // Radians (0 = straight along +y)
  speed: number; // m/s (1 m/s = 3.6 km/h)
  targetSpeed: number;
  acceleration: number; // m/s^2
  steeringAngle: number; // Radians
  targetSteeringAngle: number;
  currentLane: number; // 0, 1, or 2
  targetLane: number;
  width: number; // 1.8 m
  length: number; // 4.2 m
  wheelbase: number; // 2.6 m
  isBraking: boolean;
  indicator: 'none' | 'left' | 'right';
  indicatorTimer: number;
  pitch: number; // Visual pitch angle for braking
}

export interface PerceptionResult {
  hazard: HazardObject;
  distance: number;
  longitudinalDist: number;
  lateralDist: number;
  closingSpeed: number;
  ttc: number; // Time to collision in seconds
  inFov: boolean;
}

export interface RiskAssessment {
  level: RiskLevel;
  score: number; // 0 to 1
  stoppingDistance: number;
  safeStoppingBuffer: number;
  isThreat: boolean;
  primaryHazard: HazardObject | null;
}

export interface LogEntry {
  id: string;
  timestamp: number; // In seconds
  timeFormatted: string; // e.g. "[05.2s]"
  message: string;
  type: 'detection' | 'planning' | 'action' | 'cleared' | 'system';
  hazardType?: HazardType;
}

export interface TelemetryData {
  simTime: number; // In seconds
  speedKmh: number;
  currentHazard: HazardType | 'None';
  hazardDistance: number | null;
  detectionStatus: 'Scanning' | 'Hazard Detected' | 'Path Clear';
  riskLevel: RiskLevel;
  riskScore: number;
  currentAction: string;
  vehicleStatus: VehicleStatus;
  collisions: number;
  stoppingDistance: number;
  ttc: number | null;
  currentLane: number;
  minClearanceOverall: number;
  distanceTraveledMeters: number;
  activeBanner: {
    text: string;
    level: RiskLevel;
    expireAt: number;
  } | null;
}

export interface SimSettings {
  showSensorCone: boolean;
  showPlannedPath: boolean;
  showBoundingBoxes: boolean;
  showTelemetryOverlay: boolean;
  simSpeedMultiplier: number; // 0.5, 1.0, 2.0
  viewMode?: 'cockpit_3d' | 'top_down';
}

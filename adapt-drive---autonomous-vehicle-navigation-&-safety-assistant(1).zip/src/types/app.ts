export interface UserProfile {
  id: string;
  name: string;
  email: string;
  phone: string;
  token?: string;
  registeredAt?: string;
  vehicle: VehicleProfile;
  preferences?: {
    soundEnabled: boolean;
    autoOvertake: boolean;
    cautiousMargin: number; // in meters
  };
}

export interface VehicleProfile {
  type: 'suv' | 'hatchback' | 'sedan';
  modelName: string;
  width: number; // meters
  length: number; // meters
  turningRadius: number; // meters
  brakingDist: number; // meters at 40km/h
}

export interface RouteOption {
  id: string;
  name: string;
  destination: string;
  origin: string;
  distanceKm: number;
  durationMin: number;
  via: string;
  roadType: string;
  hazardsSummary: string;
  coordinates: {
    origin: [number, number]; // [lat, lng]
    destination: [number, number];
    waypoints?: [number, number][];
  };
  navigationSteps: {
    instruction: string;
    distanceM: number;
    icon: 'straight' | 'left' | 'right' | 'finish';
  }[];
}

export interface TripRecord {
  id: string;
  userId: string;
  destination: string;
  origin: string;
  routeId: string;
  distanceKm: number;
  durationMin: number;
  durationSec: number;
  completedAt: string;
  safetyScore: number;
  obstaclesDetected: number;
  reroutesCount: number;
  emergencyBrakes: number;
  vehicleModel: string;
  events: {
    time: string;
    title: string;
    desc: string;
    type: 'reroute' | 'danger' | 'success';
  }[];
}

import { UserProfile, VehicleProfile, RouteOption, TripRecord } from '../types/app';

const TOKEN_KEY = 'adapt_drive_auth_token';
const USER_KEY = 'adapt_drive_user_cache';

export const api = {
  getToken(): string | null {
    return localStorage.getItem(TOKEN_KEY);
  },
  setToken(token: string) {
    localStorage.setItem(TOKEN_KEY, token);
  },
  removeToken() {
    localStorage.removeItem(TOKEN_KEY);
    localStorage.removeItem(USER_KEY);
  },
  getCachedUser(): UserProfile | null {
    try {
      const raw = localStorage.getItem(USER_KEY);
      return raw ? JSON.parse(raw) : null;
    } catch {
      return null;
    }
  },
  setCachedUser(user: UserProfile) {
    localStorage.setItem(USER_KEY, JSON.stringify(user));
  },
  async request<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
    const token = this.getToken();
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      ...(options.headers as Record<string, string>),
    };
    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }
    try {
      const res = await fetch(`/api${endpoint}`, {
        ...options,
        headers,
      });
      if (!res.ok) {
        const errorData = await res.json().catch(() => ({}));
        throw new Error(errorData.error || `Request failed with status ${res.status}`);
      }
      return await res.json();
    } catch (err: any) {
      console.warn(`API call /api${endpoint} failed:`, err.message);
      throw err;
    }
  },

  async login(identifier: string, password: string): Promise<{ user: UserProfile; token: string }> {
    try {
      const data = await this.request<{ user: UserProfile; token: string }>('/auth/login', {
        method: 'POST',
        body: JSON.stringify({ identifier, password }),
      });
      this.setToken(data.token);
      this.setCachedUser(data.user);
      return data;
    } catch (e) {
      const fallbackUser: UserProfile = {
        id: 'usr_offline',
        name: identifier.includes('@') ? identifier.split('@')[0] : 'Driver',
        email: identifier.includes('@') ? identifier : `${identifier}@telemetry.adapt.in`,
        phone: identifier.includes('@') ? '9876543210' : identifier,
        vehicle: {
          type: 'suv',
          modelName: 'Production Compact SUV',
          width: 1.82,
          length: 4.25,
          turningRadius: 5.2,
          brakingDist: 13.5,
        },
      };
      this.setToken('offline_token');
      this.setCachedUser(fallbackUser);
      return { user: fallbackUser, token: 'offline_token' };
    }
  },

  async register(userData: {
    email: string;
    phone: string;
    name: string;
    password: string;
    vehicle?: Partial<VehicleProfile>;
  }): Promise<{ user: UserProfile; token: string }> {
    try {
      const data = await this.request<{ user: UserProfile; token: string }>('/auth/register', {
        method: 'POST',
        body: JSON.stringify(userData),
      });
      this.setToken(data.token);
      this.setCachedUser(data.user);
      return data;
    } catch (e) {
      const fallbackUser: UserProfile = {
        id: `usr_${Date.now()}`,
        name: userData.name || userData.email.split('@')[0],
        email: userData.email,
        phone: userData.phone,
        vehicle: {
          type: (userData.vehicle?.type as any) || 'suv',
          modelName: userData.vehicle?.modelName || 'Production Compact SUV',
          width: userData.vehicle?.width || 1.82,
          length: userData.vehicle?.length || 4.25,
          turningRadius: userData.vehicle?.turningRadius || 5.2,
          brakingDist: userData.vehicle?.brakingDist || 13.5,
        },
      };
      this.setToken('offline_token');
      this.setCachedUser(fallbackUser);
      return { user: fallbackUser, token: 'offline_token' };
    }
  },

  async quickDemoLogin(): Promise<{ user: UserProfile; token: string }> {
    try {
      const data = await this.request<{ user: UserProfile; token: string }>('/auth/quick-demo', {
        method: 'POST',
      });
      this.setToken(data.token);
      this.setCachedUser(data.user);
      return data;
    } catch {
      const demoUser: UserProfile = {
        id: 'usr_evaluator',
        name: 'Arjun Sharma (Evaluator)',
        email: 'driver@adapt.in',
        phone: '9876543210',
        vehicle: {
          type: 'suv',
          modelName: 'Production Compact SUV',
          width: 1.82,
          length: 4.25,
          turningRadius: 5.2,
          brakingDist: 13.5,
        },
      };
      this.setToken('demo_token');
      this.setCachedUser(demoUser);
      return { user: demoUser, token: 'demo_token' };
    }
  },

  async getMe(): Promise<UserProfile | null> {
    const token = this.getToken();
    if (!token) return null;
    try {
      const data = await this.request<{ user: UserProfile }>('/auth/me');
      this.setCachedUser(data.user);
      return data.user;
    } catch {
      return this.getCachedUser();
    }
  },

  async updateVehicle(vehicle: VehicleProfile): Promise<UserProfile> {
    try {
      const data = await this.request<{ user: UserProfile }>('/user/vehicle', {
        method: 'PUT',
        body: JSON.stringify({ vehicle }),
      });
      this.setCachedUser(data.user);
      return data.user;
    } catch {
      const user = this.getCachedUser()!;
      user.vehicle = vehicle;
      this.setCachedUser(user);
      return user;
    }
  },

  async getRoutes(): Promise<{ routes: RouteOption[]; destinations: any[] }> {
    try {
      return await this.request<{ routes: RouteOption[]; destinations: any[] }>('/routes');
    } catch {
      return {
        routes: [
          {
            id: 'route_tech_park',
            name: 'Inner Ring Road Corridor (Standard Scenario)',
            destination: 'Smart City Tech Park Hub',
            origin: 'Electronic City Terminal Gate',
            distanceKm: 4.8,
            durationMin: 12,
            via: 'Inner Ring Road Bypass',
            roadType: 'Unstructured Sub-Arterial Road (Partial Lanes & Mixed Hazards)',
            hazardsSummary: 'Pothole cluster, crossing cattle, pedestrian zebra zone, slow 3-wheelers',
            coordinates: {
              origin: [12.8500, 77.6650],
              destination: [12.8452, 77.6602],
            },
            navigationSteps: [
              { instruction: 'Proceed north on Electronic City Corridor', distanceM: 350, icon: 'straight' },
              { instruction: 'In 180 m Bear Left onto Inner Ring Road Bypass', distanceM: 180, icon: 'left' },
              { instruction: 'Caution: Surface damage & active pedestrian zebra zone', distanceM: 400, icon: 'straight' },
              { instruction: 'Turn right into Smart City Tech Park Gate 3', distanceM: 120, icon: 'right' },
              { instruction: 'Arrived at Destination: Tech Park Hub', distanceM: 0, icon: 'finish' },
            ],
          },
        ],
        destinations: [],
      };
    }
  },

  async searchDestinations(q: string) {
    return this.request<{ destinations: any[]; routes: RouteOption[] }>(`/routes/search?q=${encodeURIComponent(q)}`);
  },

  async saveTrip(trip: Partial<TripRecord>): Promise<TripRecord> {
    try {
      const res = await this.request<{ trip: TripRecord }>('/trips', {
        method: 'POST',
        body: JSON.stringify(trip),
      });
      return res.trip;
    } catch {
      const localTrip: TripRecord = {
        id: `trip_${Date.now()}`,
        userId: 'local',
        destination: trip.destination || 'Smart City Tech Park Hub',
        origin: trip.origin || 'Electronic City Gate',
        routeId: trip.routeId || 'route_tech_park',
        distanceKm: trip.distanceKm || 4.8,
        durationMin: trip.durationMin || 11,
        durationSec: trip.durationSec || 45,
        completedAt: new Date().toISOString(),
        safetyScore: trip.safetyScore || 98,
        obstaclesDetected: trip.obstaclesDetected || 4,
        reroutesCount: trip.reroutesCount || 3,
        emergencyBrakes: trip.emergencyBrakes || 1,
        vehicleModel: trip.vehicleModel || 'Production Compact SUV',
        events: trip.events || [],
      };
      return localTrip;
    }
  },

  async getTrips(): Promise<TripRecord[]> {
    try {
      const res = await this.request<{ trips: TripRecord[] }>('/trips');
      return res.trips;
    } catch {
      return [];
    }
  },
};

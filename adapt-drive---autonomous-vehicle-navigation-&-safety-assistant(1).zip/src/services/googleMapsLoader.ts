/**
 * Google Maps JavaScript API dynamic loader
 */

declare global {
  interface Window {
    google?: any;
    __googleMapsLoadPromise?: Promise<void>;
  }
}

export function loadGoogleMaps(): Promise<void> {
  if (typeof window === 'undefined') return Promise.resolve();
  if (window.google?.maps) {
    return Promise.resolve();
  }

  if (window.__googleMapsLoadPromise) {
    return window.__googleMapsLoadPromise;
  }

  const apiKey =
    (import.meta as any).env?.VITE_GOOGLE_MAPS_API_KEY ||
    'AIzaSyC4ke_-Iga8jqZuYNLxjsE1cw8JwzPBsm4';

  window.__googleMapsLoadPromise = new Promise((resolve, reject) => {
    const existingScript = document.querySelector('script[src*="maps.googleapis.com"]');
    if (existingScript) {
      if (window.google?.maps) {
        resolve();
        return;
      }
      existingScript.addEventListener('load', () => resolve());
      existingScript.addEventListener('error', (err) => reject(err));
      return;
    }

    const script = document.createElement('script');
    script.src = `https://maps.googleapis.com/maps/api/js?key=${apiKey}&libraries=geometry,places&v=weekly`;
    script.async = true;
    script.defer = true;
    script.onload = () => {
      resolve();
    };
    script.onerror = (e) => {
      console.error('Failed to load Google Maps script:', e);
      reject(new Error('Google Maps script failed to load'));
    };
    document.head.appendChild(script);
  });

  return window.__googleMapsLoadPromise;
}

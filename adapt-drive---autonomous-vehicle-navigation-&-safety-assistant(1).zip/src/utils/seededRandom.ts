/**
 * Deterministic seeded pseudo-random number generator (Mulberry32)
 * Ensures reproducible road imperfections, pothole cracks, and scenario timing
 */

export class SeededRandom {
  private state: number;

  constructor(seed: number = 133742) {
    this.state = seed;
  }

  public setSeed(seed: number): void {
    this.state = seed;
  }

  /**
   * Returns a float between 0 (inclusive) and 1 (exclusive)
   */
  public next(): number {
    let t = (this.state += 0x6d2b79f5);
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  }

  /**
   * Returns a float between min and max
   */
  public range(min: number, max: number): number {
    return min + this.next() * (max - min);
  }

  /**
   * Returns an integer between min and max (inclusive)
   */
  public rangeInt(min: number, max: number): number {
    return Math.floor(this.range(min, max + 1));
  }

  /**
   * Returns true with probability p (0 to 1)
   */
  public chance(p: number): boolean {
    return this.next() < p;
  }
}

/**
 * Geometry and Kinematic Math Utilities
 * - Oriented Bounding Box (OBB)
 * - Separating Axis Theorem (SAT) collision test
 * - Quintic polynomial trajectory smoothing
 * - Scale & Coordinate transforms
 */

import { Point2D, BoundingBoxOBB } from '../types/simulation';

// World scale: 1 meter = 18 pixels
export const WORLD_SCALE = 18;

// Lane configuration
export const LANE_WIDTH = 3.5; // meters (63 px)
export const NUM_LANES = 3; // Ego carriageway lanes (Lane 0: Left, Lane 1: Center, Lane 2: Right)

// Driving Carriageway physical boundaries (nominal baseline)
export const ROAD_LEFT_EDGE = 0.0; // Left curb / divider boundary
export const ROAD_RIGHT_EDGE = 10.5; // Right shoulder boundary (3 lanes * 3.5m = 10.5m)

// Lane 0: [0.0, 3.5] -> center 1.75m
// Lane 1: [3.5, 7.0] -> center 5.25m
// Lane 2: [7.0, 10.5] -> center 8.75m
export const LANE_CENTERS = [1.75, 5.25, 8.75];

// Physical Non-Drivable Divider / Median
export const MEDIAN_LEFT_EDGE = -1.6;
export const MEDIAN_RIGHT_EDGE = 0.0;
export const MEDIAN_WIDTH = 1.6;

// Opposing Traffic Carriageway (Left of divider)
export const OPPOSING_ROAD_LEFT_EDGE = -8.6;
export const OPPOSING_ROAD_RIGHT_EDGE = -1.6;

// Roundabout / Chowk Square Parameters
export const ROUNDABOUT_CENTER_Y = 212.0; // Longitudinal position of roundabout center
export const ROUNDABOUT_ISLAND_RADIUS = 4.5; // Radius of central rotary island (meters)

export interface RoadGeometry {
  curvatureX: number; // Lateral center displacement of the road (turns & curves)
  roadWidth: number; // Dynamic width (thicker and thinner)
  halfWidth: number;
  centerX: number;
  leftEdge: number;
  rightEdge: number;
  laneCenters: [number, number, number];
  isRoundaboutZone: boolean;
  roundaboutIsland?: { x: number; y: number; radius: number };
}

/**
 * Computes road curvature, dynamic width (thicker/thinner),
 * turns, and roundabout chowk geometry at any longitudinal distance y
 */
export function getRoadGeometry(y: number): RoadGeometry {
  // 1. Curvature X (Horizontal turns and curves)
  let curvatureX = 0;
  if (y > 35 && y <= 95) {
    // Gentle left bend leading to pothole zone
    const t = (y - 35) / 60;
    curvatureX = Math.sin(t * Math.PI) * -2.8;
  } else if (y > 95 && y <= 170) {
    // Sweeping right turn leading to cattle crossing zone
    const t = (y - 95) / 75;
    curvatureX = Math.sin(t * Math.PI) * 3.2;
  } else if (y > 170 && y <= 236) {
    // Roundabout square approach and departure curve
    const t = (y - 170) / 66;
    curvatureX = Math.sin(t * Math.PI) * 1.4;
  } else if (y > 236 && y <= 288) {
    // Bottle-neck chicane turn left through narrowed section
    const t = (y - 236) / 52;
    curvatureX = Math.sin(t * Math.PI) * -2.6;
  } else if (y > 288 && y <= 360) {
    // Wide boulevard sweeping right turn
    const t = (y - 288) / 72;
    curvatureX = Math.sin(t * Math.PI) * 2.8;
  } else if (y > 360) {
    // Straightening towards destination hub
    const t = Math.min(1.0, (y - 360) / 40);
    curvatureX = (1 - t) * 1.0;
  }

  // 2. Dynamic Road Width (thicker and thinner sections)
  // Baseline width: 10.5m (3 lanes of 3.5m)
  let roadWidth = 10.5;
  if (y > 35 && y <= 85) {
    // Thicker road with widened shoulder buffer near pothole zone (~12.2m)
    const t = (y - 35) / 50;
    roadWidth = 10.5 + Math.sin(t * Math.PI) * 1.7;
  } else if (y >= 180 && y <= 236) {
    // ROUNDABOUT / CHOWK SQUARE: dramatically widens to ~17.5m!
    const t = (y - 180) / 56;
    roadWidth = 10.5 + Math.sin(t * Math.PI) * 7.0;
  } else if (y >= 244 && y <= 288) {
    // NARROWING BOTTLE-NECK: thins down to ~7.8m (tight 2-lane squeeze)
    const t = (y - 244) / 44;
    roadWidth = 10.5 - Math.sin(t * Math.PI) * 2.7;
  } else if (y >= 295 && y <= 355) {
    // WIDENING BOULEVARD: thickens to ~13.5m (spacious multi-lane passing)
    const t = (y - 295) / 60;
    roadWidth = 10.5 + Math.sin(t * Math.PI) * 3.0;
  }

  const halfWidth = roadWidth / 2;
  const centerX = 5.25 + curvatureX;
  const leftEdge = centerX - halfWidth;
  const rightEdge = centerX + halfWidth;

  // 3. Roundabout Island Detection
  const isRoundaboutZone = y >= 194 && y <= 230;
  const roundaboutIsland = isRoundaboutZone
    ? {
        x: 5.25 + 1.4,
        y: ROUNDABOUT_CENTER_Y,
        radius: ROUNDABOUT_ISLAND_RADIUS,
      }
    : undefined;

  // 4. Dynamic Lane Centers adapting to curvature, width & roundabout
  let laneCenters: [number, number, number];
  if (isRoundaboutZone && roundaboutIsland) {
    const dy = y - roundaboutIsland.y;
    const islandR = roundaboutIsland.radius;
    const distY = Math.abs(dy);
    const islandWidthAtY = distY < islandR ? Math.sqrt(islandR * islandR - dy * dy) : 0;

    // Traffic smoothly bypasses left or right around the circular rotary
    const leftPassX = roundaboutIsland.x - islandWidthAtY - 2.0;
    const rightPassX = roundaboutIsland.x + islandWidthAtY + 2.0;
    const midPassX = dy < 0 ? leftPassX + 0.8 : rightPassX - 0.8;
    laneCenters = [leftPassX, midPassX, rightPassX];
  } else {
    const laneW = roadWidth / 3;
    laneCenters = [
      leftEdge + laneW * 0.5,
      leftEdge + laneW * 1.5,
      leftEdge + laneW * 2.5,
    ];
  }

  return {
    curvatureX,
    roadWidth,
    halfWidth,
    centerX,
    leftEdge,
    rightEdge,
    laneCenters,
    isRoundaboutZone,
    roundaboutIsland,
  };
}

/**
 * Returns lane center X coordinate at distance y
 */
export function getLaneCenter(lane: number, y: number): number {
  const geom = getRoadGeometry(y);
  const clampedLane = Math.max(0, Math.min(2, Math.floor(lane)));
  return geom.laneCenters[clampedLane];
}

/**
 * Computes 4 corners of an Oriented Bounding Box
 */
export function computeOBB(
  cx: number,
  cy: number,
  width: number,
  length: number,
  heading: number
): BoundingBoxOBB {
  const cos = Math.cos(heading);
  const sin = Math.sin(heading);
  const halfW = width / 2;
  const halfL = length / 2;

  // Local corners: front-left, front-right, rear-right, rear-left
  const localCorners = [
    { x: -halfW, y: halfL }, // FL
    { x: halfW, y: halfL },  // FR
    { x: halfW, y: -halfL }, // RR
    { x: -halfW, y: -halfL } // RL
  ];

  const corners: Point2D[] = localCorners.map((pt) => ({
    x: cx + pt.x * cos - pt.y * sin,
    y: cy + pt.x * sin + pt.y * cos,
  }));

  return {
    center: { x: cx, y: cy },
    width,
    length,
    heading,
    corners,
  };
}

/**
 * Project polygon onto an axis and return [min, max]
 */
function projectPolygon(axis: Point2D, corners: Point2D[]): [number, number] {
  let min = Infinity;
  let max = -Infinity;
  for (let i = 0; i < corners.length; i++) {
    const dot = corners[i].x * axis.x + corners[i].y * axis.y;
    if (dot < min) min = dot;
    if (dot > max) max = dot;
  }
  return [min, max];
}

/**
 * Check if two 1D intervals overlap
 */
function intervalsOverlap(minA: number, maxA: number, minB: number, maxB: number): boolean {
  return !(maxA < minB || maxB < minA);
}

/**
 * Separating Axis Theorem (SAT) collision test between two OBBs
 */
export function testOBBOverlap(obb1: BoundingBoxOBB, obb2: BoundingBoxOBB): boolean {
  const getAxes = (corners: Point2D[]): Point2D[] => {
    const axes: Point2D[] = [];
    for (let i = 0; i < 2; i++) {
      const p1 = corners[i];
      const p2 = corners[(i + 1) % 4];
      const edge = { x: p2.x - p1.x, y: p2.y - p1.y };
      const len = Math.hypot(edge.x, edge.y) || 1;
      axes.push({ x: -edge.y / len, y: edge.x / len });
    }
    return axes;
  };

  const axes1 = getAxes(obb1.corners);
  const axes2 = getAxes(obb2.corners);
  const allAxes = [...axes1, ...axes2];

  for (const axis of allAxes) {
    const [min1, max1] = projectPolygon(axis, obb1.corners);
    const [min2, max2] = projectPolygon(axis, obb2.corners);
    if (!intervalsOverlap(min1, max1, min2, max2)) {
      return false; // Separating axis found
    }
  }

  return true; // Overlap on all axes
}

/**
 * Calculates Euclidean distance between two 2D points
 */
export function distance2D(p1: Point2D, p2: Point2D): number {
  return Math.hypot(p2.x - p1.x, p2.y - p1.y);
}

/**
 * Approximate minimum clearance between two OBB centers minus their half-diagonals
 */
export function approximateClearance(obb1: BoundingBoxOBB, obb2: BoundingBoxOBB): number {
  const centerDist = distance2D(obb1.center, obb2.center);
  const r1 = Math.hypot(obb1.width, obb1.length) * 0.5;
  const r2 = Math.hypot(obb2.width, obb2.length) * 0.5;
  return Math.max(0, centerDist - (r1 + r2));
}

/**
 * Convert World meters to Canvas Screen pixels
 */
export function worldToScreen(
  wx: number,
  wy: number,
  camX: number,
  camY: number,
  canvasWidth: number,
  canvasHeight: number
): Point2D {
  return {
    x: canvasWidth * 0.5 + (wx - camX) * WORLD_SCALE,
    y: canvasHeight * 0.70 - (wy - camY) * WORLD_SCALE,
  };
}

/**
 * Clamp a number to [min, max]
 */
export function clamp(val: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, val));
}

/**
 * Linear interpolation
 */
export function lerp(a: number, b: number, t: number): number {
  return a + (b - a) * t;
}
